export const DEFAULT_SUPER_ADMIN_EMAIL = "akterplanning83@gmail.com";
export const SUPER_ADMIN_EMAIL = DEFAULT_SUPER_ADMIN_EMAIL;

export function isSuperAdminUser(
  email?: string | null,
  username?: string | null,
  extraSuperAdmins?: (string | null | undefined)[] | null,
): boolean {
  if (!email && !username) return false;
  const e = (email ?? "").toLowerCase().trim();
  const u = (username ?? "").toLowerCase().trim();

  // Root / default super admin check
  if (
    e === DEFAULT_SUPER_ADMIN_EMAIL.toLowerCase() ||
    u === "akterplanning83" ||
    u === DEFAULT_SUPER_ADMIN_EMAIL.toLowerCase()
  ) {
    return true;
  }

  // Check dynamic super admins list (IDs or usernames)
  if (extraSuperAdmins && Array.isArray(extraSuperAdmins)) {
    for (const item of extraSuperAdmins) {
      if (!item) continue;
      const it = item.toLowerCase().trim();
      if ((e && it === e) || (u && it === u)) {
        return true;
      }
    }
  }

  // Client-side local cache fallback
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem("cg_super_admins");
      if (raw) {
        const list = JSON.parse(raw);
        if (Array.isArray(list)) {
          for (const item of list) {
            if (!item) continue;
            const it = String(item).toLowerCase().trim();
            if ((e && it === e) || (u && it === u)) {
              return true;
            }
          }
        }
      }
    } catch {
      /* ignore */
    }
  }

  return false;
}

export type PermissionCategory = "planning" | "production" | "factory" | "analytics";

export interface PermissionItem {
  key: string;
  label: string;
  category: PermissionCategory;
  categoryLabel: string;
  description: string;
}

export const PERMISSION_CATEGORIES: { id: PermissionCategory; label: string; icon: string }[] = [
  { id: "planning", label: "প্ল্যানিং ও শিডিউলিং", icon: "CalendarRange" },
  { id: "production", label: "প্রোডাকশন ট্র্যাকিং", icon: "Factory" },
  { id: "factory", label: "কারখানা ও লাইন সেটআপ", icon: "Settings" },
  { id: "analytics", label: "রিপোর্ট ও অ্যানালিটিক্স", icon: "BarChart3" },
];

export const WORK_PERMISSIONS_LIST: PermissionItem[] = [
  // প্ল্যানিং ও শিডিউলিং
  {
    key: "can_create_plan",
    label: "নতুন প্ল্যান তৈরি",
    category: "planning",
    categoryLabel: "প্ল্যানিং ও শিডিউলিং",
    description: "প্ল্যান ইনপুট ফর্ম থেকে নতুন প্রোডাকশন প্ল্যান তৈরি করা",
  },
  {
    key: "can_edit_plan",
    label: "প্ল্যান এডিট ও মডিফাই",
    category: "planning",
    categoryLabel: "প্ল্যানিং ও শিডিউলিং",
    description: "বিদ্যমান যেকোনো প্ল্যানের টার্গেট, কোয়ান্টিটি ও লাইনে পরিবর্তন আনা",
  },
  {
    key: "can_delete_plan",
    label: "প্ল্যান ডিলিট / বাতিল",
    category: "planning",
    categoryLabel: "প্ল্যানিং ও শিডিউলিং",
    description: "প্ল্যান স্থায়ীভাবে মুছে ফেলা বা প্ল্যান বাতিল করা",
  },
  {
    key: "can_drag_reschedule",
    label: "বোর্ডে ড্র্যাগ ও রিসিডিউল",
    category: "planning",
    categoryLabel: "প্ল্যানিং ও শিডিউলিং",
    description: "প্ল্যান বোর্ডে মাউস দিয়ে ড্র্যাগ করে লাইন ও ডেট রিসিডিউল করা",
  },
  {
    key: "can_manage_unplanned",
    label: "আনপ্ল্যান্ড অর্ডার ম্যানেজমেন্ট",
    category: "planning",
    categoryLabel: "প্ল্যানিং ও শিডিউলিং",
    description: "আনপ্ল্যান্ড অর্ডার তালিকায় অর্ডার সংরক্ষণ ও লাইনে সরাসরি প্ল্যান করা",
  },

  // প্রোডাকশন ট্র্যাকিং
  {
    key: "can_update_production",
    label: "দৈনিক প্রোডাকশন আপডেট",
    category: "production",
    categoryLabel: "প্রোডাকশন ট্র্যাকিং",
    description: "লাইনের দৈনিক সেলাই ও ফিনিশিং প্রোডাকশন এন্ট্রি ইনপুট করা",
  },
  {
    key: "can_backdate_correction",
    label: "ব্যাক-ডেট কারেকশন ও সংশোধন",
    category: "production",
    categoryLabel: "প্রোডাকশন ট্র্যাকিং",
    description: "অতীতের যেকোনো তারিখের প্রোডাকশন সংখ্যা সংশোধন ও আপডেট করা",
  },
  {
    key: "can_complete_order",
    label: "অর্ডার কমপ্লিট / ক্লোজ করা",
    category: "production",
    categoryLabel: "প্রোডাকশন ট্র্যাকিং",
    description: "অর্ডার পূর্ণ হওয়া সাপেক্ষে কমপ্লিট অর্ডারে পাঠানো ও ক্লোজ করা",
  },

  // কারখানা ও লাইন সেটআপ
  {
    key: "can_manage_lines",
    label: "লাইন অ্যালোকেশন ও ওপেন ডেজ",
    category: "factory",
    categoryLabel: "কারখানা ও লাইন সেটআপ",
    description: "ফ্যাক্টরির লাইন খোলা/বন্ধ রাখা ও কার্যদিবস (Open Days) নির্ধারণ করা",
  },
  {
    key: "can_manage_holidays",
    label: "ছুটির দিন ও ক্যালেন্ডার এডিট",
    category: "factory",
    categoryLabel: "কারখানা ও লাইন সেটআপ",
    description: "ফ্যাক্টরির সাপ্তাহিক ছুটি, সরকারি ছুটি ও বিশেষ ছুটির দিন নির্ধারণ করা",
  },
  {
    key: "can_manage_shifts",
    label: "শিফট ও কাজের সময়",
    category: "factory",
    categoryLabel: "কারখানা ও লাইন সেটআপ",
    description: "শিফট ট্র্যাকার ও দৈনিক কাজের ঘণ্টা কনফিগারেশন করা",
  },

  // রিপোর্ট ও অ্যানালিটিক্স
  {
    key: "can_view_all_factories",
    label: "সকল ফ্যাক্টরির ডেটা দেখা",
    category: "analytics",
    categoryLabel: "রিপোর্ট ও অ্যানালিটিক্স",
    description: "সকল ফ্যাক্টরির প্ল্যান ও অগ্রগতি একসাথে দেখার অনুমতি",
  },
  {
    key: "can_view_matrix",
    label: "ম্যাট্রিক্স ও বায়ার সিজন ভিউ",
    category: "analytics",
    categoryLabel: "রিপোর্ট ও অ্যানালিটিক্স",
    description: "ম্যাট্রিক্স ভিউ, বায়ার ও সিজনভিত্তিক গ্রিড ও সামারি দেখার অনুমতি",
  },
  {
    key: "can_view_budget",
    label: "মান্থলি বাজেট ও এফিসিয়েন্সি",
    category: "analytics",
    categoryLabel: "রিপোর্ট ও অ্যানালিটিক্স",
    description: "মান্থলি বাজেট চার্ট ও লাইনের রিয়েল-টাইম এফিসিয়েন্সি দেখা",
  },
  {
    key: "can_export_reports",
    label: "এক্সেল / রিপোর্ট ডাউনলোড",
    category: "analytics",
    categoryLabel: "রিপোর্ট ও অ্যানালিটিক্স",
    description: "প্ল্যানিং ও প্রোডাকশনের সম্পূর্ণ ডেটা এক্সেল শিটে ডাউনলোড ও এক্সপোর্ট করা",
  },
];

export type PermissionPresetKey =
  "super_admin" | "team_leader" | "full_planner" | "production_entry" | "viewer";

export interface PresetDef {
  key: PermissionPresetKey;
  label: string;
  badgeClass: string;
  description: string;
  permissions: Record<string, boolean>;
}

export const PERMISSION_PRESETS: Record<PermissionPresetKey, PresetDef> = {
  super_admin: {
    key: "super_admin",
    label: "👑 সুপার অ্যাডমিন (পূর্ণ এক্সেস)",
    badgeClass: "bg-purple-900/60 text-purple-200 border-purple-500/40",
    description: "সিস্টেমের সকল ফ্যাক্টরি, ইউজার ও ফিচারের শতভাগ নিয়ন্ত্রণ ও এক্সেস",
    permissions: WORK_PERMISSIONS_LIST.reduce((acc, p) => ({ ...acc, [p.key]: true }), {}),
  },
  team_leader: {
    key: "team_leader",
    label: "🎯 টিম লিডার (ফ্যাক্টরি প্রধান)",
    badgeClass: "bg-indigo-900/60 text-indigo-200 border-indigo-500/40",
    description:
      "নিজ ফ্যাক্টরির সমস্ত প্ল্যানিং, টিম মেম্বারদের কাজ পর্যবেক্ষণ ও প্রোডাকশন কন্ট্রোল",
    permissions: {
      can_create_plan: true,
      can_edit_plan: true,
      can_delete_plan: true,
      can_drag_reschedule: true,
      can_manage_unplanned: true,
      can_update_production: true,
      can_backdate_correction: true,
      can_complete_order: true,
      can_manage_lines: true,
      can_manage_holidays: true,
      can_manage_shifts: true,
      can_view_all_factories: false,
      can_view_matrix: true,
      can_view_budget: true,
      can_export_reports: true,
    },
  },
  full_planner: {
    key: "full_planner",
    label: "⚡ সিনিয়র প্ল্যানার (প্ল্যানিং ও শিডিউলিং)",
    badgeClass: "bg-blue-900/60 text-blue-200 border-blue-500/40",
    description: "প্ল্যান তৈরি, এডিট, রিসিডিউল ও রিপোর্ট এক্সপোর্টের পূর্ণ ক্ষমতা",
    permissions: {
      can_create_plan: true,
      can_edit_plan: true,
      can_delete_plan: false,
      can_drag_reschedule: true,
      can_manage_unplanned: true,
      can_update_production: true,
      can_backdate_correction: false,
      can_complete_order: true,
      can_manage_lines: true,
      can_manage_holidays: false,
      can_manage_shifts: false,
      can_view_all_factories: false,
      can_view_matrix: true,
      can_view_budget: true,
      can_export_reports: true,
    },
  },
  production_entry: {
    key: "production_entry",
    label: "🏭 প্রোডাকশন অপারেটর (এন্ট্রি ও আপডেট)",
    badgeClass: "bg-emerald-900/60 text-emerald-200 border-emerald-500/40",
    description: "দৈনিক প্রোডাকশন সংখ্যা ইনপুট ও অর্ডারের আপডেট প্রদান",
    permissions: {
      can_create_plan: false,
      can_edit_plan: false,
      can_delete_plan: false,
      can_drag_reschedule: false,
      can_manage_unplanned: false,
      can_update_production: true,
      can_backdate_correction: false,
      can_complete_order: true,
      can_manage_lines: false,
      can_manage_holidays: false,
      can_manage_shifts: false,
      can_view_all_factories: false,
      can_view_matrix: true,
      can_view_budget: false,
      can_export_reports: false,
    },
  },
  viewer: {
    key: "viewer",
    label: "👁️ ভিউয়ার / অডিটর (শুধুমাত্র দেখার অনুমতি)",
    badgeClass: "bg-slate-800 text-slate-300 border-slate-700",
    description: "বোর্ড, ম্যাট্রিক্স ও রিপোর্ট শুধুমাত্র দেখতে ও ডাউনলোড করতে পারেন",
    permissions: {
      can_create_plan: false,
      can_edit_plan: false,
      can_delete_plan: false,
      can_drag_reschedule: false,
      can_manage_unplanned: false,
      can_update_production: false,
      can_backdate_correction: false,
      can_complete_order: false,
      can_manage_lines: false,
      can_manage_holidays: false,
      can_manage_shifts: false,
      can_view_all_factories: false,
      can_view_matrix: true,
      can_view_budget: false,
      can_export_reports: true,
    },
  },
};

export function getDefaultPermissionsForRole(
  role: "admin" | "team_leader" | "user",
  isSuperAdmin = false,
): Record<string, boolean> {
  if (isSuperAdmin || role === "admin") {
    return { ...PERMISSION_PRESETS.super_admin.permissions };
  }
  if (role === "team_leader") {
    return { ...PERMISSION_PRESETS.team_leader.permissions };
  }
  return { ...PERMISSION_PRESETS.full_planner.permissions };
}
