import * as XLSX from "xlsx";
import type { PlanResult } from "./plan-calc";
import { formatDate } from "./plan-calc";

export function exportMicroPlan(buyer: string, style: string, calc: PlanResult) {
  const lines = calc.lines ?? [];

  // Union of all dates across lines, sorted ascending
  const dateSet = new Set<string>();
  lines.forEach((l) => (l.dailyProduction ?? []).forEach((d) => dateSet.add(d.date)));
  const dates = Array.from(dateSet).sort();

  // Build AoA
  const aoa: (string | number)[][] = [];
  aoa.push([`Buyer: ${buyer}`, `Style: ${style}`]);
  aoa.push([
    `Order Qty: ${calc.orderQty}`,
    `Planned (incl. ${calc.excessPct}% excess): ${calc.totalPlannedQty}`,
    `Daily Target/Line: ${calc.dailyTargetPerLine}`,
    `Finish: ${formatDate(calc.finishDate)}`,
    `Shipment: ${formatDate(calc.shipmentDate)}`,
  ]);
  aoa.push([]);

  // Header row
  const header: (string | number)[] = ["Date", "Day"];
  lines.forEach((l) => header.push(l.name));
  header.push("Daily Total");
  aoa.push(header);

  const lineTotals = new Array(lines.length).fill(0);
  let grand = 0;

  dates.forEach((date) => {
    const d = new Date(date);
    const dayName = d.toLocaleDateString("en-US", { weekday: "short" });
    const row: (string | number)[] = [formatDate(date), dayName];
    let dailyTotal = 0;
    lines.forEach((l, i) => {
      const entry = (l.dailyProduction ?? []).find((x) => x.date === date);
      const qty = entry ? entry.qty : 0;
      row.push(qty || "");
      lineTotals[i] += qty;
      dailyTotal += qty;
    });
    row.push(dailyTotal);
    grand += dailyTotal;
    aoa.push(row);
  });

  // Totals row
  const totalRow: (string | number)[] = ["TOTAL", ""];
  lineTotals.forEach((t) => totalRow.push(t));
  totalRow.push(grand);
  aoa.push(totalRow);

  // Working days row
  const wdRow: (string | number)[] = ["Working Days", ""];
  lines.forEach((l) => wdRow.push(l.workingDays));
  wdRow.push("");
  aoa.push(wdRow);

  const ws = XLSX.utils.aoa_to_sheet(aoa);

  // Column widths
  ws["!cols"] = [{ wch: 12 }, { wch: 6 }, ...lines.map(() => ({ wch: 12 })), { wch: 14 }];

  // Merge title cells across line columns
  const lastCol = 2 + lines.length; // includes Daily Total column
  ws["!merges"] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: Math.max(1, Math.floor(lastCol / 2)) } },
    {
      s: { r: 0, c: Math.max(1, Math.floor(lastCol / 2)) + 1 },
      e: { r: 0, c: lastCol },
    },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Micro Plan");

  const safe = (s: string) => s.replace(/[^\w-]+/g, "_").slice(0, 40);
  XLSX.writeFile(wb, `MicroPlan_${safe(buyer)}_${safe(style)}.xlsx`);
}
