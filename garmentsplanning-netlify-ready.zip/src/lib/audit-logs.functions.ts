import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import {
  type AuditLogEntry,
  type AuditActionType,
  AUDIT_ACTION_CONFIG,
} from "@/lib/audit-logs.types";
import { isSuperAdminUser } from "@/lib/permissions.types";

const recordAuditSchema = z.object({
  action: z.string(),
  details: z.string(),
  targetId: z.string().optional(),
  targetName: z.string().optional(),
  factoryId: z.string().nullable().optional(),
  factoryName: z.string().nullable().optional(),
  metadata: z.record(z.unknown()).optional(),
});

// Record an audit log entry (any authenticated user performing an action)
export const recordAuditLog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => recordAuditSchema.parse(d))
  .handler(async ({ data, context }) => {
    const userId = context.userId;
    const email = context.claims?.email ?? "";
    const rawUsername =
      context.claims?.user_metadata?.username ?? (email ? email.split("@")[0] : "unknown");

    const isSuper = isSuperAdminUser(email, rawUsername);

    // Get user's profile and role from context.supabase
    let username = rawUsername;
    let role = isSuper ? "admin" : "user";
    let factoryId = data.factoryId ?? null;
    let factoryName = data.factoryName ?? null;

    try {
      const [{ data: prof }, { data: rRow }] = await Promise.all([
        context.supabase
          .from("profiles")
          .select("username, factory_id")
          .eq("id", userId)
          .maybeSingle(),
        context.supabase.from("user_roles").select("role").eq("user_id", userId).maybeSingle(),
      ]);

      if (prof?.username) username = prof.username;
      if (prof?.factory_id && !factoryId) factoryId = prof.factory_id;
      if (rRow?.role && !isSuper) role = rRow.role;

      if (factoryId && !factoryName) {
        const { data: fData } = await context.supabase
          .from("factories")
          .select("name")
          .eq("id", factoryId)
          .maybeSingle();
        if (fData?.name) factoryName = fData.name;
      }
    } catch {
      /* ignore lookup failure */
    }

    const actionKey = data.action as AuditActionType;
    const actionConfig = AUDIT_ACTION_CONFIG[actionKey];
    const actionLabel = actionConfig ? actionConfig.label : data.action;

    const entry: AuditLogEntry = {
      id: `audit_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      userId,
      username,
      userRole: role,
      isSuperAdmin: isSuper,
      factoryId,
      factoryName,
      action: actionKey,
      actionLabel,
      details: data.details,
      targetId: data.targetId,
      targetName: data.targetName,
      metadata: data.metadata,
    };

    const { readAuditLogsFromDisk, writeAuditLogsToDisk } = await import("./server-storage.server");
    const existing = await readAuditLogsFromDisk();
    existing.unshift(entry); // Newest at top
    await writeAuditLogsToDisk(existing);

    return { ok: true, entryId: entry.id };
  });

const listAuditSchema = z.object({
  action: z.string().optional(),
  userId: z.string().optional(),
  factoryId: z.string().optional(),
  search: z.string().optional(),
  limit: z.number().optional().default(200),
});

// List audit log entries (Super Admin and Admins)
export const listAuditLogs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => listAuditSchema.parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const email = context.claims?.email;
    const username = context.claims?.user_metadata?.username;
    const isSuper = isSuperAdminUser(email, username);

    // If not super admin, check if admin
    if (!isSuper) {
      const { data: roleRow } = await context.supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", context.userId)
        .eq("role", "admin")
        .maybeSingle();
      if (!roleRow) {
        throw new Error("Forbidden: audit logs are accessible only by administrators.");
      }
    }

    const { readAuditLogsFromDisk } = await import("./server-storage.server");
    let logs = await readAuditLogsFromDisk();

    if (data.action) {
      logs = logs.filter((l) => l.action === data.action);
    }
    if (data.userId) {
      logs = logs.filter((l) => l.userId === data.userId);
    }
    if (data.factoryId) {
      logs = logs.filter((l) => l.factoryId === data.factoryId);
    }
    if (data.search) {
      const q = data.search.trim().toLowerCase();
      logs = logs.filter(
        (l) =>
          l.username.toLowerCase().includes(q) ||
          l.details.toLowerCase().includes(q) ||
          (l.targetName && l.targetName.toLowerCase().includes(q)) ||
          (l.factoryName && l.factoryName.toLowerCase().includes(q)),
      );
    }

    return logs.slice(0, data.limit ?? 200);
  });

// Clear all audit logs (Super Admin only)
export const clearAuditLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const email = context.claims?.email;
    const username = context.claims?.user_metadata?.username;
    if (!isSuperAdminUser(email, username)) {
      throw new Error("শুধুমাত্র সুপার অ্যাডমিন অডিট হিস্টোরি ক্লিয়ার করতে পারবেন।");
    }

    const { writeAuditLogsToDisk } = await import("./server-storage.server");
    await writeAuditLogsToDisk([]);
    return { ok: true };
  });
