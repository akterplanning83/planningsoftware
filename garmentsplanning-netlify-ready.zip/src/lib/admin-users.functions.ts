import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import {
  SUPER_ADMIN_EMAIL,
  isSuperAdminUser,
  getDefaultPermissionsForRole,
} from "@/lib/permissions.types";

const EMAIL_DOMAIN = "cloud-garments.local";

// Lazy loader for server storage to ensure ZERO Node.js built-ins leak to the browser bundle
const getStorage = async () => import("./server-storage.server");

// biome-ignore lint/suspicious/noExplicitAny: supabase client — typed at call site
async function assertAdmin(supabase: any, userId: string, claims?: any): Promise<void> {
  const email = claims?.email;
  const username = claims?.user_metadata?.username;
  const { loadSuperAdminsFromDisk } = await getStorage();
  const superList = await loadSuperAdminsFromDisk();

  // 1. Any user in dynamic super admins or akterplanning83 is guaranteed Super Admin
  if (
    isSuperAdminUser(email, username, superList) ||
    superList.includes(userId.toLowerCase()) ||
    (username && superList.includes(username.toLowerCase())) ||
    (email && superList.includes(email.toLowerCase()))
  ) {
    try {
      await supabase
        .from("user_roles")
        .upsert({ user_id: userId, role: "admin" }, { onConflict: "user_id,role" });
    } catch {
      /* ignore */
    }
    return;
  }

  // 2. Database RPC check
  try {
    const { data, error } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!error && data) return;
  } catch {
    /* fallback to direct role check */
  }

  // 3. Direct user_roles check using authenticated client
  try {
    const { data: roleRow } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    if (roleRow) return;
  } catch {
    /* fallback to admin */
  }

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: roleRowAdmin } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (!roleRowAdmin) throw new Error("Forbidden: admin only.");
}

// biome-ignore lint/suspicious/noExplicitAny: supabase admin client
async function pickTopRole(supabase: any, userId: string): Promise<string> {
  const { data } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  const set = new Set((data ?? []).map((r: { role: string }) => r.role));
  if (set.has("admin")) return "admin";
  if (set.has("team_leader")) return "team_leader";
  return "user";
}

// --- List all users (admin only) ---
export const listAppUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);

    // Prefer context.supabase (which carries user's authenticated JWT) for RLS policies
    const { data: initialProfiles, error: pErr } = await context.supabase
      .from("profiles")
      .select("id, username, active, created_at, team_leader_id, factory_id")
      .order("created_at", { ascending: true });
    let profiles = initialProfiles;

    if (pErr || !profiles) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const res = await supabaseAdmin
        .from("profiles")
        .select("id, username, active, created_at, team_leader_id, factory_id")
        .order("created_at", { ascending: true });
      profiles = res.data;
    }

    const { data: initialRoles, error: rErr } = await context.supabase
      .from("user_roles")
      .select("user_id, role");
    let roles = initialRoles;

    if (rErr || !roles) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const res = await supabaseAdmin.from("user_roles").select("user_id, role");
      roles = res.data;
    }

    // Priority: admin > team_leader > user
    const roleMap = new Map<string, string>();
    for (const r of roles ?? []) {
      const cur = roleMap.get(r.user_id);
      if (r.role === "admin") roleMap.set(r.user_id, "admin");
      else if (r.role === "team_leader" && cur !== "admin") roleMap.set(r.user_id, "team_leader");
      else if (!cur) roleMap.set(r.user_id, r.role);
    }

    // Load saved granular permissions & dynamic super admins
    const { loadPermissionsFromDisk, loadSuperAdminsFromDisk } = await getStorage();
    const [allSavedPerms, superAdminsList] = await Promise.all([
      loadPermissionsFromDisk(),
      loadSuperAdminsFromDisk(),
    ]);

    return (profiles ?? []).map((p) => {
      const isSuper =
        isSuperAdminUser(p.username, p.username, superAdminsList) ||
        superAdminsList.includes(p.id.toLowerCase()) ||
        superAdminsList.includes(p.username.toLowerCase());
      const effectiveRole = isSuper ? "admin" : (roleMap.get(p.id) ?? "user");
      const defaultPerms = getDefaultPermissionsForRole(
        effectiveRole as "admin" | "team_leader" | "user",
        isSuper,
      );
      const userPerms = isSuper
        ? defaultPerms
        : { ...defaultPerms, ...(allSavedPerms[p.id] ?? {}) };

      return {
        id: p.id,
        username: p.username,
        active: p.active ?? true,
        role: effectiveRole,
        is_super_admin: isSuper,
        team_leader_id: p.team_leader_id as string | null,
        factory_id: p.factory_id as string | null,
        permissions: userPerms,
        created_at: p.created_at,
      };
    });
  });

// ============================================================
// FACTORIES
// ============================================================

export const listFactories = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("factories")
      .select("id, name, created_at")
      .order("name", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const factoryNameSchema = z.object({ name: z.string().trim().min(1).max(80) });

export const createFactory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => factoryNameSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("factories")
      .insert({ name: data.name.trim() })
      .select("id, name")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

const renameFactorySchema = z.object({
  id: z.string().uuid(),
  name: z.string().trim().min(1).max(80),
});

export const renameFactory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => renameFactorySchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("factories")
      .update({ name: data.name.trim() })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const deleteFactorySchema = z.object({ id: z.string().uuid() });

export const deleteFactory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => deleteFactorySchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Clear factory references from profiles and plans before deleting factory
    await supabaseAdmin.from("profiles").update({ factory_id: null }).eq("factory_id", data.id);
    await supabaseAdmin.from("plans").update({ factory_id: null }).eq("factory_id", data.id);
    const { error } = await supabaseAdmin.from("factories").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const setUserFactorySchema = z.object({
  userId: z.string().uuid(),
  factoryId: z.string().uuid().nullable().optional(),
});

export const setUserFactory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => setUserFactorySchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ factory_id: data.factoryId ?? null })
      .eq("id", data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// --- Create user ---
const createSchema = z.object({
  username: z.string().trim().min(2).max(50),
  password: z.string().min(6).max(200),
  role: z.enum(["admin", "team_leader", "user"]),
  teamLeaderId: z.string().uuid().nullable().optional(),
  factoryId: z.string().uuid().nullable().optional(),
  permissions: z.record(z.boolean()).optional(),
});

export const createAppUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => createSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const username = data.username.trim().toLowerCase();
    const email = username.includes("@") ? username : `${username}@${EMAIL_DOMAIN}`;

    // Validate team leader when role is 'user'
    if (data.role === "user") {
      if (!data.teamLeaderId) {
        throw new Error("User-এর জন্য Team Leader নির্বাচন করুন।");
      }
      const tlRole = await pickTopRole(context.supabase, data.teamLeaderId);
      if (tlRole !== "team_leader" && tlRole !== "admin") {
        throw new Error("নির্বাচিত ব্যবহারকারী Team Leader নন।");
      }
    }

    let newUserId: string;
    try {
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: data.password,
        email_confirm: true,
        user_metadata: { username },
      });
      if (error || !created?.user) throw error || new Error("Admin createUser failed");
      newUserId = created.user.id;
    } catch {
      // Fallback: use client signUp with ephemeral client
      const { createClient } = await import("@supabase/supabase-js");
      const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
      const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
      const ephemeral = createClient(url!, key!, {
        auth: { persistSession: false, autoRefreshToken: false },
      });
      const { data: created, error } = await ephemeral.auth.signUp({
        email,
        password: data.password,
        options: { data: { username } },
      });
      if (error || !created?.user) {
        throw new Error(error?.message ?? "ব্যবহারকারী তৈরি ব্যর্থ হয়েছে।");
      }
      newUserId = created.user.id;
    }

    // Set role
    try {
      await supabaseAdmin.from("user_roles").delete().eq("user_id", newUserId);
      await supabaseAdmin.from("user_roles").insert({ user_id: newUserId, role: data.role });
    } catch {
      await context.supabase.from("user_roles").delete().eq("user_id", newUserId);
      await context.supabase.from("user_roles").insert({ user_id: newUserId, role: data.role });
    }

    // Update profile
    const profilePayload = {
      id: newUserId,
      username,
      active: true,
      team_leader_id: data.role === "user" ? (data.teamLeaderId ?? null) : null,
      factory_id: data.factoryId ?? null,
    };
    try {
      await supabaseAdmin.from("profiles").upsert(profilePayload, { onConflict: "id" });
    } catch {
      await context.supabase.from("profiles").upsert(profilePayload, { onConflict: "id" });
    }

    // Save permissions
    const perms =
      data.permissions ??
      getDefaultPermissionsForRole(data.role, isSuperAdminUser(email, username));
    const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
    const diskPerms = await loadPermissionsFromDisk();
    diskPerms[newUserId] = perms;
    await savePermissionsToDisk(diskPerms);

    return { id: newUserId, username };
  });

// --- Delete user ---
const deleteSchema = z.object({ userId: z.string().uuid() });

export const deleteAppUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => deleteSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    if (data.userId === context.userId) {
      throw new Error("নিজেকে ডিলিট করা যাবে না।");
    }

    // Check if target is Primary Root Super Admin
    const { data: targetProf } = await context.supabase
      .from("profiles")
      .select("username")
      .eq("id", data.userId)
      .maybeSingle();
    const uname = (targetProf?.username ?? "").toLowerCase();
    if (uname === "akterplanning83" || uname === SUPER_ADMIN_EMAIL.toLowerCase()) {
      throw new Error("মূল সুপার অ্যাডমিন (akterplanning83)-কে ডিলিট করা সম্ভব নয়।");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // 1. Unassign subordinates
    await supabaseAdmin
      .from("profiles")
      .update({ team_leader_id: null })
      .eq("team_leader_id", data.userId);

    // 2. Reassign plans
    await supabaseAdmin
      .from("plans")
      .update({ created_by: context.userId })
      .eq("created_by", data.userId);

    // 3. Clear TL from plans
    await supabaseAdmin
      .from("plans")
      .update({ team_leader_id: null })
      .eq("team_leader_id", data.userId);

    // 4. Delete user roles & profile
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    await supabaseAdmin.from("profiles").delete().eq("id", data.userId);

    // 5. Clean up permissions on disk
    const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
    const diskPerms = await loadPermissionsFromDisk();
    delete diskPerms[data.userId];
    await savePermissionsToDisk(diskPerms);

    // 6. Delete auth user
    try {
      await supabaseAdmin.auth.admin.deleteUser(data.userId);
    } catch {
      /* ignore if service key unavailable */
    }
    return { ok: true };
  });

// --- Reset password ---
const resetSchema = z.object({
  userId: z.string().uuid(),
  password: z.string().min(6).max(200),
});

export const resetAppUserPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => resetSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      password: data.password,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// --- Set active/blocked status ---
const setUserActiveSchema = z.object({
  userId: z.string().uuid(),
  active: z.boolean(),
});

export const setUserActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => setUserActiveSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    if (data.userId === context.userId) {
      throw new Error("নিজের অ্যাক্টিভ স্ট্যাটাস পরিবর্তন করা যাবে না।");
    }

    const { data: targetProf } = await context.supabase
      .from("profiles")
      .select("username")
      .eq("id", data.userId)
      .maybeSingle();
    const uname = (targetProf?.username ?? "").toLowerCase();
    if (uname === "akterplanning83" || uname === SUPER_ADMIN_EMAIL.toLowerCase()) {
      throw new Error("মূল সুপার অ্যাডমিনকে ব্লক করা যাবে না।");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ active: data.active })
      .eq("id", data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// --- System Lock ---
const setSystemLockSchema = z.object({
  locked: z.boolean(),
});

export const setSystemLocked = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => setSystemLockSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("system_settings")
      .upsert({ id: 1, locked: data.locked }, { onConflict: "id" });
    if (error) throw new Error(error.message);
    return { ok: true, locked: data.locked };
  });

// --- Set user role ---
const setRoleSchema = z.object({
  userId: z.string().uuid(),
  role: z.enum(["admin", "team_leader", "user"]),
});

export const setAppUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => setRoleSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);

    const { data: targetProf } = await context.supabase
      .from("profiles")
      .select("username")
      .eq("id", data.userId)
      .maybeSingle();
    const uname = (targetProf?.username ?? "").toLowerCase();
    if (
      (uname === "akterplanning83" || uname === SUPER_ADMIN_EMAIL.toLowerCase()) &&
      data.role !== "admin"
    ) {
      throw new Error("মূল সুপার অ্যাডমিনের রোল পরিবর্তন করা যাবে না।");
    }

    if (data.userId === context.userId && data.role !== "admin") {
      throw new Error("নিজের অ্যাডমিন রোল সরানো যাবে না।");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // If role changed to non-admin, remove from super admins list if present
    if (data.role !== "admin") {
      const { loadSuperAdminsFromDisk, saveSuperAdminsToDisk } = await getStorage();
      const superList = await loadSuperAdminsFromDisk();
      const filtered = superList.filter(
        (s) => s.toLowerCase() !== data.userId.toLowerCase() && s.toLowerCase() !== uname,
      );
      await saveSuperAdminsToDisk(filtered);
    }

    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    const { error } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: data.userId, role: data.role });
    if (error) throw new Error(error.message);

    if (data.role !== "user") {
      await supabaseAdmin.from("profiles").update({ team_leader_id: null }).eq("id", data.userId);
    }

    if (data.role !== "team_leader" && data.role !== "admin") {
      await supabaseAdmin
        .from("profiles")
        .update({ team_leader_id: null })
        .eq("team_leader_id", data.userId);
    }

    return { ok: true };
  });

// --- Set user's team leader ---
const setTeamLeaderSchema = z.object({
  userId: z.string().uuid(),
  teamLeaderId: z.string().uuid().nullable().optional(),
});

export const setUserTeamLeader = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => setTeamLeaderSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    if (data.userId === data.teamLeaderId) {
      throw new Error("একজন ব্যবহারকারী নিজেই নিজের Team Leader হতে পারবেন না।");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (data.teamLeaderId) {
      const tlRole = await pickTopRole(context.supabase, data.teamLeaderId);
      if (tlRole !== "team_leader" && tlRole !== "admin") {
        throw new Error("নির্বাচিত ব্যবহারকারী Team Leader নন।");
      }
    }

    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ team_leader_id: data.teamLeaderId ?? null })
      .eq("id", data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============================================================
// WORK PERMISSIONS MANAGEMENT
// ============================================================

const savePermissionsSchema = z.object({
  userId: z.string().uuid(),
  permissions: z.record(z.boolean()),
});

export const saveUserPermissions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => savePermissionsSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);

    const { data: targetProf } = await context.supabase
      .from("profiles")
      .select("username")
      .eq("id", data.userId)
      .maybeSingle();

    if (isSuperAdminUser(targetProf?.username, targetProf?.username)) {
      throw new Error("সুপার অ্যাডমিনের পারমিশন সর্বদা শতভাগ উন্মুক্ত।");
    }

    const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
    const diskPerms = await loadPermissionsFromDisk();
    diskPerms[data.userId] = data.permissions;
    await savePermissionsToDisk(diskPerms);

    return { ok: true, permissions: data.permissions };
  });

export const getUserPermissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { loadPermissionsFromDisk } = await getStorage();
    return loadPermissionsFromDisk();
  });

const bulkPermissionsSchema = z.object({
  userIds: z.array(z.string().uuid()),
  permissions: z.record(z.boolean()),
});

export const applyBulkPermissions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => bulkPermissionsSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { loadPermissionsFromDisk, savePermissionsToDisk } = await getStorage();
    const diskPerms = await loadPermissionsFromDisk();
    for (const uid of data.userIds) {
      diskPerms[uid] = { ...data.permissions };
    }
    await savePermissionsToDisk(diskPerms);
    return { ok: true, count: data.userIds.length };
  });

// ============================================================
// DYNAMIC SUPER ADMIN MANAGEMENT (GRANT & REVOKE)
// ============================================================

const grantSuperAdminSchema = z.object({
  userId: z.string().uuid(),
});

export const grantSuperAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => grantSuperAdminSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Fetch user profile
    const { data: prof } = await context.supabase
      .from("profiles")
      .select("username")
      .eq("id", data.userId)
      .maybeSingle();

    const username = prof?.username ?? data.userId;

    // 1. Add to super admins list
    const {
      loadSuperAdminsFromDisk,
      saveSuperAdminsToDisk,
      loadPermissionsFromDisk,
      savePermissionsToDisk,
    } = await getStorage();
    const list = await loadSuperAdminsFromDisk();
    const set = new Set(list.map((s) => s.toLowerCase()));
    set.add(data.userId.toLowerCase());
    if (prof?.username) set.add(prof.username.toLowerCase());
    await saveSuperAdminsToDisk(Array.from(set));

    // 2. Set admin role in user_roles
    try {
      await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: data.userId, role: "admin" }, { onConflict: "user_id,role" });
    } catch {
      await context.supabase
        .from("user_roles")
        .upsert({ user_id: data.userId, role: "admin" }, { onConflict: "user_id,role" });
    }

    // 3. Grant 100% full permissions in work_permissions.json
    const diskPerms = await loadPermissionsFromDisk();
    const { PERMISSION_PRESETS } = await import("@/lib/permissions.types");
    diskPerms[data.userId] = { ...PERMISSION_PRESETS.super_admin.permissions };
    await savePermissionsToDisk(diskPerms);

    return { ok: true, userId: data.userId, username, is_super_admin: true };
  });

const revokeSuperAdminSchema = z.object({
  userId: z.string().uuid(),
  newRole: z.enum(["admin", "team_leader", "user"]).optional().default("admin"),
});

export const revokeSuperAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => revokeSuperAdminSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: prof } = await context.supabase
      .from("profiles")
      .select("username")
      .eq("id", data.userId)
      .maybeSingle();

    const username = (prof?.username ?? "").toLowerCase();

    // Prevent revoking root default super admin unless authorized
    if (
      (username === "akterplanning83" || username === SUPER_ADMIN_EMAIL.toLowerCase()) &&
      context.userId !== data.userId
    ) {
      throw new Error("মূল সুপার অ্যাডমিন (akterplanning83)-কে পরিবর্তন করা যাবে না।");
    }

    // 1. Remove from super admins list
    const {
      loadSuperAdminsFromDisk,
      writeSuperAdminsDirect,
      loadPermissionsFromDisk,
      savePermissionsToDisk,
    } = await getStorage();
    const list = await loadSuperAdminsFromDisk();
    const filtered = list.filter(
      (s) => s.toLowerCase() !== data.userId.toLowerCase() && s.toLowerCase() !== username,
    );
    const set = new Set(filtered.map((s) => s.toLowerCase().trim()));
    if (username !== "akterplanning83" && username !== SUPER_ADMIN_EMAIL.toLowerCase()) {
      set.add(SUPER_ADMIN_EMAIL.toLowerCase());
      set.add("akterplanning83");
    }
    await writeSuperAdminsDirect(Array.from(set));

    // 2. Set new role if provided
    if (data.newRole) {
      try {
        await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
        await supabaseAdmin.from("user_roles").insert({ user_id: data.userId, role: data.newRole });
      } catch {
        await context.supabase.from("user_roles").delete().eq("user_id", data.userId);
        await context.supabase
          .from("user_roles")
          .insert({ user_id: data.userId, role: data.newRole });
      }
    }

    // 3. Update permissions to preset or default for newRole
    const diskPerms = await loadPermissionsFromDisk();
    diskPerms[data.userId] = getDefaultPermissionsForRole(data.newRole || "admin", false);
    await savePermissionsToDisk(diskPerms);

    return {
      ok: true,
      userId: data.userId,
      username: prof?.username,
      is_super_admin: false,
      role: data.newRole,
    };
  });

export const listSuperAdmins = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId, context.claims);
    const { loadSuperAdminsFromDisk } = await getStorage();
    return loadSuperAdminsFromDisk();
  });
