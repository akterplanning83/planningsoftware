// Pure port of the original calculateAndAddPlan() logic from the source HTML.
// Zero DOM access — takes typed input, returns typed result.

export type LineInput = {
  id: number;
  name: string;
  startDateStr: string; // YYYY-MM-DD
  allocatedOrderQty: number;
  applyLC: boolean;
  chainAuto?: boolean; // when true (default), start auto-shifts after upstream style on same line
  /** Exceptional per-line daily target for this style. Overrides the default (SMV) target.
   *  Date-range target adjustments still win over this value. */
  targetOverride?: number | null;
};

export type TargetAdjustment = {
  id: number;
  lineName: string;
  fromDate: string;
  toDate: string;
  newTarget: number;
};

export type PlanInput = {
  buyer: string;
  style: string;
  orderQty: number;
  excessPct: number;
  dailyTargetPerLine: number;
  shipmentDate: string;
  lines: LineInput[];
  customHolidays: string[];
  targetAdjustments: TargetAdjustment[];
  targetAdjustmentsEnabled: boolean;
  // Optional custom learning curve as percentages (0-100) for day 1, day 2, day 3, ...
  // From day (length+1) onwards, 100% is used. Falsy / empty => default [20, 40, 60].
  learningCurve?: number[];
};

export const DEFAULT_LEARNING_CURVE = [20, 40, 60];

export type LineResult = LineInput & {
  plannedQty: number;
  workingDays: number;
  finishDateStr: string;
  dailyProduction: Array<{ date: string; qty: number }>;
};

export type MonthlyBreakdown = Record<string, { days: number; qty: number }>;

export type PlanResult = {
  buyer: string;
  style: string;
  orderQty: number;
  excessPct: number;
  totalPlannedQty: number;
  dailyTargetPerLine: number;
  hasLineAllocation: boolean;
  lines: LineResult[];
  totalLineDaysSum: number;
  targetAdjustments: TargetAdjustment[];
  finishDate: string;
  shipmentDate: string;
  isDelayed: boolean;
  monthlyBreakdown: MonthlyBreakdown;
  customHolidays: string[];
};

export function getLocalDateStr(d: Date): string {
  return (
    d.getFullYear() +
    "-" +
    String(d.getMonth() + 1).padStart(2, "0") +
    "-" +
    String(d.getDate()).padStart(2, "0")
  );
}

function getEffectiveTarget(
  lineName: string,
  dateStr: string,
  baseTarget: number,
  enabled: boolean,
  adjustments: TargetAdjustment[],
): number {
  if (!enabled) return baseTarget;
  const adj = adjustments.find(
    (a) => a.lineName === lineName && dateStr >= a.fromDate && dateStr <= a.toDate,
  );
  return adj ? adj.newTarget : baseTarget;
}

function lineBaseTarget(line: { targetOverride?: number | null }, fallback: number): number {
  const o = Number(line.targetOverride);
  return isFinite(o) && o > 0 ? o : fallback;
}

function lcFactor(applyLC: boolean, workingDays: number, curve?: number[]): number {
  if (!applyLC) return 1.0;
  const c = curve && curve.length > 0 ? curve : DEFAULT_LEARNING_CURVE;
  const idx = workingDays - 1;
  if (idx < 0) return 1.0;
  if (idx >= c.length) return 1.0;
  const pct = Number(c[idx]);
  if (!isFinite(pct) || pct <= 0) return 1.0;
  return Math.max(0, Math.min(100, pct)) / 100;
}

export type AllocationSource = "manual" | "range" | "auto" | "none";

export type DerivedAllocation = {
  name: string;
  /** share of the order qty (excess NOT included) */
  alloc: number;
  /** qty actually produced on this line = alloc + excess%, capped by total order+excess */
  planQty: number;
  source: AllocationSource;
  /** working days available from date-range targets (only for source === "range") */
  rangeDays?: number;
  /** full capacity of the date range (days × target) before capping */
  rangeCapacity?: number;
  /** true when the range capacity is bigger than the qty left to plan (finishes early) */
  finishesEarly?: boolean;
};

function isWorkingDay(dateStr: string, holidays: string[]): boolean {
  const d = new Date(dateStr);
  return d.getDay() !== 5 && !holidays.includes(dateStr);
}

/** Working-day count between two YYYY-MM-DD dates (inclusive), skipping Fridays + holidays. */
export function countWorkingDays(
  fromDate: string,
  toDate: string,
  holidays: string[] = [],
): number {
  if (!fromDate || !toDate) return 0;
  const end = new Date(toDate);
  const cur = new Date(fromDate);
  let n = 0;
  let guard = 0;
  while (cur <= end && guard++ < 5000) {
    const ds = getLocalDateStr(cur);
    if (isWorkingDay(ds, holidays)) n++;
    cur.setDate(cur.getDate() + 1);
  }
  return n;
}

/**
 * Resolves how much each line produces. The grand total NEVER exceeds
 * order qty + excess% — that is the whole quantity to be planned.
 * Priority order:
 *  1. `manual` — the user typed an allocation qty (used as-is, NO excess added)
 *  2. `range`  — date-range targets give a capacity (working days × target),
 *                but it is capped at whatever qty is still left to plan, so a
 *                big range simply finishes early instead of over-planning.
 *  3. `auto`   — the remaining qty split evenly across the leftover lines
 * Anything that still can't be placed stays unplanned (warned in the UI).
 */
export function deriveLineAllocations(args: {
  lines: Pick<LineInput, "name" | "allocatedOrderQty">[];
  orderQty: number;
  excessPct?: number;
  targetAdjustments?: TargetAdjustment[];
  targetAdjustmentsEnabled?: boolean;
  holidays?: string[];
}): DerivedAllocation[] {
  const { lines } = args;
  const holidays = args.holidays ?? [];
  const adjustments = args.targetAdjustmentsEnabled ? (args.targetAdjustments ?? []) : [];
  const orderQty = Number(args.orderQty) || 0;
  const factor = 1 + (Number(args.excessPct) || 0) / 100;
  const totalPlan = Math.round(orderQty * factor);
  const toAlloc = (planQty: number) => (factor > 0 ? Math.round(planQty / factor) : planQty);

  const rows: DerivedAllocation[] = lines.map((l) => ({
    name: l.name,
    alloc: 0,
    planQty: 0,
    source: "none" as AllocationSource,
  }));

  let remaining = totalPlan;

  // 1) manual allocations — taken exactly as typed, NO excess added
  lines.forEach((l, i) => {
    const manual = Number(l.allocatedOrderQty) || 0;
    if (manual <= 0) return;
    const give = Math.max(0, Math.min(manual, remaining));
    remaining -= give;
    rows[i] = { name: l.name, alloc: give, planQty: give, source: "manual" };
  });

  // 2) date-range capacity, capped at what is still left to plan
  lines.forEach((l, i) => {
    if (rows[i].source !== "none") return;
    const mine = adjustments.filter((a) => a.lineName === l.name && a.fromDate && a.toDate);
    if (mine.length === 0) return;
    let capacity = 0;
    let days = 0;
    for (const a of mine) {
      const d = countWorkingDays(a.fromDate, a.toDate, holidays);
      days += d;
      capacity += d * (Number(a.newTarget) || 0);
    }
    if (capacity <= 0) return;
    const give = Math.max(0, Math.min(capacity, remaining));
    remaining -= give;
    rows[i] = {
      name: l.name,
      alloc: toAlloc(give),
      planQty: give,
      source: "range",
      rangeDays: days,
      rangeCapacity: capacity,
      finishesEarly: capacity > give,
    };
  });

  // 3) auto-split whatever is left across untouched lines
  const openIdx = rows.map((r, i) => (r.source === "none" ? i : -1)).filter((i) => i >= 0);
  if (openIdx.length > 0 && remaining > 0) {
    const per = Math.floor(remaining / openIdx.length);
    let leftover = remaining - per * openIdx.length;
    for (const i of openIdx) {
      const extra = leftover > 0 ? 1 : 0;
      leftover -= extra;
      const give = per + extra;
      rows[i] = { name: rows[i].name, alloc: toAlloc(give), planQty: give, source: "auto" };
    }
    remaining = 0;
  }

  return rows;
}

export function calculatePlan(input: PlanInput): PlanResult {
  const {
    buyer,
    style,
    excessPct,
    dailyTargetPerLine,
    shipmentDate,
    customHolidays,
    targetAdjustments,
    targetAdjustmentsEnabled,
    learningCurve,
  } = input;

  const orderQty = Math.max(0, Number(input.orderQty) || 0);
  const factor = 1 + (Number(excessPct) || 0) / 100;
  const totalPlannedQty = Math.round(orderQty * factor);

  const workingLines = input.lines.map((l) => ({ ...l }));
  const hasPositiveTarget =
    dailyTargetPerLine > 0 ||
    workingLines.some((l) => (Number(l.targetOverride) || 0) > 0) ||
    (targetAdjustmentsEnabled && (targetAdjustments ?? []).some((a) => a.newTarget > 0));

  if (totalPlannedQty <= 0 || !hasPositiveTarget) {
    const lines: LineResult[] = workingLines.map((l) => ({
      ...l,
      plannedQty: 0,
      workingDays: 0,
      finishDateStr: l.startDateStr,
      dailyProduction: [],
    }));
    return {
      buyer,
      style,
      orderQty,
      excessPct,
      totalPlannedQty: 0,
      dailyTargetPerLine,
      hasLineAllocation: true,
      lines,
      totalLineDaysSum: 0,
      targetAdjustments: targetAdjustmentsEnabled ? [...targetAdjustments] : [],
      finishDate: lines[0]?.startDateStr || shipmentDate,
      shipmentDate,
      isDelayed: false,
      monthlyBreakdown: {},
      customHolidays: [...customHolidays],
    };
  }

  // Balance multi-line allocation based on "open space" (capacity)
  // while keeping manual allocations as-is.
  if (workingLines.length > 1) {
    let manualSum = 0;
    const autoIndices: number[] = [];
    const lineCaps: number[] = [];
    let totalAutoCap = 0;

    workingLines.forEach((l, i) => {
      const manual = Number(l.allocatedOrderQty) || 0;
      const base = lineBaseTarget(l, dailyTargetPerLine);
      if (manual > 0) {
        manualSum += manual;
      } else {
        autoIndices.push(i);
        totalAutoCap += base;
      }
      lineCaps.push(base);
    });

    const remainingToAllocate = Math.max(0, totalPlannedQty - manualSum);

    if (autoIndices.length > 0 && remainingToAllocate > 0) {
      let allocatedTotal = 0;
      autoIndices.forEach((idx, i) => {
        const l = workingLines[idx];
        const isLast = i === autoIndices.length - 1;
        const share = isLast
          ? remainingToAllocate - allocatedTotal
          : Math.round((lineCaps[idx] / totalAutoCap) * remainingToAllocate);
        l.allocatedOrderQty = share;
        allocatedTotal += share;
      });
    }
  }

  // Resolve allocations (respects what we just set above)
  const derived = deriveLineAllocations({
    lines: workingLines,
    orderQty,
    excessPct,
    targetAdjustments,
    targetAdjustmentsEnabled,
    holidays: customHolidays,
  });

  workingLines.forEach((l, i) => {
    l.allocatedOrderQty = derived[i]?.alloc ?? l.allocatedOrderQty;
  });

  const lines: LineResult[] = workingLines.map((l, i) => ({
    ...l,
    plannedQty: derived[i]?.planQty ?? 0,
    workingDays: 0,
    finishDateStr: "",
    dailyProduction: [],
  }));

  const hasLineAllocation = true;

  const monthlyBreakdown: MonthlyBreakdown = {};
  const startMs = Math.min(...lines.map((l) => new Date(l.startDateStr).getTime()));
  let maxFinishDate = new Date(startMs);

  const bumpMonth = (dateStr: string, dateObj: Date, qty: number) => {
    const monthYear = dateObj.toLocaleString("en-US", { month: "short", year: "numeric" });
    if (!monthlyBreakdown[monthYear]) monthlyBreakdown[monthYear] = { days: 0, qty: 0 };
    monthlyBreakdown[monthYear].qty += qty;
    monthlyBreakdown[monthYear].days += 1;
    void dateStr;
  };

  if (hasLineAllocation) {
    for (const line of lines) {
      if (line.plannedQty <= 0) {
        line.finishDateStr = line.startDateStr;
        continue;
      }
      const cursor = new Date(line.startDateStr);
      let remaining = line.plannedQty;
      let guard = 0;
      let consecutiveZeroDays = 0;
      while (remaining > 0 && guard++ < 3650) {
        const dateStr = getLocalDateStr(cursor);
        if (cursor.getDay() === 5 || customHolidays.includes(dateStr)) {
          cursor.setDate(cursor.getDate() + 1);
          continue;
        }
        const base = getEffectiveTarget(
          line.name,
          dateStr,
          lineBaseTarget(line, dailyTargetPerLine),
          targetAdjustmentsEnabled,
          targetAdjustments,
        );
        const eff = lcFactor(line.applyLC, line.workingDays + 1, learningCurve);
        const todayProd = Math.min(remaining, Math.round(base * eff));
        if (todayProd > 0) {
          consecutiveZeroDays = 0;
          line.workingDays++;
          bumpMonth(dateStr, cursor, todayProd);
          line.dailyProduction.push({ date: dateStr, qty: todayProd });
          remaining -= todayProd;
        } else {
          consecutiveZeroDays++;
          if (consecutiveZeroDays > 365) break;
        }
        if (remaining > 0) cursor.setDate(cursor.getDate() + 1);
      }
      line.finishDateStr = getLocalDateStr(cursor);
      if (cursor > maxFinishDate) maxFinishDate = new Date(cursor);
    }
  } else {
    const cursor = new Date(startMs);
    let remaining = totalPlannedQty;
    let guard = 0;
    let consecutiveZeroDays = 0;
    while (remaining > 0 && guard++ < 3650) {
      const dateStr = getLocalDateStr(cursor);
      if (cursor.getDay() === 5 || customHolidays.includes(dateStr)) {
        cursor.setDate(cursor.getDate() + 1);
        continue;
      }
      let prodTodaySum = 0;
      for (const line of lines) {
        if (cursor >= new Date(line.startDateStr) && remaining > 0) {
          const base = getEffectiveTarget(
            line.name,
            dateStr,
            lineBaseTarget(line, dailyTargetPerLine),
            targetAdjustmentsEnabled,
            targetAdjustments,
          );
          const eff = lcFactor(line.applyLC, line.workingDays + 1, learningCurve);
          const cap = Math.round(base * eff);
          const actual = Math.min(remaining, cap);
          if (actual > 0) {
            line.workingDays++;
            bumpMonth(dateStr, cursor, actual);
            line.dailyProduction.push({ date: dateStr, qty: actual });
            remaining -= actual;
            prodTodaySum += actual;
          }
        }
      }
      if (prodTodaySum > 0) {
        consecutiveZeroDays = 0;
      } else {
        consecutiveZeroDays++;
        if (consecutiveZeroDays > 365) break;
      }
      if (remaining > 0) cursor.setDate(cursor.getDate() + 1);
    }
    maxFinishDate = new Date(cursor);
    for (const l of lines) l.finishDateStr = getLocalDateStr(maxFinishDate);
  }

  const totalLineDaysSum = lines.reduce((s, l) => s + l.workingDays, 0);
  const finishDate = getLocalDateStr(maxFinishDate);

  return {
    buyer,
    style,
    orderQty,
    excessPct,
    totalPlannedQty,
    dailyTargetPerLine,
    hasLineAllocation,
    lines,
    totalLineDaysSum,
    targetAdjustments: targetAdjustmentsEnabled ? [...targetAdjustments] : [],
    finishDate,
    shipmentDate,
    isDelayed: new Date(finishDate) > new Date(shipmentDate),
    monthlyBreakdown,
    customHolidays: [...customHolidays],
  };
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "2-digit" });
}

// Given a "last working day" string, return the next available working day
// (skipping Fridays and holidays).
export function nextWorkingDay(lastDateStr: string, holidays: string[] = []): string {
  if (!lastDateStr) return lastDateStr;
  const d = new Date(lastDateStr);
  d.setDate(d.getDate() + 1);
  const set = new Set(holidays);
  let guard = 0;
  while ((d.getDay() === 5 || set.has(getLocalDateStr(d))) && guard++ < 1000) {
    d.setDate(d.getDate() + 1);
  }
  return getLocalDateStr(d);
}
