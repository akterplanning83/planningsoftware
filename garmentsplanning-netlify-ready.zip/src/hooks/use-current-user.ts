import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  SUPER_ADMIN_EMAIL,
  isSuperAdminUser,
  getDefaultPermissionsForRole,
} from "@/lib/permissions.types";

export type AppRole = "admin" | "team_leader" | "user";

export interface CurrentUser {
  id: string;
  email: string;
  username: string;
  active: boolean;
  role: AppRole;
  isSuperAdmin: boolean;
  factoryId: string | null;
  factoryName: string | null;
  teamLeaderId: string | null;
  permissions: Record<string, boolean>;
  hasPermission: (key: string) => boolean;
}

function pickRole(rows: { role: string }[] | null | undefined, isSuperAdmin: boolean): AppRole {
  if (isSuperAdmin) return "admin";
  const set = new Set((rows ?? []).map((r) => r.role));
  if (set.has("admin")) return "admin";
  if (set.has("team_leader")) return "team_leader";
  return "user";
}

export function useCurrentUser() {
  return useQuery({
    queryKey: ["current-user"],
    queryFn: async (): Promise<CurrentUser | null> => {
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user) return null;

      const userEmail = user.email ?? "";
      const rawUsername =
        user.user_metadata?.username ?? (userEmail ? userEmail.split("@")[0] : "");

      let localSuperList: string[] = [];
      try {
        const raw = localStorage.getItem("cg_super_admins");
        if (raw) localSuperList = JSON.parse(raw);
      } catch {
        /* ignore */
      }

      const isSuper =
        isSuperAdminUser(userEmail, rawUsername, localSuperList) ||
        localSuperList.includes(user.id.toLowerCase()) ||
        localSuperList.includes(rawUsername.toLowerCase()) ||
        (userEmail && localSuperList.includes(userEmail.toLowerCase()));

      const [{ data: profile }, { data: roleRows }] = await Promise.all([
        supabase
          .from("profiles")
          .select("username, active, team_leader_id, factory_id")
          .eq("id", user.id)
          .maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", user.id),
      ]);

      const effectiveRole = pickRole(roleRows, isSuper);
      const factoryId = (profile?.factory_id as string | null) ?? null;

      let factoryName: string | null = null;
      if (factoryId) {
        const { data: fData } = await supabase
          .from("factories")
          .select("name")
          .eq("id", factoryId)
          .maybeSingle();
        factoryName = fData?.name ?? null;
      }

      // Load permissions
      let savedPerms: Record<string, boolean> = {};
      try {
        const raw = localStorage.getItem(`cg_perms_${user.id}`);
        if (raw) savedPerms = JSON.parse(raw);
      } catch {
        /* ignore parse error */
      }

      const defaultPerms = getDefaultPermissionsForRole(effectiveRole, isSuper);
      const permissions = isSuper ? defaultPerms : { ...defaultPerms, ...savedPerms };

      const hasPermission = (key: string): boolean => {
        if (isSuper) return true;
        if (effectiveRole === "admin") return true;
        return !!permissions[key];
      };

      return {
        id: user.id,
        email: userEmail,
        username: profile?.username ?? rawUsername,
        active: profile?.active ?? true,
        role: effectiveRole,
        isSuperAdmin: isSuper,
        factoryId,
        factoryName,
        teamLeaderId: profile?.team_leader_id ?? null,
        permissions,
        hasPermission,
      };
    },
    staleTime: 30_000,
  });
}
