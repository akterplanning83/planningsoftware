import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Loader2,
  Lock,
  User,
  Eye,
  EyeOff,
  Crown,
  Building2,
  Users,
  ShieldCheck,
  ClipboardList,
  Sparkles,
  CheckCircle2,
  HelpCircle,
  ShieldAlert,
  ArrowRight,
} from "lucide-react";
import { SUPER_ADMIN_EMAIL, isSuperAdminUser } from "@/lib/permissions.types";

export const Route = createFileRoute("/auth")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "লগইন — Cloud Garments ERP" },
      {
        name: "description",
        content: "Cloud Garments ERP সিস্টেমে ইউজারনেম বা ইমেইল দিয়ে লগইন করুন।",
      },
    ],
  }),
  component: AuthPage,
});

const emailFromUsername = (username: string) => {
  const v = username.trim().toLowerCase();
  return v.includes("@") ? v : `${v}@cloud-garments.local`;
};

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [busy, setBusy] = useState(false);
  const [systemLocked, setSystemLocked] = useState(false);
  const [checkingLock, setCheckingLock] = useState(true);
  const [firstUser, setFirstUser] = useState(false);

  // Check existing session
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/app", replace: true });
    });
  }, [navigate]);

  // Load remembered username & system lock status
  useEffect(() => {
    try {
      const savedUser = localStorage.getItem("cg_remember_user");
      if (savedUser) {
        setUsername(savedUser);
      }
    } catch {
      /* ignore */
    }

    (async () => {
      try {
        const { data } = await supabase
          .from("system_settings")
          .select("locked")
          .eq("id", 1)
          .maybeSingle();
        setSystemLocked(!!data?.locked);
        // detect whether any admin exists to hint at first-user signup
        const { count } = await supabase
          .from("user_roles")
          .select("*", { count: "exact", head: true })
          .eq("role", "admin");
        setFirstUser((count ?? 0) === 0);
      } catch {
        /* ignore */
      } finally {
        setCheckingLock(false);
      }
    })();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const cleanUser = username.trim();
    if (!cleanUser) {
      toast.error("অনুগ্রহ করে ইউজারনেম বা ইমেইল প্রদান করুন।");
      return;
    }
    if (!password) {
      toast.error("অনুগ্রহ করে পাসওয়ার্ড দিন।");
      return;
    }

    if (mode === "signup") {
      if (password.length < 6) {
        toast.error("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।");
        return;
      }
      if (password !== confirmPassword) {
        toast.error("পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।");
        return;
      }
    }

    // Save remember me
    try {
      if (rememberMe) {
        localStorage.setItem("cg_remember_user", cleanUser);
      } else {
        localStorage.removeItem("cg_remember_user");
      }
    } catch {
      /* ignore */
    }

    setBusy(true);
    try {
      const email = emailFromUsername(cleanUser);

      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { username: cleanUser },
            emailRedirectTo: window.location.origin,
          },
        });
        if (error) throw error;

        toast.success("অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে — সিস্টেমে প্রবেশ করা হচ্ছে…");
        navigate({ to: "/app", replace: true });
        return;
      }

      // Login mode
      const { error, data } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) {
        if (
          error.message.includes("Invalid login credentials") ||
          error.message.includes("invalid")
        ) {
          throw new Error("ইউজারনেম বা পাসওয়ার্ড সঠিক নয়। পুনরায় চেষ্টা করুন।");
        }
        throw error;
      }

      // Check profile.active & system lock
      const uid = data.user!.id;
      const userEmail = data.user!.email ?? "";

      const [{ data: profile }, { data: roleRow }] = await Promise.all([
        supabase.from("profiles").select("username, active").eq("id", uid).maybeSingle(),
        supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", uid)
          .eq("role", "admin")
          .maybeSingle(),
      ]);

      // Check dynamic super admins list
      let localSuperList: string[] = [];
      try {
        const raw = localStorage.getItem("cg_super_admins");
        if (raw) localSuperList = JSON.parse(raw);
      } catch {
        /* ignore */
      }

      const isSuper =
        isSuperAdminUser(userEmail, cleanUser, localSuperList) ||
        isSuperAdminUser(userEmail, profile?.username, localSuperList) ||
        localSuperList.includes(uid.toLowerCase()) ||
        localSuperList.includes(cleanUser.toLowerCase());

      const isAdmin = !!roleRow || isSuper;

      if (isSuper) {
        try {
          await supabase
            .from("user_roles")
            .upsert({ user_id: uid, role: "admin" }, { onConflict: "user_id,role" });
        } catch {
          /* ignore */
        }
      }

      if (!isSuper && profile && profile.active === false) {
        await supabase.auth.signOut();
        toast.error(
          "আপনার অ্যাকাউন্ট নিষ্ক্রিয় বা ব্লক করা হয়েছে। সুপার অ্যাডমিনের সাথে যোগাযোগ করুন।",
        );
        return;
      }

      if (systemLocked && !isAdmin) {
        await supabase.auth.signOut();
        toast.error("সিস্টেম বর্তমানে লক করা আছে। শুধুমাত্র অ্যাডমিন লগইন করতে পারবেন।");
        return;
      }

      toast.success(
        isSuper
          ? `👑 স্বাগতম সুপার অ্যাডমিন (${profile?.username ?? cleanUser})! পূর্ণ এক্সেস সক্রিয়।`
          : `স্বাগতম ${profile?.username ?? cleanUser}! লগইন সফল হয়েছে।`,
      );
      navigate({ to: "/app", replace: true });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  }

  const fillSuperAdmin = () => {
    setUsername(SUPER_ADMIN_EMAIL);
    toast.info("সুপার অ্যাডমিন ইমেইল প্রদান করা হয়েছে। আপনার পাসওয়ার্ড দিন।");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/70 text-slate-100">
      <div className="w-full max-w-lg rounded-3xl border border-indigo-500/30 bg-slate-950/85 backdrop-blur-2xl p-6 sm:p-8 shadow-2xl shadow-indigo-950/60 transition">
        {/* Header Branding */}
        <div className="text-center mb-6">
          <div className="inline-flex p-3 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-sky-600 text-white shadow-xl shadow-indigo-600/30 mb-3.5 ring-4 ring-indigo-500/20">
            <Crown className="w-7 h-7 text-amber-300" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-100 to-indigo-300">
            Cloud Garments ERP
          </h1>
          <p className="text-xs text-slate-400 mt-1.5 font-medium leading-relaxed">
            গার্মেন্টস প্ল্যানিং, মাল্টি-ফ্যাক্টরি লাইন কন্ট্রোল ও পারমিশন সিস্টেম
          </p>
        </div>

        {checkingLock ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3 text-slate-400 text-xs">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
            <span>সিস্টেম স্ট্যাটাস লোড হচ্ছে…</span>
          </div>
        ) : (
          <>
            {/* System Locked Alert */}
            {systemLocked && (
              <div className="mb-4 flex items-start gap-3 rounded-2xl border border-rose-500/40 bg-rose-500/10 p-3.5 text-xs text-rose-300">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="leading-snug">
                  <span className="font-bold">সিস্টেম মেইনটেন্যান্স মোডে রয়েছে:</span> বর্তমানে
                  সাধারণ ব্যবহারকারীদের প্রবেশ স্থগিত। শুধুমাত্র সুপার অ্যাডমিন ও অ্যাডমিন লগইন করতে
                  পারবেন।
                </div>
              </div>
            )}

            {/* Login / Signup Tabs */}
            <div className="mb-5 grid grid-cols-2 gap-1 rounded-2xl bg-slate-900/90 border border-slate-800 p-1.5 shadow-inner">
              <button
                type="button"
                onClick={() => setMode("login")}
                className={`rounded-xl py-2.5 text-xs font-black transition flex items-center justify-center gap-1.5 ${
                  mode === "login"
                    ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-indigo-600/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>লগইন (Sign In)</span>
              </button>
              <button
                type="button"
                onClick={() => setMode("signup")}
                className={`rounded-xl py-2.5 text-xs font-black transition flex items-center justify-center gap-1.5 ${
                  mode === "signup"
                    ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-indigo-600/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>নতুন অ্যাকাউন্ট (Sign Up)</span>
              </button>
            </div>

            {/* Super Admin Quick Fill & Permission Info Card */}
            <div className="mb-5 bg-gradient-to-r from-purple-950/50 via-indigo-950/40 to-slate-900/60 rounded-2xl border border-purple-500/30 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-1.5 rounded-xl bg-purple-500/20 text-purple-300 shrink-0">
                  <Crown className="w-4 h-4 text-amber-300" />
                </div>
                <div className="min-w-0">
                  <div className="text-[12px] font-black text-purple-200 truncate flex items-center gap-1.5">
                    <span>সুপার অ্যাডমিন এক্সেস</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/30 text-purple-200 border border-purple-400/30">
                      Master
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    সকল ইউজারকে সুপার অ্যাডমিন পারমিশন প্রদান ও বাতিল নিয়ন্ত্রণ
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={fillSuperAdmin}
                className="shrink-0 px-3 py-1.5 rounded-xl text-[11px] font-extrabold bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-400/40 transition active:scale-95 flex items-center justify-center gap-1"
                title="সুপার অ্যাডমিন ইমেইল পূরণ করুন"
              >
                <span>কুইক প্রি-ফিল</span>
                <ArrowRight className="w-3 h-3 text-purple-300" />
              </button>
            </div>

            {mode === "signup" && firstUser && (
              <div className="mb-4 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-xs text-emerald-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  🎉 আপনি প্রথম অ্যাকাউন্ট তৈরি করছেন — সাইন আপ সম্পন্ন হলে স্বয়ংক্রিয়ভাবে{" "}
                  <b>সুপার অ্যাডমিন</b> রোল সক্রিয় হবে।
                </span>
              </div>
            )}

            {/* Auth Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>ইউজারনেম বা ইমেইল</span>
                  <span className="text-[10px] text-slate-400 font-normal">Username / Email</span>
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="যেমন: akterplanning83 বা akterplanning83@gmail.com"
                    className="w-full rounded-xl border border-slate-700 bg-slate-900/90 pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>পাসওয়ার্ড</span>
                  <span className="text-[10px] text-slate-400 font-normal">Password</span>
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    autoComplete={mode === "signup" ? "new-password" : "current-password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-slate-700 bg-slate-900/90 pl-10 pr-10 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                    title={showPassword ? "পাসওয়ার্ড লুকান" : "পাসওয়ার্ড দেখুন"}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password (only for signup) */}
              {mode === "signup" && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                    <span>পাসওয়ার্ড নিশ্চিত করুন</span>
                    <span className="text-[10px] text-slate-400 font-normal">Confirm Password</span>
                  </label>
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showConfirmPassword ? "text" : "password"}
                      autoComplete="new-password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="পাসওয়ার্ড পুনরায় লিখুন"
                      className="w-full rounded-xl border border-slate-700 bg-slate-900/90 pl-10 pr-10 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword((v) => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                      title={showConfirmPassword ? "পাসওয়ার্ড লুকান" : "পাসওয়ার্ড দেখুন"}
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">
                    কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।
                  </p>
                </div>
              )}

              {/* Remember me & support info */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="inline-flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0"
                  />
                  <span>আমাকে মনে রাখুন</span>
                </label>
                <div className="text-[11px] text-slate-400 flex items-center gap-1">
                  <HelpCircle className="w-3 h-3 text-indigo-400" />
                  <span>পাসওয়ার্ড ভুলে গেলে অ্যাডমিনের সাথে যোগাযোগ করুন</span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-indigo-700 hover:from-purple-500 hover:to-indigo-500 py-3 text-xs font-black text-white shadow-lg shadow-indigo-600/30 transition active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
              >
                {busy ? (
                  <span className="inline-flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> প্রক্রিয়াধীন…
                  </span>
                ) : mode === "login" ? (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>লগইন করুন (Sign In)</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>নতুন অ্যাকাউন্ট তৈরি করুন (Sign Up)</span>
                  </>
                )}
              </button>
            </form>

            {/* ERP System Features Banner */}
            <div className="mt-6 pt-5 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80">
                <Building2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span className="truncate">মাল্টি-ফ্যাক্টরি হায়ারার্কি</span>
              </div>
              <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80">
                <Users className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span className="truncate">টিম লিডার ও প্ল্যানার রোল</span>
              </div>
              <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80">
                <Crown className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="truncate">সুপার অ্যাডমিন পারমিশন কন্ট্রোল</span>
              </div>
              <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/50 border border-slate-800/80">
                <ClipboardList className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">রিয়েলটাইম অডিট লগ</span>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
