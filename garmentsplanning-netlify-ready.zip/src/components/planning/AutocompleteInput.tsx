import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, History } from "lucide-react";

type Props = {
  value: string;
  onChange: (v: string) => void;
  suggestions: string[];
  placeholder?: string;
  className?: string;
  maxItems?: number;
  required?: boolean;
  disabled?: boolean;
  title?: string;
  autoFocus?: boolean;
};

export function AutocompleteInput({
  value,
  onChange,
  suggestions,
  placeholder,
  className,
  maxItems = 15,
  required,
  disabled,
  title,
  autoFocus,
}: Props) {
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Clean, unique, non-empty suggestions preserving input order
  const unique = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const s of suggestions) {
      const t = (s ?? "").trim();
      if (!t) continue;
      const k = t.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(t);
    }
    return out;
  }, [suggestions]);

  // Filtered based on query:
  // If query is empty: show all unique suggestions up to maxItems!
  // If query is present: show startsWith first, then includes!
  const filtered = useMemo(() => {
    const q = value.trim().toLowerCase();
    if (!q) {
      return unique.slice(0, maxItems);
    }
    const starts = unique.filter((s) => s.toLowerCase().startsWith(q));
    const contains = unique.filter(
      (s) => !s.toLowerCase().startsWith(q) && s.toLowerCase().includes(q),
    );
    return [...starts, ...contains].slice(0, maxItems);
  }, [value, unique, maxItems]);

  useEffect(() => {
    setHi(0);
  }, [filtered]);

  // Close when clicking outside
  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const show = open && filtered.length > 0;

  return (
    <div className="relative w-full" ref={wrapRef}>
      <div className="relative flex items-center">
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setOpen(true);
          }}
          onFocus={() => {
            if (unique.length > 0) {
              setOpen(true);
            }
          }}
          onClick={() => {
            if (unique.length > 0) {
              setOpen(true);
            }
          }}
          onKeyDown={(e) => {
            if (!show) {
              if ((e.key === "ArrowDown" || e.key === "ArrowUp") && unique.length > 0) {
                e.preventDefault();
                setOpen(true);
              }
              return;
            }
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setHi((i) => Math.min(i + 1, filtered.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setHi((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter" || e.key === "Tab") {
              if (filtered[hi] && e.key === "Enter") {
                e.preventDefault();
                onChange(filtered[hi]);
                setOpen(false);
              }
            } else if (e.key === "Escape") {
              setOpen(false);
            }
          }}
          placeholder={placeholder}
          className={`${className ?? ""} pr-7`}
          autoComplete="off"
          required={required}
          disabled={disabled}
          title={title}
          autoFocus={autoFocus}
        />

        {/* Dropdown toggle chevron button */}
        {unique.length > 0 && !disabled && (
          <button
            type="button"
            tabIndex={-1}
            onClick={() => {
              setOpen((prev) => !prev);
              if (!open) {
                inputRef.current?.focus();
              }
            }}
            className="absolute right-2 text-muted-foreground hover:text-foreground transition p-0.5 rounded cursor-pointer"
            title="পূর্ববর্তী এন্ট্রি তালিকা দেখুন"
          >
            <ChevronDown
              className={`w-3.5 h-3.5 transition-transform duration-150 ${
                open ? "rotate-180 text-foreground" : "opacity-70"
              }`}
            />
          </button>
        )}
      </div>

      {show && (
        <div className="absolute left-0 z-50 mt-1 w-full min-w-[200px] rounded-xl border border-border bg-panel shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-100">
          <div className="px-3 py-1.5 bg-panel-2/90 border-b border-border text-[10px] font-bold text-muted-foreground uppercase flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-amber-400">
              <History className="w-3 h-3" />
              পূর্ববর্তী এন্ট্রি
            </span>
            <span className="text-[9px] font-mono text-muted-foreground/80">
              {filtered.length} টি সাজেশন
            </span>
          </div>

          <div className="max-h-56 overflow-y-auto py-1 divide-y divide-border/20">
            {filtered.map((s, i) => {
              const isSelected = i === hi;
              const isCurrent = s.toLowerCase() === value.trim().toLowerCase();
              return (
                <button
                  type="button"
                  key={s}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    onChange(s);
                    setOpen(false);
                  }}
                  onMouseEnter={() => setHi(i)}
                  className={`w-full text-left px-3 py-2 text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                    isSelected
                      ? "bg-primary/20 text-primary-foreground font-bold"
                      : isCurrent
                        ? "bg-panel-2 text-foreground font-bold"
                        : "text-foreground/90 hover:bg-panel-2"
                  }`}
                >
                  <span className="truncate">{s}</span>
                  {isCurrent && (
                    <span className="text-[10px] text-emerald-400 font-bold ml-2">✓ বর্তমান</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
