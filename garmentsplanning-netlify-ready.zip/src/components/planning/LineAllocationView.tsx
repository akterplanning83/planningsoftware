import { useCallback, useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Layers,
  Search,
  RotateCcw,
  Save,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Clock,
  GripVertical,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
} from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import {
  formatDate,
  getLocalDateStr,
  nextWorkingDay,
  type LineInput,
  type PlanResult,
} from "@/lib/plan-calc";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  normLine,
  sortLineNamesByPreset,
  uniqueCanonicalLineNames,
} from "./lineLookup";
import { useGlobalHolidays } from "./HolidayCalendar";
import { buildPlanSnapshot } from "@/lib/plan-snapshot";
import { recomputePlan, type PlanRow } from "./planBoardSim";

export type TimeWindow = "current-month" | "next-month" | "next-30-days" | "next-60-days" | "all";

export type AllocationTask = {
  id: string; // unique key: planId + "::" + lineIndex
  planId: string;
  lineIndex: number;
  buyer: string;
  style: string;
  orderQty: number;
  plannedQty: number;
  dailyTarget: number;
  lineName: string; // canonical name (or "" if unallocated)
  rawLineName: string;
  startDateStr: string;
  finishDateStr: string;
  shipmentDate: string;
  isDelayed: boolean;
  workingDays: number;
  excessPct: number;
  fabricEta?: string | null;
  status: "unallocated" | "allocated";
  isDirty?: boolean;
};

export type LineCapacityInfo = {
  line: string; // canonical name
  workingDaysInWindow: number;
  dailyTargetCapacity: number;
  maxCapacityQty: number;
  allocatedQtyInWindow: number;
  totalAllocatedQty: number;
  utilizationPct: number;
  remainingQty: number;
  tasks: AllocationTask[];
  taskCount: number;
  status: "underloaded" | "optimal" | "warning" | "overloaded";
};

function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / 86_400_000);
}

function countWorkingDaysBetween(startStr: string, endStr: string, holidays: Set<string>): number {
  if (!startStr || !endStr || startStr > endStr) return 0;
  const cur = new Date(startStr);
  const end = new Date(endStr);
  let count = 0;
  let guard = 0;
  while (cur <= end && guard++ < 365) {
    const ds = getLocalDateStr(cur);
    if (cur.getDay() !== 5 && !holidays.has(ds)) {
      count++;
    }
    cur.setDate(cur.getDate() + 1);
  }
  return count;
}

export function LineAllocationView({ onSwitchTab }: { onSwitchTab?: (tab: string) => void }) {
  const qc = useQueryClient();
  const { presets: linePresets } = useLinePresets();
  const { data: globalHolidays = [] } = useGlobalHolidays();
  const holidaySet = useMemo(() => new Set(globalHolidays), [globalHolidays]);

  // Query plans
  const { data: rawPlans = [], isLoading } = useQuery({
    queryKey: ["plans", "allocation-board"],
    queryFn: async (): Promise<PlanRow[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("*")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PlanRow[];
    },
  });

  // Local working copy of plans to support interactive drag & drop with immediate simulation
  const [plans, setPlans] = useState<PlanRow[]>([]);
  const [initialPlansJson, setInitialPlansJson] = useState<string>("");
  const [saving, setSaving] = useState(false);

  // Sync from query on load / reset
  useEffect(() => {
    if (rawPlans.length && !initialPlansJson) {
      setPlans(rawPlans);
      setInitialPlansJson(JSON.stringify(rawPlans));
    }
  }, [rawPlans, initialPlansJson]);

  // Dirty state tracking
  const dirtyPlanIds = useMemo(() => {
    if (!initialPlansJson) return new Set<string>();
    const origMap = new Map<string, string>();
    try {
      const origList = JSON.parse(initialPlansJson) as PlanRow[];
      origList.forEach((p) => origMap.set(p.id, JSON.stringify(p.config)));
    } catch {
      return new Set<string>();
    }
    const dirty = new Set<string>();
    for (const p of plans) {
      const orig = origMap.get(p.id);
      if (!orig || orig !== JSON.stringify(p.config)) {
        dirty.add(p.id);
      }
    }
    return dirty;
  }, [plans, initialPlansJson]);

  // Time horizon / Date window
  const [timeWindow, setTimeWindow] = useState<TimeWindow>("current-month");
  const [searchQuery, setSearchQuery] = useState("");
  const [buyerFilter, setBuyerFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<
    "all" | "underloaded" | "optimal" | "overloaded"
  >("all");
  const [viewMode, setViewMode] = useState<"lanes" | "compact">("lanes");
  const [collapsedUnallocated, setCollapsedUnallocated] = useState(false);

  // Drag and drop state
  const [draggedTask, setDraggedTask] = useState<AllocationTask | null>(null);
  const [dragOverTarget, setDragOverTarget] = useState<string | null>(null); // canonical line name or "unallocated"

  const presetLookup = useMemo(() => buildLinePresetLookup(linePresets), [linePresets]);

  // Compute date range based on selected timeWindow
  const { windowStart, windowEnd, windowLabel } = useMemo(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();

    if (timeWindow === "current-month") {
      const s = new Date(y, m, 1);
      const e = new Date(y, m + 1, 0);
      return {
        windowStart: getLocalDateStr(s),
        windowEnd: getLocalDateStr(e),
        windowLabel: s.toLocaleString("en-US", { month: "long", year: "numeric" }),
      };
    } else if (timeWindow === "next-month") {
      const s = new Date(y, m + 1, 1);
      const e = new Date(y, m + 2, 0);
      return {
        windowStart: getLocalDateStr(s),
        windowEnd: getLocalDateStr(e),
        windowLabel: s.toLocaleString("en-US", { month: "long", year: "numeric" }),
      };
    } else if (timeWindow === "next-30-days") {
      const s = new Date(now);
      const e = new Date(now);
      e.setDate(e.getDate() + 30);
      return {
        windowStart: getLocalDateStr(s),
        windowEnd: getLocalDateStr(e),
        windowLabel: `${formatDate(getLocalDateStr(s))} → ${formatDate(getLocalDateStr(e))} (30 Days)`,
      };
    } else if (timeWindow === "next-60-days") {
      const s = new Date(now);
      const e = new Date(now);
      e.setDate(e.getDate() + 60);
      return {
        windowStart: getLocalDateStr(s),
        windowEnd: getLocalDateStr(e),
        windowLabel: `${formatDate(getLocalDateStr(s))} → ${formatDate(getLocalDateStr(e))} (60 Days)`,
      };
    } else {
      // all
      return {
        windowStart: "2020-01-01",
        windowEnd: "2030-12-31",
        windowLabel: "All Scheduled Horizon",
      };
    }
  }, [timeWindow]);

  // Working days in current window
  const windowWorkingDays = useMemo(() => {
    return countWorkingDaysBetween(windowStart, windowEnd, holidaySet);
  }, [windowStart, windowEnd, holidaySet]);

  // Flatten plans into AllocationTask items
  const allTasks: AllocationTask[] = useMemo(() => {
    const list: AllocationTask[] = [];
    for (const p of plans) {
      const isDirty = dirtyPlanIds.has(p.id);
      const lines = p.config?.lines ?? [];
      const calcLines = p.calc_result?.lines ?? [];
      const excessPct = p.calc_result?.excessPct ?? (Number(p.excess_pct) || 0);
      const factor = 1 + excessPct / 100;
      const fabricEta =
        (p.config as any)?.fabricEta ||
        (p.config as any)?.fabric_eta ||
        (p as any)?.fabric_eta ||
        (p as any)?.fabricEta ||
        null;

      if (!lines.length) {
        // Plan has no line allocations at all - goes to unallocated
        list.push({
          id: `${p.id}::unallocated`,
          planId: p.id,
          lineIndex: -1,
          buyer: p.buyer,
          style: p.style,
          orderQty: p.order_qty,
          plannedQty: Math.round(p.order_qty * factor),
          dailyTarget: p.daily_target || 800,
          lineName: "",
          rawLineName: "",
          startDateStr: "",
          finishDateStr: "",
          shipmentDate: p.shipment_date,
          isDelayed: false,
          workingDays: 0,
          excessPct,
          fabricEta,
          status: "unallocated",
          isDirty,
        });
        continue;
      }

      lines.forEach((l, idx) => {
        const cLine = calcLines.find((cl) => normLine(cl.name) === normLine(l.name));
        const daily = cLine?.dailyProduction ?? [];
        const start = daily.length ? daily[0].date : l.startDateStr;
        const end = cLine?.finishDateStr || (daily.length ? daily[daily.length - 1].date : start);
        let qty = cLine?.plannedQty || l.allocatedOrderQty || 0;
        if (qty === 0 && daily.length) {
          qty = daily.reduce((s, d) => s + (d.qty || 0), 0);
        }
        if (qty === 0) {
          qty = Math.round((p.order_qty / lines.length) * factor);
        }
        const workDays = cLine?.workingDays || countWorkingDaysBetween(start, end, holidaySet) || 1;
        const delayed = end ? end > p.shipment_date : false;
        const canon = canonicalLineName(l.name, presetLookup);

        list.push({
          id: `${p.id}::${idx}`,
          planId: p.id,
          lineIndex: idx,
          buyer: p.buyer,
          style: p.style,
          orderQty: l.allocatedOrderQty || Math.round(qty / factor),
          plannedQty: qty,
          dailyTarget: l.targetOverride || p.daily_target || 800,
          lineName: canon,
          rawLineName: l.name,
          startDateStr: start,
          finishDateStr: end,
          shipmentDate: p.shipment_date,
          isDelayed: delayed,
          workingDays: workDays,
          excessPct,
          fabricEta,
          status: "allocated",
          isDirty,
        });
      });
    }
    return list;
  }, [plans, dirtyPlanIds, presetLookup, holidaySet]);

  // Unique list of all lines to display
  const allLines = useMemo(() => {
    const set = new Set<string>();
    // Include all presets
    linePresets.forEach((p) => set.add(p));
    // Include any active lines from plans
    allTasks.forEach((t) => {
      if (t.lineName) set.add(t.lineName);
    });
    return sortLineNamesByPreset(Array.from(set), linePresets);
  }, [linePresets, allTasks]);

  // Compute capacity for each factory line in real-time
  const lineCapacities: LineCapacityInfo[] = useMemo(() => {
    // Map tasks by line
    const tasksByLine = new Map<string, AllocationTask[]>();
    allTasks.forEach((t) => {
      if (!t.lineName) return;
      const key = normLine(t.lineName);
      if (!tasksByLine.has(key)) tasksByLine.set(key, []);
      tasksByLine.get(key)!.push(t);
    });

    return allLines.map((line) => {
      const key = normLine(line);
      const tasks = tasksByLine.get(key) ?? [];
      // Sort tasks on line by start date
      tasks.sort((a, b) => a.startDateStr.localeCompare(b.startDateStr));

      // Calculate allocated quantity that falls within the selected window
      let allocatedQtyInWindow = 0;
      let totalAllocatedQty = 0;
      let sumDailyTarget = 0;
      let taskTargetCount = 0;

      for (const t of tasks) {
        totalAllocatedQty += t.plannedQty;
        if (t.dailyTarget > 0) {
          sumDailyTarget += t.dailyTarget;
          taskTargetCount++;
        }

        // Exact calculation if dates overlap the window
        if (!t.startDateStr || !t.finishDateStr) {
          allocatedQtyInWindow += t.plannedQty;
          continue;
        }

        const taskStart = t.startDateStr;
        const taskEnd = t.finishDateStr;

        if (taskEnd < windowStart || taskStart > windowEnd) {
          // outside window
          continue;
        }

        // Calculate overlap
        const overlapStart = taskStart < windowStart ? windowStart : taskStart;
        const overlapEnd = taskEnd > windowEnd ? windowEnd : taskEnd;
        const overlapDays = countWorkingDaysBetween(overlapStart, overlapEnd, holidaySet);
        const totalTaskDays = countWorkingDaysBetween(taskStart, taskEnd, holidaySet) || 1;

        const portion = Math.min(1, Math.max(0, overlapDays / totalTaskDays));
        allocatedQtyInWindow += Math.round(t.plannedQty * portion);
      }

      // Standard daily capacity: average of task targets or standard factory line benchmark (1,000 pcs/day)
      const dailyTargetCapacity =
        taskTargetCount > 0 ? Math.round(sumDailyTarget / taskTargetCount) : 1000;

      const workingDays = timeWindow === "all" ? 60 : Math.max(1, windowWorkingDays);
      const maxCapacityQty = dailyTargetCapacity * workingDays;
      const utilizationPct = maxCapacityQty > 0 ? (allocatedQtyInWindow / maxCapacityQty) * 100 : 0;
      const remainingQty = maxCapacityQty - allocatedQtyInWindow;

      let status: LineCapacityInfo["status"] = "optimal";
      if (utilizationPct < 70) status = "underloaded";
      else if (utilizationPct > 105) status = "overloaded";
      else if (utilizationPct > 95) status = "warning";

      return {
        line,
        workingDaysInWindow: workingDays,
        dailyTargetCapacity,
        maxCapacityQty,
        allocatedQtyInWindow,
        totalAllocatedQty,
        utilizationPct: Math.round(utilizationPct * 10) / 10,
        remainingQty,
        tasks,
        taskCount: tasks.length,
        status,
      };
    });
  }, [allLines, allTasks, windowStart, windowEnd, windowWorkingDays, timeWindow, holidaySet]);

  // Filter buyers
  const buyerOptions = useMemo(() => {
    const set = new Set<string>();
    allTasks.forEach((t) => set.add(t.buyer));
    return Array.from(set).sort();
  }, [allTasks]);

  // Unallocated tasks queue
  const unallocatedTasks = useMemo(() => {
    return allTasks.filter((t) => t.status === "unallocated" || !t.lineName);
  }, [allTasks]);

  // Overall Factory Summary KPIs
  const factoryMetrics = useMemo(() => {
    let totalCap = 0;
    let totalAlloc = 0;
    let overloadedCount = 0;
    let optimalCount = 0;
    let underloadedCount = 0;

    lineCapacities.forEach((lc) => {
      totalCap += lc.maxCapacityQty;
      totalAlloc += lc.allocatedQtyInWindow;
      if (lc.status === "overloaded") overloadedCount++;
      else if (lc.status === "underloaded") underloadedCount++;
      else optimalCount++;
    });

    const factoryUtilization = totalCap > 0 ? Math.round((totalAlloc / totalCap) * 1000) / 10 : 0;

    return {
      totalCap,
      totalAlloc,
      factoryUtilization,
      totalLines: lineCapacities.length,
      overloadedCount,
      optimalCount,
      underloadedCount,
      unallocatedCount: unallocatedTasks.length,
      unallocatedQty: unallocatedTasks.reduce((s, t) => s + t.plannedQty, 0),
    };
  }, [lineCapacities, unallocatedTasks]);

  // Filter lines based on search, buyer, status
  const visibleLineCapacities = useMemo(() => {
    return lineCapacities.filter((lc) => {
      if (statusFilter !== "all" && lc.status !== statusFilter) return false;

      if (buyerFilter !== "all") {
        const hasBuyer = lc.tasks.some((t) => t.buyer === buyerFilter);
        if (!hasBuyer) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesLine = lc.line.toLowerCase().includes(q);
        const matchesTask = lc.tasks.some(
          (t) => t.style.toLowerCase().includes(q) || t.buyer.toLowerCase().includes(q),
        );
        if (!matchesLine && !matchesTask) return false;
      }

      return true;
    });
  }, [lineCapacities, statusFilter, buyerFilter, searchQuery]);

  // ── Drag & Drop Handlers ─────────────────────────────────────
  const handleDragStart = (e: React.DragEvent, task: AllocationTask) => {
    e.dataTransfer.setData("text/plain", task.id);
    e.dataTransfer.effectAllowed = "move";
    setDraggedTask(task);
  };

  const handleDragEnd = () => {
    setDraggedTask(null);
    setDragOverTarget(null);
  };

  const handleDragOver = (e: React.DragEvent, targetKey: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (dragOverTarget !== targetKey) {
      setDragOverTarget(targetKey);
    }
  };

  const handleDragLeave = (e: React.DragEvent, targetKey: string) => {
    // Only clear if leaving this target
    if (dragOverTarget === targetKey) {
      setDragOverTarget(null);
    }
  };

  // Perform Allocation Drop onto a line or into unallocated pool
  const handleDrop = useCallback(
    (targetLineName: string) => {
      if (!draggedTask) return;
      const targetIsUnallocated = targetLineName === "unallocated";
      const currentLineNorm = normLine(draggedTask.lineName);
      const targetLineNorm = targetIsUnallocated ? "" : normLine(targetLineName);

      if (currentLineNorm === targetLineNorm) {
        // dropped on same line
        setDraggedTask(null);
        setDragOverTarget(null);
        return;
      }

      // Clone plans
      const cloned: PlanRow[] = JSON.parse(JSON.stringify(plans));
      const targetPlan = cloned.find((p) => p.id === draggedTask.planId);
      if (!targetPlan) {
        setDraggedTask(null);
        setDragOverTarget(null);
        return;
      }

      if (targetIsUnallocated) {
        // Move task to unallocated
        if (draggedTask.lineIndex >= 0 && targetPlan.config.lines[draggedTask.lineIndex]) {
          targetPlan.config.lines.splice(draggedTask.lineIndex, 1);
          targetPlan.calc_result = recomputePlan(targetPlan, globalHolidays);
          setPlans(cloned);
          toast.info(`${draggedTask.style} (${draggedTask.buyer}) unallocated.`);
        }
      } else {
        // Moving to targetLineName
        // Determine start date on new line:
        // Chain after the latest finishing task on the target line, or start from existing start / today
        const existingOnTarget = allTasks.filter(
          (t) =>
            normLine(t.lineName) === targetLineNorm &&
            t.planId !== draggedTask.planId &&
            t.finishDateStr,
        );
        let newStartDate = draggedTask.startDateStr || getLocalDateStr(new Date());

        if (existingOnTarget.length > 0) {
          existingOnTarget.sort((a, b) => b.finishDateStr.localeCompare(a.finishDateStr));
          const latestFinish = existingOnTarget[0].finishDateStr;
          const nextDay = nextWorkingDay(latestFinish, globalHolidays);
          if (nextDay > newStartDate) {
            newStartDate = nextDay;
          }
        }

        if (draggedTask.lineIndex >= 0 && targetPlan.config.lines[draggedTask.lineIndex]) {
          // Update existing line entry
          targetPlan.config.lines[draggedTask.lineIndex] = {
            ...targetPlan.config.lines[draggedTask.lineIndex],
            name: targetLineName,
            startDateStr: newStartDate,
          };
        } else {
          // Plan had no line entry or was unallocated
          const newLineEntry: LineInput = {
            id: Date.now(),
            name: targetLineName,
            startDateStr: newStartDate,
            allocatedOrderQty: draggedTask.orderQty,
            applyLC: true,
            chainAuto: true,
          };
          targetPlan.config.lines = [newLineEntry];
        }

        targetPlan.calc_result = recomputePlan(targetPlan, globalHolidays);
        setPlans(cloned);
        toast.success(
          `${draggedTask.style} allocated to ${targetLineName} (Starts: ${formatDate(newStartDate)})`,
        );
      }

      setDraggedTask(null);
      setDragOverTarget(null);
    },
    [draggedTask, plans, allTasks, globalHolidays],
  );

  // Quick move via action button
  const handleQuickMove = (task: AllocationTask, targetLine: string) => {
    setDraggedTask(task);
    setTimeout(() => {
      handleDrop(targetLine);
    }, 10);
  };

  // Discard / Reset changes
  const handleReset = () => {
    if (!initialPlansJson) return;
    try {
      setPlans(JSON.parse(initialPlansJson));
      toast.info("Allocations reverted to saved state.");
    } catch {
      /* noop */
    }
  };

  // Save changes to database
  const handleSaveAllocations = async () => {
    if (dirtyPlanIds.size === 0) return;
    setSaving(true);
    try {
      const origMap = new Map<string, PlanRow>();
      try {
        const origList = JSON.parse(initialPlansJson) as PlanRow[];
        origList.forEach((p) => origMap.set(p.id, p));
      } catch {
        /* noop */
      }

      for (const planId of dirtyPlanIds) {
        const current = plans.find((p) => p.id === planId);
        const orig = origMap.get(planId);
        if (!current) continue;

        const previousSnapshot = orig ? buildPlanSnapshot(orig.calc_result) : null;

        const { error } = await supabase
          .from("plans")
          .update({
            config: current.config as any,
            calc_result: current.calc_result as any,
            previous_snapshot: previousSnapshot as any,
            num_lines: current.config.lines.length,
            updated_at: new Date().toISOString(),
          })
          .eq("id", planId);

        if (error) throw error;
      }

      setInitialPlansJson(JSON.stringify(plans));
      await qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success(`${dirtyPlanIds.size} plan allocation(s) saved successfully!`);
    } catch (err: any) {
      console.error("Save allocation error:", err);
      toast.error("Failed to save allocations: " + (err?.message || "Unknown error"));
    } finally {
      setSaving(false);
    }
  };

  // Export to Excel
  const handleExportXLSX = () => {
    const rows = lineCapacities.map((lc) => ({
      "Factory Line": lc.line,
      "Daily Capacity (Pcs)": lc.dailyTargetCapacity,
      "Working Days": lc.workingDaysInWindow,
      "Max Capacity (Pcs)": lc.maxCapacityQty,
      "Allocated (Pcs)": lc.allocatedQtyInWindow,
      "Capacity Utilization %": `${lc.utilizationPct}%`,
      "Remaining Pcs": lc.remainingQty,
      Status: lc.status.toUpperCase(),
      "Allocated Styles": lc.tasks.map((t) => `${t.style} (${t.plannedQty})`).join(", "),
    }));

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Line Capacities");
    XLSX.writeFile(wb, `Line_Allocation_Capacity_${windowStart}_to_${windowEnd}.xlsx`);
    toast.success("Allocation and capacity report exported to Excel!");
  };

  // Live Prospective Delta when dragging over a line
  const computeProspectiveCapacity = (targetLineName: string) => {
    if (!draggedTask) return null;
    const lc = lineCapacities.find((l) => normLine(l.line) === normLine(targetLineName));
    if (!lc) return null;

    const isCurrentLine = normLine(draggedTask.lineName) === normLine(targetLineName);
    if (isCurrentLine) return null;

    const addedQty = draggedTask.plannedQty;
    const prospectiveAllocated = lc.allocatedQtyInWindow + addedQty;
    const prospectiveUtil =
      lc.maxCapacityQty > 0 ? (prospectiveAllocated / lc.maxCapacityQty) * 100 : 0;
    const deltaUtil = Math.round(prospectiveUtil - lc.utilizationPct);

    return {
      addedQty,
      prospectiveUtil: Math.round(prospectiveUtil * 10) / 10,
      deltaUtil,
      isOverload: prospectiveUtil > 100,
    };
  };

  if (isLoading && !plans.length) {
    return (
      <div className="flex flex-col items-center justify-center p-16 gap-3">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-muted-foreground">Loading factory lines & allocations...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ── Page Header ────────────────────────────────────────────── */}
      <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
        <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                <Layers className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-lg md:text-xl font-extrabold text-foreground tracking-tight">
                  Line Allocation &amp; Capacity
                </h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Drag production tasks onto factory lines. Real-time capacity and utilization
                  update instantly.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {dirtyPlanIds.size > 0 && (
              <>
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  {dirtyPlanIds.size} pending change{dirtyPlanIds.size > 1 ? "s" : ""}
                </div>

                <button
                  onClick={handleReset}
                  disabled={saving}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-border bg-panel-2 hover:bg-panel text-xs font-medium text-muted-foreground hover:text-foreground transition disabled:opacity-50"
                  title="Discard pending unsaved allocations"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Discard
                </button>

                <button
                  onClick={handleSaveAllocations}
                  disabled={saving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-bold shadow-md transition disabled:opacity-50"
                >
                  {saving ? (
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Save className="w-3.5 h-3.5" />
                  )}
                  Save Allocations
                </button>
              </>
            )}

            <button
              onClick={handleExportXLSX}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-border bg-panel-2 hover:bg-panel text-xs font-medium text-foreground transition"
              title="Export Line Allocation Report"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Export Excel
            </button>
          </div>
        </div>

        {/* ── Real-Time Capacity KPI Metric Cards (No Static Pills) ── */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 p-4 md:p-6 bg-panel/30 border-b border-border">
          <div className="p-3 rounded-xl bg-panel-2/60 border border-border">
            <span className="text-[11px] font-medium text-muted-foreground block">
              Factory Capacity
            </span>
            <span className="text-lg md:text-xl font-extrabold text-foreground mt-0.5 block">
              {factoryMetrics.totalCap.toLocaleString()}{" "}
              <span className="text-xs font-normal text-muted-foreground">pcs</span>
            </span>
            <span className="text-[10px] text-muted-foreground mt-1 block">
              {factoryMetrics.totalLines} Lines · {windowWorkingDays} Working Days
            </span>
          </div>

          <div className="p-3 rounded-xl bg-panel-2/60 border border-border">
            <span className="text-[11px] font-medium text-muted-foreground block">
              Allocated Output
            </span>
            <span className="text-lg md:text-xl font-extrabold text-blue-400 mt-0.5 block">
              {factoryMetrics.totalAlloc.toLocaleString()}{" "}
              <span className="text-xs font-normal text-muted-foreground">pcs</span>
            </span>
            <span className="text-[10px] text-muted-foreground mt-1 block">
              In selected horizon ({windowLabel})
            </span>
          </div>

          <div className="p-3 rounded-xl bg-panel-2/60 border border-border">
            <span className="text-[11px] font-medium text-muted-foreground block">
              Factory Utilization
            </span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span
                className={`text-lg md:text-xl font-extrabold ${
                  factoryMetrics.factoryUtilization > 100
                    ? "text-rose-400"
                    : factoryMetrics.factoryUtilization > 75
                      ? "text-emerald-400"
                      : "text-sky-400"
                }`}
              >
                {factoryMetrics.factoryUtilization}%
              </span>
            </div>
            {/* Visual meter */}
            <div className="w-full h-1.5 rounded-full bg-panel mt-1.5 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  factoryMetrics.factoryUtilization > 100
                    ? "bg-rose-500"
                    : factoryMetrics.factoryUtilization > 75
                      ? "bg-emerald-500"
                      : "bg-sky-500"
                }`}
                style={{ width: `${Math.min(100, factoryMetrics.factoryUtilization)}%` }}
              />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-panel-2/60 border border-border">
            <span className="text-[11px] font-medium text-muted-foreground block">
              Balanced Lines
            </span>
            <span className="text-lg md:text-xl font-extrabold text-emerald-400 mt-0.5 block">
              {factoryMetrics.optimalCount}
            </span>
            <span className="text-[10px] text-emerald-400/80 mt-1 block">70% – 100% capacity</span>
          </div>

          <div className="p-3 rounded-xl bg-panel-2/60 border border-border">
            <span className="text-[11px] font-medium text-muted-foreground block">
              Under-utilized Lines
            </span>
            <span className="text-lg md:text-xl font-extrabold text-sky-400 mt-0.5 block">
              {factoryMetrics.underloadedCount}
            </span>
            <span className="text-[10px] text-sky-400/80 mt-1 block">&lt; 70% available slots</span>
          </div>

          <div className="p-3 rounded-xl bg-panel-2/60 border border-border">
            <span className="text-[11px] font-medium text-muted-foreground block">
              Overloaded Lines
            </span>
            <span
              className={`text-lg md:text-xl font-extrabold mt-0.5 block ${
                factoryMetrics.overloadedCount > 0 ? "text-rose-400" : "text-muted-foreground"
              }`}
            >
              {factoryMetrics.overloadedCount}
            </span>
            <span className="text-[10px] text-rose-400/80 mt-1 block">
              {factoryMetrics.overloadedCount > 0
                ? "Risk of shipment delay!"
                : "None over capacity"}
            </span>
          </div>
        </div>

        {/* ── Filters & Time Horizon Controls ──────────────────────── */}
        <div className="p-4 bg-panel/40 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            {/* Time Window Buttons */}
            <div className="inline-flex rounded-xl border border-border bg-panel-2/60 p-0.5">
              {(
                [
                  { key: "current-month", label: "This Month" },
                  { key: "next-month", label: "Next Month" },
                  { key: "next-30-days", label: "Next 30 Days" },
                  { key: "next-60-days", label: "Next 60 Days" },
                  { key: "all", label: "All Horizon" },
                ] as { key: TimeWindow; label: string }[]
              ).map((tw) => (
                <button
                  key={tw.key}
                  onClick={() => setTimeWindow(tw.key)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                    timeWindow === tw.key
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {tw.label}
                </button>
              ))}
            </div>

            {/* Status Filter */}
            <div className="inline-flex rounded-xl border border-border bg-panel-2/60 p-0.5">
              {(
                [
                  { key: "all", label: "All Lines" },
                  { key: "underloaded", label: "Free Slots (<70%)" },
                  { key: "optimal", label: "Optimal (70-100%)" },
                  { key: "overloaded", label: "Overloaded (>100%)" },
                ] as const
              ).map((s) => (
                <button
                  key={s.key}
                  onClick={() => setStatusFilter(s.key)}
                  className={`px-2.5 py-1.5 text-[11px] font-semibold rounded-lg transition ${
                    statusFilter === s.key
                      ? "bg-panel text-foreground shadow-sm border border-border/80"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Search Box */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search style or line..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-border bg-panel-2 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary w-44"
              />
            </div>

            {/* Buyer Select */}
            {buyerOptions.length > 0 && (
              <select
                value={buyerFilter}
                onChange={(e) => setBuyerFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-border bg-panel-2 text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value="all">All Buyers</option>
                {buyerOptions.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            )}

            {/* View Mode Switcher */}
            <div className="inline-flex rounded-xl border border-border bg-panel-2 p-0.5">
              <button
                onClick={() => setViewMode("lanes")}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg transition ${
                  viewMode === "lanes"
                    ? "bg-panel text-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                title="Lanes View"
              >
                Columns
              </button>
              <button
                onClick={() => setViewMode("compact")}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg transition ${
                  viewMode === "compact"
                    ? "bg-panel text-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                title="Compact Grid View"
              >
                Grid
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ── Drag & Drop Active Notice ───────────────────────────────── */}
      {draggedTask && (
        <div className="sticky top-16 z-40 p-3 rounded-2xl bg-blue-600/95 text-white shadow-2xl backdrop-blur flex items-center justify-between animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <span className="p-1.5 rounded-lg bg-white/20">
              <GripVertical className="w-4 h-4" />
            </span>
            <div>
              <div className="text-xs font-bold">
                Dragging: {draggedTask.style} · {draggedTask.buyer} (
                {draggedTask.plannedQty.toLocaleString()} pcs)
              </div>
              <div className="text-[11px] text-blue-100">
                Release over any Factory Line card to reallocate. Hover over lines to preview
                real-time capacity impact.
              </div>
            </div>
          </div>
          <button
            onClick={() => setDraggedTask(null)}
            className="px-3 py-1 rounded-lg bg-black/20 hover:bg-black/40 text-xs font-medium"
          >
            Cancel
          </button>
        </div>
      )}

      {/* ── Main Layout: Side-by-Side Queue + Factory Lines ─────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ── Left / Side Queue: Unallocated Orders ─────────────────── */}
        <div
          className={`lg:col-span-3 rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-md transition-all ${
            dragOverTarget === "unallocated" ? "ring-2 ring-blue-500 bg-blue-500/10" : ""
          }`}
          onDragOver={(e) => handleDragOver(e, "unallocated")}
          onDragLeave={(e) => handleDragLeave(e, "unallocated")}
          onDrop={() => handleDrop("unallocated")}
        >
          <div className="p-3.5 border-b border-border bg-panel-2/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-foreground">
                Unallocated Orders
              </h3>
              <span className="text-[11px] text-muted-foreground">({unallocatedTasks.length})</span>
            </div>
            <button
              onClick={() => setCollapsedUnallocated((v) => !v)}
              className="p-1 text-muted-foreground hover:text-foreground rounded"
            >
              {collapsedUnallocated ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronUp className="w-4 h-4" />
              )}
            </button>
          </div>

          {!collapsedUnallocated && (
            <div className="p-3 space-y-2.5 max-h-[70vh] overflow-y-auto">
              <div className="text-[11px] text-muted-foreground leading-relaxed px-1">
                Drag cards from here directly onto any factory line below.
              </div>

              {unallocatedTasks.length === 0 ? (
                <div className="py-8 text-center border border-dashed border-border rounded-xl">
                  <ShieldCheck className="w-6 h-6 text-emerald-400 mx-auto mb-1 opacity-70" />
                  <p className="text-xs text-muted-foreground">No unallocated styles.</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    All orders currently assigned to lines.
                  </p>
                </div>
              ) : (
                unallocatedTasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    isDragging={draggedTask?.id === task.id}
                    onDragStart={(e) => handleDragStart(e, task)}
                    onDragEnd={handleDragEnd}
                    onQuickMove={(line) => handleQuickMove(task, line)}
                    availableLines={allLines}
                    onEditPlan={(planId) => {
                      if (onSwitchTab) onSwitchTab("input");
                      window.dispatchEvent(new CustomEvent("cg:edit-plan", { detail: planId }));
                    }}
                  />
                ))
              )}

              {/* Drop area notice */}
              <div className="p-2.5 border border-dashed border-border/70 rounded-xl text-center text-[10px] text-muted-foreground bg-panel/30">
                Drop any scheduled task here to unassign from its line.
              </div>
            </div>
          )}
        </div>

        {/* ── Right / Main: Factory Lines Grid & Capacity Meters ───── */}
        <div className="lg:col-span-9 space-y-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
            <span>
              Showing {visibleLineCapacities.length} of {lineCapacities.length} factory lines ·
              Window: <span className="font-semibold text-foreground">{windowLabel}</span>
            </span>
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-sky-400" /> &lt;70% Free
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" /> 70-100% Optimal
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-400" /> &gt;100% Overload
              </span>
            </div>
          </div>

          <div
            className={
              viewMode === "lanes"
                ? "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4"
                : "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3"
            }
          >
            {visibleLineCapacities.map((lineCap) => {
              const prospective = computeProspectiveCapacity(lineCap.line);
              const isDragTarget = dragOverTarget === lineCap.line;

              return (
                <LineCard
                  key={lineCap.line}
                  lineCap={lineCap}
                  isDragTarget={isDragTarget}
                  prospective={prospective}
                  draggedTask={draggedTask}
                  onDragOver={(e) => handleDragOver(e, lineCap.line)}
                  onDragLeave={(e) => handleDragLeave(e, lineCap.line)}
                  onDrop={() => handleDrop(lineCap.line)}
                  onTaskDragStart={handleDragStart}
                  onTaskDragEnd={handleDragEnd}
                  onQuickMoveTask={handleQuickMove}
                  availableLines={allLines}
                  onEditPlan={(planId) => {
                    if (onSwitchTab) onSwitchTab("input");
                    window.dispatchEvent(new CustomEvent("cg:edit-plan", { detail: planId }));
                  }}
                  compact={viewMode === "compact"}
                />
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Factory Line Card Component ──────────────────────────────────
function LineCard({
  lineCap,
  isDragTarget,
  prospective,
  draggedTask,
  onDragOver,
  onDragLeave,
  onDrop,
  onTaskDragStart,
  onTaskDragEnd,
  onQuickMoveTask,
  availableLines,
  onEditPlan,
  compact = false,
}: {
  lineCap: LineCapacityInfo;
  isDragTarget: boolean;
  prospective: {
    addedQty: number;
    prospectiveUtil: number;
    deltaUtil: number;
    isOverload: boolean;
  } | null;
  draggedTask: AllocationTask | null;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onDrop: () => void;
  onTaskDragStart: (e: React.DragEvent, task: AllocationTask) => void;
  onTaskDragEnd: () => void;
  onQuickMoveTask: (task: AllocationTask, line: string) => void;
  availableLines: string[];
  onEditPlan: (planId: string) => void;
  compact?: boolean;
}) {
  const effectiveUtil = prospective ? prospective.prospectiveUtil : lineCap.utilizationPct;

  return (
    <div
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      className={`rounded-2xl border transition-all duration-200 flex flex-col ${
        isDragTarget
          ? prospective?.isOverload
            ? "border-rose-500 bg-rose-950/20 ring-2 ring-rose-500/50 shadow-lg scale-[1.01]"
            : "border-emerald-500 bg-emerald-950/20 ring-2 ring-emerald-500/50 shadow-lg scale-[1.01]"
          : "border-border bg-panel/70 hover:border-border/80"
      }`}
    >
      {/* ── Line Header & Capacity Gauge ────────────────────────── */}
      <div className="p-3.5 border-b border-border/70 bg-panel-2/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-sm md:text-base text-foreground tracking-tight">
              {lineCap.line}
            </span>
            <span className="text-[10px] text-muted-foreground">
              {lineCap.dailyTargetCapacity.toLocaleString()} pcs/day
            </span>
          </div>

          {/* Utilization Badge */}
          <div className="text-right">
            <span
              className={`text-xs font-extrabold ${
                effectiveUtil > 100
                  ? "text-rose-400"
                  : effectiveUtil >= 70
                    ? "text-emerald-400"
                    : "text-sky-400"
              }`}
            >
              {effectiveUtil}%
            </span>
            {prospective && (
              <span className="text-[10px] text-amber-300 block font-mono">
                (+{prospective.deltaUtil}%)
              </span>
            )}
          </div>
        </div>

        {/* Capacity Bar */}
        <div className="mt-2">
          <div className="w-full h-2 rounded-full bg-panel overflow-hidden relative">
            {/* Base allocated load */}
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                lineCap.utilizationPct > 100
                  ? "bg-rose-500"
                  : lineCap.utilizationPct >= 70
                    ? "bg-emerald-500"
                    : "bg-sky-500"
              }`}
              style={{ width: `${Math.min(100, lineCap.utilizationPct)}%` }}
            />
            {/* Live Prospective ghost bar during drag */}
            {prospective && (
              <div
                className={`absolute top-0 bottom-0 opacity-70 animate-pulse ${
                  prospective.isOverload ? "bg-rose-400" : "bg-emerald-400"
                }`}
                style={{
                  left: `${Math.min(100, lineCap.utilizationPct)}%`,
                  width: `${Math.min(100 - Math.min(100, lineCap.utilizationPct), prospective.deltaUtil)}%`,
                }}
              />
            )}
          </div>

          <div className="flex items-center justify-between text-[10px] text-muted-foreground mt-1.5">
            <span>
              <b className="text-foreground">{lineCap.allocatedQtyInWindow.toLocaleString()}</b> /{" "}
              {lineCap.maxCapacityQty.toLocaleString()} pcs
            </span>
            <span>
              {lineCap.remainingQty > 0 ? (
                <span className="text-emerald-400">
                  +{lineCap.remainingQty.toLocaleString()} free
                </span>
              ) : (
                <span className="text-rose-400 font-semibold">
                  {Math.abs(lineCap.remainingQty).toLocaleString()} overload
                </span>
              )}
            </span>
          </div>

          {/* Real-time live hover impact hint */}
          {prospective && (
            <div
              className={`mt-2 p-1.5 rounded-lg text-[10px] font-semibold flex items-center gap-1.5 ${
                prospective.isOverload
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              }`}
            >
              {prospective.isOverload ? (
                <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
              ) : (
                <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
              )}
              <span>
                Adding {draggedTask?.style}: +{prospective.addedQty.toLocaleString()} pcs ➔{" "}
                {prospective.prospectiveUtil}%
              </span>
            </div>
          )}
        </div>
      </div>

      {/* ── Tasks List on Line ──────────────────────────────────── */}
      <div className="p-3 flex-1 flex flex-col space-y-2 max-h-96 overflow-y-auto">
        {lineCap.tasks.length === 0 ? (
          <div
            className={`flex-1 min-h-24 flex flex-col items-center justify-center border border-dashed rounded-xl p-3 text-center transition-colors ${
              isDragTarget ? "border-emerald-400 bg-emerald-500/10" : "border-border/60"
            }`}
          >
            <p className="text-xs text-muted-foreground">Line has no allocated tasks.</p>
            <p className="text-[10px] text-muted-foreground/80 mt-0.5">
              Drag production tasks here to schedule.
            </p>
          </div>
        ) : (
          lineCap.tasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              isDragging={draggedTask?.id === task.id}
              onDragStart={(e) => onTaskDragStart(e, task)}
              onDragEnd={onTaskDragEnd}
              onQuickMove={(targetLine) => onQuickMoveTask(task, targetLine)}
              availableLines={availableLines}
              onEditPlan={onEditPlan}
              compact={compact}
            />
          ))
        )}

        {/* Drop target prompt */}
        {draggedTask && draggedTask.lineName !== lineCap.line && (
          <div
            className={`p-2.5 rounded-xl border border-dashed text-center text-[11px] font-semibold transition ${
              isDragTarget
                ? "border-emerald-400 text-emerald-300 bg-emerald-500/20"
                : "border-border text-muted-foreground hover:border-emerald-400"
            }`}
          >
            Release to drop on {lineCap.line}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Production Task Card Component ──────────────────────────────
function TaskCard({
  task,
  isDragging,
  onDragStart,
  onDragEnd,
  onQuickMove,
  availableLines,
  onEditPlan,
  compact = false,
}: {
  task: AllocationTask;
  isDragging: boolean;
  onDragStart: (e: React.DragEvent) => void;
  onDragEnd: () => void;
  onQuickMove: (targetLine: string) => void;
  availableLines: string[];
  onEditPlan: (planId: string) => void;
  compact?: boolean;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      className={`rounded-xl border p-2.5 transition-all select-none cursor-grab active:cursor-grabbing ${
        isDragging
          ? "opacity-40 scale-95 border-blue-500"
          : task.isDirty
            ? "border-amber-500/40 bg-amber-500/5 hover:border-amber-400"
            : "border-border bg-panel-2/60 hover:bg-panel-2 hover:border-border/80 shadow-sm"
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex items-center gap-1.5">
          <GripVertical className="w-3.5 h-3.5 text-muted-foreground/60 shrink-0" />
          <div className="min-w-0">
            <span className="text-xs font-bold text-foreground block truncate" title={task.style}>
              {task.style}
            </span>
            <span className="text-[10px] text-muted-foreground truncate block">{task.buyer}</span>
          </div>
        </div>

        <div className="text-right shrink-0">
          <span className="text-xs font-extrabold text-blue-400">
            {task.plannedQty.toLocaleString()}{" "}
            <span className="text-[9px] font-normal text-muted-foreground">pcs</span>
          </span>
          {task.isDirty && (
            <span className="text-[9px] text-amber-400 block font-semibold">● Modified</span>
          )}
        </div>
      </div>

      {!compact && (
        <div className="mt-2 pt-2 border-t border-border/50 grid grid-cols-2 gap-1.5 text-[10px] text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-muted-foreground/70" />
            <span>Target: {task.dailyTarget}/day</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3 text-muted-foreground/70" />
            <span>{task.workingDays} working days</span>
          </div>
        </div>
      )}

      {task.startDateStr && task.finishDateStr && (
        <div className="mt-1.5 flex items-center justify-between text-[10px]">
          <span className="text-muted-foreground font-mono">
            {formatDate(task.startDateStr)} → {formatDate(task.finishDateStr)}
          </span>
          {task.isDelayed ? (
            <span className="text-rose-400 font-semibold flex items-center gap-0.5">
              <AlertTriangle className="w-2.5 h-2.5" /> Delay
            </span>
          ) : (
            <span className="text-emerald-400">On Time</span>
          )}
        </div>
      )}

      {task.fabricEta && (
        <div className="mt-1 flex items-center justify-between text-[10px]">
          <span className="inline-flex items-center gap-1 text-teal-300 font-mono">
            🧵 ETA: {formatDate(task.fabricEta)}
          </span>
          {task.startDateStr && task.fabricEta > task.startDateStr && (
            <span
              className="text-rose-400 font-bold flex items-center gap-0.5"
              title="ফ্যাব্রিক লাইন শুরুর পরে আসবে!"
            >
              ⚠️ Late ETA
            </span>
          )}
        </div>
      )}

      {/* Quick Move / Edit Actions */}
      <div className="mt-2 pt-1.5 border-t border-border/40 flex items-center justify-between">
        <button
          onClick={() => onEditPlan(task.planId)}
          className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 hover:underline"
          title="Open in Plan Input editor"
        >
          <ExternalLink className="w-2.5 h-2.5" /> Edit
        </button>

        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="text-[10px] text-blue-400 hover:text-blue-300 font-medium flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-blue-500/10 hover:bg-blue-500/20"
          >
            Move <ChevronDown className="w-2.5 h-2.5" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 bottom-full mb-1 z-50 w-36 rounded-xl border border-border bg-panel shadow-xl p-1 text-[11px] max-h-48 overflow-y-auto">
              <div className="px-2 py-1 text-[9px] uppercase font-bold text-muted-foreground border-b border-border/50">
                Move to Line
              </div>
              {task.lineName && (
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onQuickMove("unallocated");
                  }}
                  className="w-full text-left px-2 py-1 rounded hover:bg-amber-500/20 text-amber-300 text-xs font-medium"
                >
                  Unallocate
                </button>
              )}
              {availableLines
                .filter((l) => normLine(l) !== normLine(task.lineName))
                .slice(0, 15)
                .map((ln) => (
                  <button
                    key={ln}
                    onClick={() => {
                      setMenuOpen(false);
                      onQuickMove(ln);
                    }}
                    className="w-full text-left px-2 py-1 rounded hover:bg-panel-2 text-foreground text-xs"
                  >
                    {ln}
                  </button>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
