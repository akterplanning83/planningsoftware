import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { format, startOfMonth, addMonths, subMonths } from "date-fns";
import { toast } from "sonner";
import {
  Loader2,
  ChevronLeft,
  ChevronRight,
  Save,
  Factory,
  Layers,
  LayoutGrid,
  Plus,
  Trash2,
  Search,
  Filter,
  X,
  AlertCircle,
  RefreshCw,
  CheckCircle2,
  Copy,
  Clipboard,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import Select from "react-select";
import { useLinePresets } from "@/hooks/use-line-presets";
import { normLine } from "./lineLookup";

const COST_HEADS = [
  "OT Employee",
  "Manpower",
  "Salary",
  "Over Time",
  "Tiffin & Night",
  "Earned Leave Benefit",
  "Festival Bonus",
  "Attendence Bonus",
  "Office Supply & Stationary",
  "Needle, Spare Parts, Oil & Chemical",
  "Floor Overhead",
  "Machine-hour",
  "Total Man-hour",
  "Standard Hour (Gross)",
  "Standard Hour (Machine)",
  "Efficiency (Gross)",
  "Efficiency ( Machine)",
  "NO. OF STYLE CHANGE OVER",
  "LOST TIME",
  "REWORK",
  "Production (Pcs.)",
  "CM Earning Projection",
];

export default function MonthlyBudgetView() {
  const [currentDate, setCurrentDate] = useState(startOfMonth(new Date()));
  const [entryDate, setEntryDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [activeTab, setActiveTab] = useState("line");
  const [selectedLinesForView, setSelectedLinesForView] = useState<string[]>([]);
  const [selectedFloorIds, setSelectedFloorIds] = useState<string[]>([]);
  const [floorSearchQuery, setFloorSearchQuery] = useState("");
  const [isClusterDialogOpen, setIsClusterDialogOpen] = useState(false);
  const [newClusterName, setNewClusterName] = useState("");
  const [selectedLines, setSelectedLines] = useState<string[]>([]);
  const [clusterSearchQuery, setClusterSearchQuery] = useState("");
  const [lineBudgetData, setLineBudgetData] = useState<
    Record<string, { budget: number; actual: number }>
  >({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(new Date());
  const [copiedLineData, setCopiedLineData] = useState<Record<
    string,
    { budget: number; actual: number }
  > | null>(null);
  const queryClient = useQueryClient();

  const { data: profile, isLoading: loadingProfile } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();
      if (error) {
        console.error("Profile fetch error:", error);
        return null;
      }
      if (data && !data.factory_id) {
        console.warn(
          "User profile found but factory_id is null. Checking for existing factories...",
        );
        const { data: factories } = await supabase.from("factories").select("id").limit(1);
        if (factories && factories.length > 0) {
          data.factory_id = factories[0].id;
        }
      }
      return data;
    },
    staleTime: 1000 * 60 * 5,
  });

  const { presets: linePresets, loaded: loadedPresets } = useLinePresets();

  // Sync selected lines if presets change or on initial load
  useEffect(() => {
    if (!linePresets || linePresets.length === 0) return;
    setSelectedLinesForView((prev) => {
      if (prev.length === 0) return [linePresets[0]];
      const validLines = prev.filter((line) => linePresets.includes(line));
      if (validLines.length === prev.length) return prev;
      return validLines.length > 0 ? validLines : [linePresets[0]];
    });
  }, [linePresets]);

  const monthStr = format(currentDate, "yyyy-MM-01");

  const {
    data: lineDetails,
    isLoading: loadingLines,
    error: lineQueryError,
  } = useQuery({
    queryKey: ["budget_line_details", profile?.factory_id, monthStr, entryDate],
    queryFn: async () => {
      if (!profile?.factory_id) return [];
      const { data, error } = await (supabase.from("budget_line_details" as any) as any)
        .select("*")
        .eq("factory_id", profile.factory_id)
        .eq("month", monthStr)
        .eq("entry_date", entryDate);
      if (error) throw error;
      return data || [];
    },
    enabled: !!profile?.factory_id,
    retry: 1,
  });

  const { data: deptDetails, isLoading: loadingDepts } = useQuery({
    queryKey: ["budget_department_details", profile?.factory_id, monthStr, entryDate],
    queryFn: async () => {
      if (!profile?.factory_id) return [];
      const { data } = await (supabase.from("budget_department_details" as any) as any)
        .select("*")
        .eq("factory_id", profile.factory_id)
        .eq("month", monthStr)
        .eq("entry_date", entryDate);
      return data || [];
    },
    enabled: !!profile?.factory_id,
  });

  const upsertLineMutation = useMutation({
    mutationFn: async (payload: any) => {
      const { error } = await supabase
        .from("budget_line_details" as any)
        .upsert(payload, { onConflict: "factory_id,month,line_name,cost_head,entry_date" });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["budget_line_details"] });
      toast.success("Line budget updated");
    },
  });

  const upsertDeptMutation = useMutation({
    mutationFn: async (payload: any) => {
      const { error } = await supabase
        .from("budget_department_details" as any)
        .upsert(payload, { onConflict: "factory_id,month,department,cost_head,entry_date" });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["budget_department_details"] });
      toast.success("Department budget updated");
    },
  });

  const bulkUpsertLineMutation = useMutation({
    mutationFn: async (payloads: any[]) => {
      const { error } = await supabase
        .from("budget_line_details" as any)
        .upsert(payloads, { onConflict: "factory_id,month,line_name,cost_head,entry_date" });
      if (error) throw error;
    },
    retry: 3,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["budget_line_details"] });
      setSaveError(null);
      setCooldownRemaining(0);
      setLastSyncedAt(new Date());
      toast.success("Sync complete: All budget views updated");
    },
    onError: (err: any) => {
      console.error("Save error:", err);
      setSaveError(err.message || "Failed to save changes. Please try again.");
      setIsSaving(false);
      setCooldownRemaining(30); // 30 second cooldown on persistent error
    },
  });

  const handleLineDataChange = (
    line: string,
    head: string,
    type: "budget" | "actual",
    value: number,
  ) => {
    const key = `${line}::${head}`;
    setLineBudgetData((prev) => ({
      ...prev,
      [key]: {
        ...(prev[key] || {
          budget: getLineVal(line, head, "budget"),
          actual: getLineVal(line, head, "actual"),
        }),
        [type]: value,
      },
    }));
  };

  const saveLineBudget = useCallback(
    async (dataToSave?: Record<string, { budget: number; actual: number }>) => {
      const data = dataToSave || lineBudgetData;
      if (Object.keys(data).length === 0 || !profile?.factory_id) return;

      setIsSaving(true);
      setSaveError(null);
      const payloads: any[] = [];

      Object.entries(data).forEach(([key, vals]) => {
        const [lineName, head] = key.split("::");

        payloads.push({
          factory_id: profile.factory_id,
          month: monthStr,
          entry_date: entryDate,
          line_name: lineName,
          cost_head: head,
          budget_value: vals.budget,
          actual_value: vals.actual,
        });
      });

      // Auto-calculate efficiency heads for all lines that had base data changes
      const affectedLines = new Set(payloads.map((p) => p.line_name));
      affectedLines.forEach((line) => {
        ["Efficiency (Gross)", "Efficiency ( Machine)"].forEach((head) => {
          payloads.push({
            factory_id: profile.factory_id,
            month: monthStr,
            entry_date: entryDate,
            line_name: line,
            cost_head: head,
            budget_value: getLineVal(line as string, head, "budget"),
            actual_value: getLineVal(line as string, head, "actual"),
          });
        });
      });

      if (payloads.length === 0) {
        setIsSaving(false);
        return;
      }

      bulkUpsertLineMutation.mutate(payloads, {
        onSuccess: () => {
          setLineBudgetData((prev) => {
            const newState = { ...prev };
            Object.keys(data).forEach((k) => delete newState[k]);
            return newState;
          });
        },
        onSettled: () => {
          setIsSaving(false);
        },
      });
    },
    [lineBudgetData, profile?.factory_id, monthStr, entryDate, bulkUpsertLineMutation],
  );

  // Cooldown timer
  useEffect(() => {
    if (cooldownRemaining > 0) {
      const timer = setInterval(() => {
        setCooldownRemaining((prev) => Math.max(0, prev - 1));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [cooldownRemaining]);

  // Removed auto-save logic as per user request for manual save option.

  const { data: clusters = [], isLoading: loadingClusters } = useQuery({
    queryKey: ["budget_floor_clusters", profile?.factory_id],
    queryFn: async () => {
      if (!profile?.factory_id) return [];
      const { data, error } = await supabase
        .from("budget_floor_clusters")
        .select("*")
        .eq("factory_id", profile.factory_id)
        .order("cluster_name");
      if (error) {
        console.error("Clusters fetch error:", error);
        return [];
      }
      return data || [];
    },
    enabled: !!profile?.factory_id,
    refetchOnWindowFocus: true,
  });

  const createClusterMutation = useMutation({
    mutationFn: async (payload: any) => {
      console.log("Mutation started with payload:", payload);
      const { data, error } = await supabase.from("budget_floor_clusters").insert(payload).select();
      if (error) {
        console.error("Supabase insert error:", error);
        throw error;
      }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["budget_floor_clusters"] });
      queryClient.refetchQueries({ queryKey: ["budget_floor_clusters"] });
      setIsClusterDialogOpen(false);
      setNewClusterName("");
      setSelectedLines([]);
      setClusterSearchQuery("");
      toast.success("Floor created successfully");
    },
    onError: (err: any) => {
      console.error("Floor creation failed:", err);
      toast.error(`Error: ${err.message || "Failed to create floor"}`);
    },
  });

  const updateClusterMutation = useMutation({
    mutationFn: async ({ id, line_names }: { id: string; line_names: string[] }) => {
      const { error } = await supabase
        .from("budget_floor_clusters")
        .update({ line_names })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["budget_floor_clusters"] });
      toast.success("Cluster lines updated");
    },
  });

  const deleteClusterMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("budget_floor_clusters").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["budget_floor_clusters"] });
      toast.success("Floor cluster removed");
    },
  });

  const getLineValRaw = useCallback(
    (line: string, head: string, type: "budget" | "actual") => {
      const key = `${line}::${head}`;
      if (lineBudgetData[key]) {
        return lineBudgetData[key][type];
      }
      if (!lineDetails) return 0;
      const row = (lineDetails as any[])?.find(
        (d: any) => d.line_name === line && d.cost_head === head,
      );
      return row ? (type === "budget" ? row.budget_value : row.actual_value) : 0;
    },
    [lineDetails, lineBudgetData],
  );

  const getLineVal = useCallback(
    (line: string, head: string, type: "budget" | "actual") => {
      // Calculated efficiency formulas
      if (head === "Efficiency (Gross)" || head === "Efficiency ( Machine)") {
        const isGross = head === "Efficiency (Gross)";
        const stdHourHead = isGross ? "Standard Hour (Gross)" : "Standard Hour (Machine)";
        const denomHead = isGross ? "Total Man-hour" : "Machine-hour";

        const stdVal = getLineValRaw(line, stdHourHead, type);
        const denomVal = getLineValRaw(line, denomHead, type);

        if (denomVal === 0) return 0;
        return (stdVal / denomVal) * 100;
      }

      return getLineValRaw(line, head, type);
    },
    [getLineValRaw],
  );

  const isLoading =
    loadingProfile || loadingLines || loadingDepts || loadingClusters || !loadedPresets;

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-[500px] gap-6 bg-panel/30 rounded-2xl border border-border/50 animate-in fade-in duration-700">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full animate-pulse" />
          <Loader2 className="w-12 h-12 animate-spin text-primary relative z-10" />
        </div>
        <div className="text-center space-y-2">
          <p className="text-lg font-bold bn-gradient-text animate-pulse">
            Syncing Factory Session...
          </p>
          <p className="text-xs text-muted-foreground uppercase tracking-widest font-black opacity-70">
            {loadingProfile
              ? "Authenticating user..."
              : !loadedPresets
                ? "Loading line configurations..."
                : loadingLines
                  ? "Fetching budget details..."
                  : "Optimizing views..."}
          </p>
        </div>
      </div>
    );
  }

  // Fallback if profile didn't load (session issue)
  if (!profile) {
    return (
      <Card className="bg-panel border-amber-500/20 m-6">
        <CardContent className="py-12 flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center mb-4">
            <Factory className="w-6 h-6 text-amber-500" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Factory Session Missing</h3>
          <p className="text-sm text-muted-foreground max-w-md mb-6">
            We couldn't verify your factory assignment. This usually happens if the session expired
            or the profile is incomplete.
          </p>
          <Button onClick={() => window.location.reload()} className="bg-primary">
            Refresh Dashboard
          </Button>
        </CardContent>
      </Card>
    );
  }

  const getDeptVal = (dept: string, head: string, type: "budget" | "actual") => {
    if (!deptDetails) return 0;
    const row = (deptDetails as any[])?.find(
      (d: any) => d.department === dept && d.cost_head === head,
    );
    return row ? (type === "budget" ? row.budget_value : row.actual_value) : 0;
  };

  const handleCopyLine = (line: string) => {
    const lineData: Record<string, { budget: number; actual: number }> = {};
    COST_HEADS.forEach((head) => {
      const key = `${line}::${head}`;
      lineData[head] = {
        budget: lineBudgetData[key]?.budget ?? getLineVal(line, head, "budget"),
        actual: lineBudgetData[key]?.actual ?? getLineVal(line, head, "actual"),
      };
    });
    setCopiedLineData(lineData);
    toast.success(`${line} budget copied to clipboard`);
  };

  const handlePasteLine = (targetLine: string) => {
    if (!copiedLineData) return;

    setLineBudgetData((prev) => {
      const newState = { ...prev };
      Object.entries(copiedLineData).forEach(([head, vals]) => {
        const key = `${targetLine}::${head}`;
        newState[key] = { ...vals };
      });
      return newState;
    });
    toast.success(`Budget pasted to ${targetLine}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {lineQueryError && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-4 text-red-500 shadow-lg animate-in slide-in-from-top-4">
          <div className="p-2 bg-red-500/20 rounded-lg">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h4 className="font-bold text-sm">Data Loading Error</h4>
            <p className="text-xs text-red-400/80">
              {lineQueryError.message?.includes("schema cache") ||
              lineQueryError.message?.includes("could not find")
                ? "We couldn't reach the budget tables. This might be a temporary permission issue or missing table. Please refresh the page or contact support."
                : lineQueryError.message ||
                  "An unexpected error occurred while fetching budget data."}
            </p>
          </div>
          <Button
            variant="secondary"
            size="sm"
            className="bg-red-500/20 hover:bg-red-500/30 text-red-100 border-none transition-all"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["budget_line_details"] })}
          >
            <RefreshCw className="w-4 h-4 mr-2" /> Try Again
          </Button>
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-foreground">Monthly Budget</h2>
          <div className="flex items-center gap-2 mt-1">
            {isSaving || bulkUpsertLineMutation.isPending ? (
              <Badge
                variant="outline"
                className="text-[10px] bg-primary/5 text-primary border-primary/20 flex items-center gap-1.5 py-0 px-2 h-5"
              >
                <Loader2 className="w-2.5 h-2.5 animate-spin" />
                Syncing Views...
              </Badge>
            ) : saveError ? (
              <Badge
                variant="outline"
                className="text-[10px] bg-red-500/5 text-red-500 border-red-500/20 flex items-center gap-1.5 py-0 px-2 h-5"
              >
                <AlertCircle className="w-2.5 h-2.5" />
                Sync Failed
              </Badge>
            ) : Object.keys(lineBudgetData).length > 0 ? (
              <Badge
                variant="outline"
                className="text-[10px] bg-amber-500/5 text-amber-500 border-amber-500/20 flex items-center gap-1.5 py-0 px-2 h-5"
              >
                <Save className="w-2.5 h-2.5" />
                Pending Save
              </Badge>
            ) : (
              <Badge
                variant="outline"
                className="text-[10px] bg-emerald-500/5 text-emerald-500 border-emerald-500/20 flex items-center gap-1.5 py-0 px-2 h-5"
              >
                <CheckCircle2 className="w-2.5 h-2.5" />
                Synced
              </Badge>
            )}
            {lastSyncedAt && (
              <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-tight">
                Last synced: {format(lastSyncedAt, "hh:mm:ss a")}
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              queryClient.invalidateQueries({ queryKey: ["budget_line_details"] });
              queryClient.invalidateQueries({ queryKey: ["budget_department_details"] });
              toast.info("Forcing sync across all views...");
            }}
            className="h-8 gap-2 bg-panel/40 border-border hover:bg-panel/60 transition-all text-xs font-bold"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Sync now
          </Button>
          <div className="flex items-center gap-2 bg-panel/40 p-1.5 rounded-xl border border-border">
            <Label className="text-xs font-bold px-2 text-muted-foreground">Entry Date:</Label>
            <Input
              type="date"
              value={entryDate}
              onChange={(e) => {
                setEntryDate(e.target.value);
                setLineBudgetData({});
              }}
              className="h-8 w-[140px] text-xs bg-panel border-border"
            />
          </div>
          <div className="flex items-center gap-2 bg-panel/40 p-1.5 rounded-xl border border-border">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setCurrentDate(subMonths(currentDate, 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="font-bold text-xs min-w-[100px] text-center uppercase tracking-wider">
              {format(currentDate, "MMMM yyyy")}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setCurrentDate(addMonths(currentDate, 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 max-w-3xl mb-8 bg-panel/50 p-1.5 rounded-2xl border border-border/50">
          <TabsTrigger
            value="line"
            className="flex items-center gap-2 rounded-xl transition-all data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-lg font-bold"
          >
            <LayoutGrid className="w-4 h-4" /> Line Wise
          </TabsTrigger>
          <TabsTrigger
            value="floor"
            className="flex items-center gap-2 rounded-xl transition-all data-[state=active]:bg-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-bold"
          >
            <Layers className="w-4 h-4" /> Floor Wise
          </TabsTrigger>
          <TabsTrigger
            value="full"
            className="flex items-center gap-2 rounded-xl transition-all data-[state=active]:bg-amber-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-bold"
          >
            <Factory className="w-4 h-4" /> Full Factory
          </TabsTrigger>
          <TabsTrigger
            value="custom-floor"
            className="flex items-center gap-2 rounded-xl transition-all data-[state=active]:bg-indigo-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-bold"
          >
            <Plus className="w-4 h-4" /> Club Management
          </TabsTrigger>
        </TabsList>

        <TabsContent value="line" className="space-y-4">
          <Card className="bg-panel border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <Label className="text-sm font-bold">Select Sewing Lines:</Label>
                  <Select
                    isMulti
                    options={(linePresets || [])
                      .filter((n) => {
                        const normalized = normLine(n);
                        const num = parseInt(normalized);
                        return isNaN(num) || num >= 15;
                      })
                      .map((name: string) => ({ value: name, label: name }))}
                    value={selectedLinesForView.map((name) => ({ value: name, label: name }))}
                    onChange={(selected: any) => {
                      const values = selected ? selected.map((s: any) => s.value) : [];
                      setSelectedLinesForView(values);
                      setLineBudgetData({}); // Reset local changes when switching lines
                    }}
                    placeholder={!loadedPresets ? "Loading lines..." : "Choose lines..."}
                    className="min-w-[320px] text-sm react-select-container"
                    classNamePrefix="react-select"
                    menuPortalTarget={typeof document !== "undefined" ? document.body : null}
                    styles={{
                      control: (base) => ({
                        ...base,
                        backgroundColor: "#1a1f2c",
                        borderColor: "#334155",
                        color: "#fff",
                      }),
                      singleValue: (base) => ({
                        ...base,
                        color: "#fff",
                      }),
                      multiValue: (base) => ({
                        ...base,
                        backgroundColor: "#334155",
                      }),
                      multiValueLabel: (base) => ({
                        ...base,
                        color: "#fff",
                      }),
                      menu: (base) => ({
                        ...base,
                        backgroundColor: "#1a1f2c",
                        border: "1px solid #334155",
                        zIndex: 100000,
                      }),
                      menuPortal: (base) => ({
                        ...base,
                        zIndex: 100000,
                      }),
                      option: (base, state) => ({
                        ...base,
                        backgroundColor: state.isFocused ? "#334155" : "transparent",
                        color: "#fff",
                      }),
                      placeholder: (base) => ({
                        ...base,
                        color: "#94a3b8",
                      }),
                    }}
                  />
                </div>
                <div className="flex items-center gap-3">
                  {saveError && (
                    <div className="flex items-center gap-3 text-xs text-red-500 bg-red-500/10 px-4 py-2 rounded-lg border border-red-500/20 shadow-sm animate-in slide-in-from-top-2 duration-300">
                      <div className="p-1.5 bg-red-500/20 rounded-md">
                        <AlertCircle className="w-4 h-4" />
                      </div>
                      <div className="flex flex-col">
                        <span className="font-bold text-[13px]">Save Failed</span>
                        <span className="text-red-400/80 leading-tight">
                          {saveError.includes("schema cache") ||
                          saveError.includes("could not find")
                            ? "Database connection issue: Missing table or permissions. Please contact your administrator or refresh the page."
                            : saveError}
                        </span>
                      </div>
                      <Button
                        variant="secondary"
                        size="sm"
                        className="h-8 px-3 ml-2 bg-red-500/20 hover:bg-red-500/30 text-red-100 border-none transition-all"
                        onClick={() => {
                          setCooldownRemaining(0);
                          saveLineBudget();
                        }}
                      >
                        <RefreshCw className="w-3 h-3 mr-2" /> Retry Now
                      </Button>
                    </div>
                  )}
                  {isSaving && !saveError && (
                    <div className="flex items-center gap-2 text-xs text-primary animate-pulse">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      Saving changes...
                    </div>
                  )}
                  {!isSaving && !saveError && Object.keys(lineBudgetData).length > 0 && (
                    <Button
                      size="sm"
                      onClick={() => saveLineBudget()}
                      className="bg-primary hover:bg-primary/90 text-white shadow-lg animate-in fade-in zoom-in duration-300"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </Button>
                  )}
                  {Object.keys(lineBudgetData).length === 0 && !isSaving && !saveError && (
                    <div className="text-xs text-emerald-500 font-medium flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      All changes saved
                    </div>
                  )}
                </div>
              </div>

              {selectedLinesForView.length > 0 ? (
                <div className="overflow-x-auto rounded-xl border border-border">
                  <Table>
                    <TableHeader className="bg-muted/50">
                      <TableRow>
                        <TableHead className="w-[300px] font-bold sticky left-0 bg-panel z-10 border-r border-border">
                          Cost Heads
                        </TableHead>
                        {selectedLinesForView.map((line) => (
                          <TableHead
                            key={line}
                            className="text-center font-bold border-l border-border bg-primary/5 min-w-[240px]"
                          >
                            <div className="flex items-center justify-center gap-2 mb-1">
                              {line}
                              <div className="flex items-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-muted-foreground hover:text-primary transition-colors"
                                  title={`Copy ${line} budget`}
                                  onClick={() => handleCopyLine(line)}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className={`h-6 w-6 transition-colors ${copiedLineData ? "text-amber-500 hover:text-amber-600" : "text-muted-foreground/30 cursor-not-allowed"}`}
                                  title={
                                    copiedLineData ? `Paste budget to ${line}` : "Nothing to paste"
                                  }
                                  onClick={() => handlePasteLine(line)}
                                  disabled={!copiedLineData}
                                >
                                  <Clipboard className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-1 mt-1 text-[10px] uppercase font-bold text-muted-foreground">
                              <span>Budget</span>
                              <span>Actual</span>
                            </div>
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {COST_HEADS.map((head) => {
                        return (
                          <TableRow key={head} className="hover:bg-muted/30">
                            <TableCell className="font-medium text-sm sticky left-0 bg-panel z-10 border-r border-border">
                              {head}
                            </TableCell>
                            {selectedLinesForView.map((line) => {
                              const bVal = getLineVal(line, head, "budget");
                              const aVal = getLineVal(line, head, "actual");
                              const key = `${line}::${head}`;
                              const isCalculated =
                                head === "Efficiency (Gross)" || head === "Efficiency ( Machine)";
                              return (
                                <TableCell key={line} className="p-2 border-l border-border">
                                  <div className="grid grid-cols-2 gap-2">
                                    <Input
                                      type="number"
                                      className={`h-8 text-center text-xs ${isCalculated ? "bg-muted/50 font-bold text-primary" : ""}`}
                                      value={
                                        isCalculated
                                          ? getLineVal(line, head, "budget").toFixed(2)
                                          : (lineBudgetData[key]?.budget ?? (bVal || ""))
                                      }
                                      onChange={(e) =>
                                        !isCalculated &&
                                        handleLineDataChange(
                                          line,
                                          head,
                                          "budget",
                                          parseFloat(e.target.value) || 0,
                                        )
                                      }
                                      readOnly={isCalculated}
                                    />
                                    <Input
                                      type="number"
                                      className={`h-8 text-center text-xs ${isCalculated ? "bg-muted/50 font-bold text-primary" : ""}`}
                                      value={
                                        isCalculated
                                          ? getLineVal(line, head, "actual").toFixed(2)
                                          : (lineBudgetData[key]?.actual ?? (aVal || ""))
                                      }
                                      onChange={(e) =>
                                        !isCalculated &&
                                        handleLineDataChange(
                                          line,
                                          head,
                                          "actual",
                                          parseFloat(e.target.value) || 0,
                                        )
                                      }
                                      readOnly={isCalculated}
                                    />
                                  </div>
                                </TableCell>
                              );
                            })}
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-20 text-muted-foreground italic border-2 border-dashed border-border rounded-xl">
                  Please select one or more sewing lines to view and edit their budget details.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="floor" className="space-y-4">
          <Card className="bg-panel border-border">
            <CardContent className="pt-6">
              <div className="flex flex-col gap-4 mb-6">
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Label className="text-sm font-bold whitespace-nowrap">Filter Floors:</Label>
                    <div className="relative w-[300px]">
                      <Select
                        isMulti
                        options={[
                          { value: "all", label: "All Factory Lines" },
                          ...(clusters || []).map((c: any) => ({
                            value: c.id,
                            label: c.cluster_name,
                          })),
                        ]}
                        value={[
                          ...(selectedFloorIds.includes("all")
                            ? [{ value: "all", label: "All Factory Lines" }]
                            : []),
                          ...(clusters || [])
                            .filter((c: any) => selectedFloorIds.includes(c.id))
                            .map((c: any) => ({ value: c.id, label: c.cluster_name })),
                        ]}
                        onChange={(selected: any) => {
                          const values = selected ? selected.map((s: any) => s.value) : [];
                          // If "all" is selected, it should probably clear others or vice-versa
                          // For simplicity here, just set whatever is selected
                          setSelectedFloorIds(values);
                        }}
                        placeholder="Search & Select Floors..."
                        className="text-sm react-select-container"
                        classNamePrefix="react-select"
                        styles={{
                          control: (base) => ({
                            ...base,
                            backgroundColor: "#1a1f2c",
                            borderColor: "#334155",
                            color: "#fff",
                          }),
                          multiValue: (base) => ({
                            ...base,
                            backgroundColor: "#334155",
                          }),
                          multiValueLabel: (base) => ({
                            ...base,
                            color: "#fff",
                          }),
                          multiValueRemove: (base) => ({
                            ...base,
                            color: "#fff",
                            ":hover": {
                              backgroundColor: "#ef4444",
                              color: "#fff",
                            },
                          }),
                          menu: (base) => ({
                            ...base,
                            backgroundColor: "#1a1f2c",
                            border: "1px solid #334155",
                            zIndex: 100,
                          }),
                          option: (base, state) => ({
                            ...base,
                            backgroundColor: state.isFocused ? "#334155" : "transparent",
                            color: "#fff",
                          }),
                        }}
                      />
                    </div>
                  </div>

                  {selectedFloorIds.length > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedFloorIds([])}
                      className="h-8 border-dashed border-primary/50 text-primary hover:bg-primary/10"
                    >
                      <X className="w-3 h-3 mr-1" /> Clear Filters
                    </Button>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 items-center">
                  <Badge variant="outline" className="bg-panel border-border text-xs py-1 px-3">
                    <Filter className="w-3 h-3 mr-2 text-primary" />
                    {selectedFloorIds.length === 0
                      ? "Showing all active factory lines"
                      : `Filtering ${selectedFloorIds.length} floor(s)`}
                  </Badge>
                  {selectedFloorIds.map((id) => {
                    const name =
                      id === "all"
                        ? "All Factory Lines"
                        : clusters.find((c: any) => c.id === id)?.cluster_name;
                    return name ? (
                      <Badge
                        key={id}
                        variant="secondary"
                        className="bg-primary/10 text-primary border-primary/20 flex items-center gap-1"
                      >
                        {name}
                        <X
                          className="w-3 h-3 cursor-pointer hover:text-white"
                          onClick={() =>
                            setSelectedFloorIds((prev) => prev.filter((p) => p !== id))
                          }
                        />
                      </Badge>
                    ) : null;
                  })}
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-border bg-panel shadow-sm">
                <Table className="min-w-[1200px]">
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead className="w-[250px] sticky left-0 bg-muted/50 z-20 font-bold">
                        Cost Heads
                      </TableHead>
                      {(linePresets || [])
                        .filter((l) => {
                          if (selectedFloorIds.length === 0 || selectedFloorIds.includes("all"))
                            return true;
                          return clusters.some(
                            (c: any) => selectedFloorIds.includes(c.id) && c.line_names.includes(l),
                          );
                        })
                        .map((l: string, idx: number) => (
                          <TableHead
                            key={`${l}-${idx}`}
                            className="text-center min-w-[300px] border-l border-border"
                          >
                            <div className="font-black text-primary">{l}</div>
                            <div className="grid grid-cols-3 gap-1 mt-1 text-[10px] uppercase font-bold text-muted-foreground">
                              <span>Budget</span>
                              <span>Actual</span>
                              <span>Dev.</span>
                            </div>
                          </TableHead>
                        ))}
                      <TableHead className="text-center min-w-[300px] border-l border-border bg-primary/5">
                        <div className="font-black text-primary">Summary</div>
                        <div className="grid grid-cols-3 gap-1 mt-1 text-[10px] uppercase font-bold text-muted-foreground">
                          <span>Budget</span>
                          <span>Actual</span>
                          <span>Dev.</span>
                        </div>
                      </TableHead>
                      <TableHead className="text-center min-w-[300px] border-l border-border bg-emerald-500/5">
                        <div className="font-black text-emerald-500 uppercase">Cutting</div>
                        <div className="grid grid-cols-3 gap-1 mt-1 text-[10px] uppercase font-bold text-muted-foreground">
                          <span>Budget</span>
                          <span>Actual</span>
                          <span>Dev.</span>
                        </div>
                      </TableHead>
                      <TableHead className="text-center min-w-[300px] border-l border-border bg-amber-500/5">
                        <div className="font-black text-amber-500 uppercase">Finishing</div>
                        <div className="grid grid-cols-3 gap-1 mt-1 text-[10px] uppercase font-bold text-muted-foreground">
                          <span>Budget</span>
                          <span>Actual</span>
                          <span>Dev.</span>
                        </div>
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {COST_HEADS.map((head) => {
                      let summaryBudgetSum = 0;
                      let summaryActualSum = 0;

                      const visibleLines = (linePresets || []).filter((l) => {
                        if (selectedFloorIds.length === 0 || selectedFloorIds.includes("all"))
                          return true;
                        return clusters.some(
                          (c: any) => selectedFloorIds.includes(c.id) && c.line_names.includes(l),
                        );
                      });

                      return (
                        <TableRow key={head} className="hover:bg-muted/30">
                          <TableCell className="font-bold text-xs sticky left-0 bg-panel z-10 border-r border-border">
                            {head}
                          </TableCell>
                          {visibleLines.map((l: string, idx: number) => {
                            const bVal = getLineVal(l, head, "budget");
                            const aVal = getLineVal(l, head, "actual");
                            summaryBudgetSum += bVal;
                            summaryActualSum += aVal;
                            return (
                              <TableCell key={`${l}-${idx}`} className="p-1 border-l border-border">
                                <div className="grid grid-cols-3 gap-1">
                                  <div className="h-7 px-1 text-[11px] text-center flex items-center justify-center bg-panel/50 border border-border/50 rounded">
                                    {bVal.toLocaleString()}
                                  </div>
                                  <div className="h-7 px-1 text-[11px] text-center flex items-center justify-center bg-panel/50 border border-border/50 rounded">
                                    {aVal.toLocaleString()}
                                  </div>
                                  <div
                                    className={`h-7 flex items-center justify-center text-[10px] font-bold rounded ${aVal - bVal > 0 ? "text-red-400 bg-red-500/10" : "text-emerald-400 bg-emerald-500/10"}`}
                                  >
                                    {(aVal - bVal).toLocaleString()}
                                  </div>
                                </div>
                              </TableCell>
                            );
                          })}
                          {/* Summary */}
                          <TableCell className="p-1 border-l border-border bg-primary/5">
                            <div className="grid grid-cols-3 gap-1 text-[11px] font-black text-center">
                              <div className="h-7 flex items-center justify-center">
                                {summaryBudgetSum.toLocaleString()}
                              </div>
                              <div className="h-7 flex items-center justify-center">
                                {summaryActualSum.toLocaleString()}
                              </div>
                              <div
                                className={`h-7 flex items-center justify-center rounded ${summaryActualSum - summaryBudgetSum > 0 ? "text-red-400 bg-red-500/10" : "text-emerald-400 bg-emerald-500/10"}`}
                              >
                                {(summaryActualSum - summaryBudgetSum).toLocaleString()}
                              </div>
                            </div>
                          </TableCell>
                          {/* Cutting */}
                          <DeptCells
                            dept="Cutting"
                            head={head}
                            profile={profile}
                            monthStr={monthStr}
                            entryDate={entryDate}
                            getDeptVal={getDeptVal}
                            upsertDeptMutation={upsertDeptMutation}
                          />
                          {/* Finishing */}
                          <DeptCells
                            dept="Finishing"
                            head={head}
                            profile={profile}
                            monthStr={monthStr}
                            entryDate={entryDate}
                            getDeptVal={getDeptVal}
                            upsertDeptMutation={upsertDeptMutation}
                          />
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="full" className="space-y-4">
          <Card className="bg-panel border-border shadow-lg">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-8 border-b border-border pb-4">
                <div>
                  <h3 className="text-2xl font-black text-primary uppercase flex items-center gap-2">
                    <Factory className="w-6 h-6" /> Full Factory Budget Consolidation
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1 italic">
                    Aggregate view of all production lines and departments
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge
                    variant="outline"
                    className="px-4 py-1.5 bg-primary/5 border-primary/20 text-primary font-bold"
                  >
                    {format(currentDate, "MMMM yyyy")}
                  </Badge>
                  <Badge
                    variant="outline"
                    className="px-4 py-1.5 bg-emerald-500/5 border-emerald-500/20 text-emerald-500 font-bold"
                  >
                    {linePresets?.length || 0} Lines Active
                  </Badge>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-border shadow-sm">
                <Table className="min-w-[800px]">
                  <TableHeader className="bg-muted/50">
                    <TableRow className="border-b-2 border-primary/20">
                      <TableHead className="w-[350px] font-black text-sm uppercase tracking-wider">
                        Cost Heads
                      </TableHead>
                      <TableHead className="text-center font-black text-sm uppercase tracking-wider bg-primary/5 min-w-[150px]">
                        Factory Budget
                      </TableHead>
                      <TableHead className="text-center font-black text-sm uppercase tracking-wider bg-emerald-500/5 min-w-[150px]">
                        Factory Actual
                      </TableHead>
                      <TableHead className="text-center font-black text-sm uppercase tracking-wider bg-muted/50 min-w-[150px]">
                        Variance (Dev.)
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {COST_HEADS.map((head) => {
                      // Sum across ALL active factory lines
                      const lineBudgetSum = (linePresets || []).reduce(
                        (acc, ln) => acc + getLineVal(ln, head, "budget"),
                        0,
                      );
                      const lineActualSum = (linePresets || []).reduce(
                        (acc, ln) => acc + getLineVal(ln, head, "actual"),
                        0,
                      );

                      // Sum across Departments (Cutting & Finishing)
                      const depts = ["Cutting", "Finishing"];
                      const deptBudgetSum = depts.reduce(
                        (acc, d) => acc + getDeptVal(d, head, "budget"),
                        0,
                      );
                      const deptActualSum = depts.reduce(
                        (acc, d) => acc + getDeptVal(d, head, "actual"),
                        0,
                      );

                      const totalBudget = lineBudgetSum + deptBudgetSum;
                      const totalActual = lineActualSum + deptActualSum;
                      const variance = totalActual - totalBudget;
                      const isNegative = variance > 0;

                      return (
                        <TableRow
                          key={head}
                          className="hover:bg-primary/5 transition-colors border-b border-border/50 group"
                        >
                          <TableCell className="font-bold text-[13px] text-white/90 group-hover:text-primary transition-colors py-4">
                            {head}
                          </TableCell>
                          <TableCell className="text-center py-4 bg-primary/5 font-black text-sm">
                            {totalBudget.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </TableCell>
                          <TableCell className="text-center py-4 bg-emerald-500/5 font-black text-sm text-emerald-400">
                            {totalActual.toLocaleString(undefined, {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                          </TableCell>
                          <TableCell className="text-center py-4">
                            <div
                              className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-black ${
                                isNegative
                                  ? "text-red-400 bg-red-500/10 border border-red-500/20"
                                  : "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20"
                              }`}
                            >
                              {variance > 0 ? "+" : ""}
                              {variance.toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              })}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>

              {/* Final Totals Footer */}
              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-[#1e293b] border-primary/20 border-t-4 border-t-primary shadow-xl">
                  <CardContent className="pt-6 text-center">
                    <p className="text-[10px] uppercase font-black tracking-widest text-muted-foreground mb-2">
                      Total Factory Budget
                    </p>
                    <h4 className="text-2xl font-black text-white">
                      {COST_HEADS.reduce((acc, head) => {
                        const lineSum = (linePresets || []).reduce(
                          (lAcc, ln) => lAcc + getLineVal(ln, head, "budget"),
                          0,
                        );
                        const deptSum = ["Cutting", "Finishing"].reduce(
                          (dAcc, d) => dAcc + getDeptVal(d, head, "budget"),
                          0,
                        );
                        return acc + lineSum + deptSum;
                      }, 0).toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </h4>
                  </CardContent>
                </Card>
                <Card className="bg-[#1e293b] border-emerald-500/20 border-t-4 border-t-emerald-500 shadow-xl">
                  <CardContent className="pt-6 text-center">
                    <p className="text-[10px] uppercase font-black tracking-widest text-muted-foreground mb-2">
                      Total Factory Actual
                    </p>
                    <h4 className="text-2xl font-black text-emerald-400">
                      {COST_HEADS.reduce((acc, head) => {
                        const lineSum = (linePresets || []).reduce(
                          (lAcc, ln) => lAcc + getLineVal(ln, head, "actual"),
                          0,
                        );
                        const deptSum = ["Cutting", "Finishing"].reduce(
                          (dAcc, d) => dAcc + getDeptVal(d, head, "actual"),
                          0,
                        );
                        return acc + lineSum + deptSum;
                      }, 0).toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </h4>
                  </CardContent>
                </Card>
                <Card className="bg-[#1e293b] border-amber-500/20 border-t-4 border-t-amber-500 shadow-xl">
                  <CardContent className="pt-6 text-center">
                    <p className="text-[10px] uppercase font-black tracking-widest text-muted-foreground mb-2">
                      Total Variance
                    </p>
                    {(() => {
                      const budgetTotal = COST_HEADS.reduce((acc, head) => {
                        const lineSum = (linePresets || []).reduce(
                          (lAcc, ln) => lAcc + getLineVal(ln, head, "budget"),
                          0,
                        );
                        const deptSum = ["Cutting", "Finishing"].reduce(
                          (dAcc, d) => dAcc + getDeptVal(d, head, "budget"),
                          0,
                        );
                        return acc + lineSum + deptSum;
                      }, 0);
                      const actualTotal = COST_HEADS.reduce((acc, head) => {
                        const lineSum = (linePresets || []).reduce(
                          (lAcc, ln) => lAcc + getLineVal(ln, head, "actual"),
                          0,
                        );
                        const deptSum = ["Cutting", "Finishing"].reduce(
                          (dAcc, d) => dAcc + getDeptVal(d, head, "actual"),
                          0,
                        );
                        return acc + lineSum + deptSum;
                      }, 0);
                      const diff = actualTotal - budgetTotal;
                      return (
                        <h4
                          className={`text-2xl font-black ${diff > 0 ? "text-red-400" : "text-emerald-400"}`}
                        >
                          {diff > 0 ? "+" : ""}
                          {diff.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </h4>
                      );
                    })()}
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="custom-floor" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-foreground">
              Customized Floor Wise Lines Club
            </h3>
            <Dialog
              open={isClusterDialogOpen}
              onOpenChange={(open) => {
                setIsClusterDialogOpen(open);
                if (!open) setClusterSearchQuery("");
              }}
            >
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="w-4 h-4" /> Create New Club
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl bg-[#1A1F2C] border-[#334155] text-white">
                <DialogHeader className="border-b border-border/50 pb-4">
                  <DialogTitle className="text-xl font-bold text-primary flex items-center gap-2">
                    <Factory className="w-5 h-5" /> Create New Floor
                  </DialogTitle>
                </DialogHeader>

                <div className="py-6 space-y-6">
                  {/* Step 1: Floor Name */}
                  <div className="space-y-3">
                    <Label
                      htmlFor="clusterName"
                      className="text-sm font-bold flex items-center gap-2 text-white/80"
                    >
                      <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary/20 text-primary text-[10px]">
                        1
                      </span>
                      Floor / Cluster Name
                    </Label>
                    <Input
                      id="clusterName"
                      placeholder="e.g. 2nd Floor, Section A..."
                      value={newClusterName}
                      onChange={(e) => setNewClusterName(e.target.value)}
                      className="bg-[#0f172a] border-[#334155] focus:border-primary/50 text-white placeholder:text-muted-foreground/50 h-11"
                    />
                  </div>

                  {/* Step 2: Line Selection */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-bold flex items-center gap-2 text-white/80">
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary/20 text-primary text-[10px]">
                          2
                        </span>
                        Select Lines ({selectedLines.length} selected)
                      </Label>
                      {linePresets.length > 5 && (
                        <div className="relative">
                          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="Filter lines..."
                            value={clusterSearchQuery}
                            onChange={(e) => setClusterSearchQuery(e.target.value)}
                            className="h-8 w-40 pl-8 text-xs bg-[#0f172a] border-[#334155] text-white"
                          />
                        </div>
                      )}
                    </div>

                    <div className="border border-[#334155] rounded-xl bg-[#0f172a] p-3">
                      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-[280px] overflow-y-auto custom-scrollbar pr-1">
                        {(linePresets || [])
                          .filter((name) => {
                            const num = parseInt(name);
                            if (!isNaN(num) && num < 15) return false;
                            return name.toLowerCase().includes(clusterSearchQuery.toLowerCase());
                          })
                          .map((name: string) => {
                            const isSelected = selectedLines.includes(name);
                            return (
                              <button
                                key={name}
                                type="button"
                                onClick={() => {
                                  if (isSelected) {
                                    setSelectedLines((prev) => prev.filter((l) => l !== name));
                                  } else {
                                    setSelectedLines((prev) => [...prev, name]);
                                  }
                                }}
                                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200 group ${
                                  isSelected
                                    ? "bg-primary/20 border-primary text-primary shadow-[0_0_15px_rgba(var(--primary-rgb),0.1)]"
                                    : "bg-panel/50 border-[#334155] text-white/60 hover:border-primary/50 hover:bg-panel"
                                }`}
                              >
                                <div
                                  className={`w-6 h-6 rounded-full border flex items-center justify-center mb-2 transition-colors ${
                                    isSelected
                                      ? "bg-primary border-primary text-white"
                                      : "border-[#334155] text-transparent group-hover:border-primary/50"
                                  }`}
                                >
                                  {isSelected && <Save className="w-3 h-3" />}
                                </div>
                                <span className="text-xs font-black uppercase tracking-wider">
                                  {name}
                                </span>
                              </button>
                            );
                          })}

                        {linePresets.length === 0 && loadedPresets && (
                          <div className="col-span-full py-8 text-center text-amber-500/80 bg-amber-500/5 rounded-xl border border-dashed border-amber-500/20">
                            <p className="text-sm font-medium">No line presets found.</p>
                            <p className="text-[10px] mt-1 opacity-70">
                              Add lines in "Plan Input" tab first.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <DialogFooter className="border-t border-border/50 pt-4 gap-2">
                  <Button
                    variant="ghost"
                    onClick={() => setIsClusterDialogOpen(false)}
                    className="text-white/60 hover:text-white hover:bg-white/5"
                  >
                    Cancel
                  </Button>
                  <Button
                    disabled={
                      !newClusterName.trim() ||
                      selectedLines.length === 0 ||
                      createClusterMutation.isPending
                    }
                    onClick={() => {
                      if (!profile?.factory_id) {
                        console.error(
                          "Mutation blocked: factory_id is missing in profile",
                          profile,
                        );
                        toast.error("Factory session error. Try refreshing the page.");
                        queryClient.invalidateQueries({ queryKey: ["profile"] });
                        return;
                      }

                      const payload = {
                        factory_id: profile.factory_id,
                        cluster_name: newClusterName.trim(),
                        line_names: selectedLines,
                      };

                      console.log("Creating floor with payload:", payload);
                      createClusterMutation.mutate(payload);
                    }}
                    className="bg-primary hover:bg-primary/90 text-white font-bold px-8 shadow-lg shadow-primary/20"
                  >
                    {createClusterMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Create Floor"
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {clusters.length === 0 && !loadingClusters && (
              <div className="col-span-full py-12 text-center border-2 border-dashed border-border rounded-2xl bg-panel/30">
                <LayoutGrid className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-20" />
                <h4 className="text-lg font-bold text-muted-foreground">No floors created yet</h4>
                <p className="text-sm text-muted-foreground mt-2 italic">
                  Use the "Create New Club" button to organize your production lines into floors.
                </p>
              </div>
            )}
            {clusters.map((cluster: any) => (
              <Card
                key={cluster.id}
                className="overflow-hidden border-t-4 border-t-primary shadow-sm bg-panel"
              >
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="text-xl font-black text-primary uppercase">
                        {cluster.cluster_name}
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        {cluster.line_names.length} Lines included
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:bg-destructive/10"
                      onClick={() => {
                        if (confirm(`Delete ${cluster.cluster_name}?`)) {
                          deleteClusterMutation.mutate(cluster.id);
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex gap-4 min-h-[160px]">
                    <div className="flex-1 space-y-2 border-r border-dashed border-border pr-4">
                      <Label className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1">
                        <Layers className="w-3 h-3" /> Floor Details
                      </Label>
                      <div className="space-y-3">
                        <div className="bg-muted/30 p-2 rounded-lg">
                          <div className="text-[10px] text-muted-foreground uppercase font-bold">
                            Monthly Budget
                          </div>
                          <div className="text-lg font-black">
                            {COST_HEADS.reduce((acc, head) => {
                              return (
                                acc +
                                cluster.line_names.reduce(
                                  (lAcc: number, ln: string) =>
                                    lAcc + getLineVal(ln, head, "budget"),
                                  0,
                                )
                              );
                            }, 0).toLocaleString()}
                          </div>
                        </div>
                        <div className="bg-muted/30 p-2 rounded-lg">
                          <div className="text-[10px] text-muted-foreground uppercase font-bold">
                            Actual Cost
                          </div>
                          <div className="text-lg font-black text-primary">
                            {COST_HEADS.reduce((acc, head) => {
                              return (
                                acc +
                                cluster.line_names.reduce(
                                  (lAcc: number, ln: string) =>
                                    lAcc + getLineVal(ln, head, "actual"),
                                  0,
                                )
                              );
                            }, 0).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex-1 space-y-2 pl-2">
                      <Label className="text-[10px] uppercase font-bold text-muted-foreground flex items-center gap-1">
                        <LayoutGrid className="w-3 h-3" /> Lines Included
                      </Label>
                      <div className="max-h-[150px] overflow-y-auto pr-1 custom-scrollbar">
                        <div className="grid grid-cols-2 gap-2">
                          {cluster.line_names.map((ln: string) => (
                            <div
                              key={ln}
                              className="text-[11px] font-bold bg-panel border border-border px-2 py-1 rounded-lg text-center truncate flex items-center justify-center gap-1 group/item"
                            >
                              {ln}
                              <button
                                onClick={() => {
                                  const newLines = cluster.line_names.filter(
                                    (l: string) => l !== ln,
                                  );
                                  updateClusterMutation.mutate({
                                    id: cluster.id,
                                    line_names: newLines,
                                  });
                                }}
                                className="opacity-0 group-hover/item:opacity-100 text-destructive hover:scale-110 transition-all"
                              >
                                <Trash2 className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="mt-2">
                        <Label className="text-[8px] uppercase font-bold text-muted-foreground block mb-1">
                          Edit Lines
                        </Label>
                        <Select
                          isMulti
                          options={(linePresets || [])
                            .filter((n) => {
                              const num = parseInt(n);
                              return isNaN(num) || num >= 15;
                            })
                            .map((name: string) => ({ value: name, label: name }))}
                          defaultValue={cluster.line_names.map((name: string) => ({
                            value: name,
                            label: name,
                          }))}
                          onChange={(selected: any) => {
                            const values = selected ? selected.map((s: any) => s.value) : [];
                            updateClusterMutation.mutate({ id: cluster.id, line_names: values });
                          }}
                          placeholder="Add/Remove..."
                          className="text-[10px]"
                          classNamePrefix="react-select"
                          menuPortalTarget={typeof document !== "undefined" ? document.body : null}
                          styles={{
                            control: (base) => ({
                              ...base,
                              backgroundColor: "#1a1f2c",
                              borderColor: "#334155",
                              minHeight: "28px",
                              fontSize: "10px",
                            }),
                            multiValue: (base) => ({
                              ...base,
                              backgroundColor: "#334155",
                            }),
                            multiValueLabel: (base) => ({
                              ...base,
                              color: "#fff",
                            }),
                            menuPortal: (base) => ({ ...base, zIndex: 100000 }),
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function DeptCells({
  dept,
  head,
  profile,
  monthStr,
  entryDate,
  getDeptVal,
  upsertDeptMutation,
}: any) {
  const bVal = getDeptVal(dept, head, "budget");
  const aVal = getDeptVal(dept, head, "actual");
  const colorClass = dept === "Cutting" ? "bg-emerald-500/5" : "bg-amber-500/5";

  return (
    <TableCell className={`p-1 border-l border-border ${colorClass}`}>
      <div className="grid grid-cols-3 gap-1">
        <Input
          type="number"
          className="h-7 px-1 text-[11px] text-center"
          defaultValue={bVal || ""}
          onBlur={(e) => {
            if (!profile?.factory_id) return;
            upsertDeptMutation.mutate({
              factory_id: profile.factory_id,
              month: monthStr,
              entry_date: entryDate,
              department: dept,
              cost_head: head,
              budget_value: parseFloat(e.target.value) || 0,
              actual_value: aVal,
            });
          }}
        />
        <Input
          type="number"
          className="h-7 px-1 text-[11px] text-center"
          defaultValue={aVal || ""}
          onBlur={(e) => {
            if (!profile?.factory_id) return;
            upsertDeptMutation.mutate({
              factory_id: profile.factory_id,
              month: monthStr,
              entry_date: entryDate,
              department: dept,
              cost_head: head,
              budget_value: bVal,
              actual_value: parseFloat(e.target.value) || 0,
            });
          }}
        />
        <div
          className={`h-7 flex items-center justify-center text-[10px] font-bold rounded ${aVal - bVal > 0 ? "text-red-400 bg-red-500/10" : "text-emerald-400 bg-emerald-500/10"}`}
        >
          {(aVal - bVal).toLocaleString()}
        </div>
      </div>
    </TableCell>
  );
}
