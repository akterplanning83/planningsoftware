import { useEffect, useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { toast } from "sonner";
import { Loader2, Trash2, Pencil, FileSpreadsheet, CheckCircle2, Search, X } from "lucide-react";
import type { PlanResult } from "@/lib/plan-calc";
import { exportMicroPlan } from "@/lib/micro-plan-export";
import { FilterSelect } from "./LineSummaryView";

type MatrixPlan = {
  id: string;
  buyer: string;
  style: string;
  created_by: string;
  calc_result: PlanResult;
};

export function MatrixView() {
  const { data: user } = useCurrentUser();
  const qc = useQueryClient();
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [styleFilter, setStyleFilter] = useState<string[]>([]);
  const [search, setSearch] = useState("");

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "matrix"],
    queryFn: async (): Promise<MatrixPlan[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, created_by, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as MatrixPlan[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-matrix-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("plans").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("প্ল্যান ডিলিট হয়েছে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const complete = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("plans")
        .update({ completed_at: new Date().toISOString() } as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("অর্ডার Complete হয়েছে — Complete Order ট্যাবে দেখা যাবে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const buyerOptions = useMemo(
    () => Array.from(new Set(plans.map((p) => p.buyer))).sort(),
    [plans],
  );
  const styleOptions = useMemo(
    () => Array.from(new Set(plans.map((p) => p.style))).sort(),
    [plans],
  );

  const filteredPlans = useMemo(() => {
    const q = search.trim().toLowerCase();
    return plans.filter(
      (p) =>
        (buyerFilter.length === 0 || buyerFilter.includes(p.buyer)) &&
        (styleFilter.length === 0 || styleFilter.includes(p.style)) &&
        (q === "" || p.buyer.toLowerCase().includes(q) || p.style.toLowerCase().includes(q)),
    );
  }, [plans, buyerFilter, styleFilter, search]);

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (plans.length === 0) {
    return (
      <div className="p-12 text-center">
        <p className="text-sm text-muted-foreground">কোনো ক্লাউড ডাটা নেই!</p>
        <p className="text-xs text-muted-foreground mt-1">
          প্ল্যান ইনপুট ট্যাব থেকে নতুন প্ল্যান সেভ করুন।
        </p>
      </div>
    );
  }

  // Collect all months across filtered plans, sorted chronologically
  const monthSet = new Set<string>();
  filteredPlans.forEach((p) => {
    for (const m in p.calc_result?.monthlyBreakdown ?? {}) monthSet.add(m);
  });
  const sortedMonths = Array.from(monthSet).sort(
    (a, b) => new Date("1 " + a).getTime() - new Date("1 " + b).getTime(),
  );

  const monthTotals: Record<string, { qty: number; days: number }> = {};
  sortedMonths.forEach((m) => (monthTotals[m] = { qty: 0, days: 0 }));
  let grandQty = 0;
  let grandDays = 0;

  filteredPlans.forEach((p) => {
    grandQty += p.calc_result?.totalPlannedQty ?? 0;
    grandDays += p.calc_result?.totalLineDaysSum ?? 0;
    for (const m of sortedMonths) {
      const d = p.calc_result?.monthlyBreakdown?.[m];
      if (d) {
        monthTotals[m].qty += d.qty;
        monthTotals[m].days += d.days;
      }
    }
  });

  const isAdmin = user?.role === "admin";
  const hasFilter = buyerFilter.length > 0 || styleFilter.length > 0 || search.trim() !== "";

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 space-y-3">
        <div>
          <h2 className="text-base md:text-lg font-bold text-emerald-400">
            📊 লাইভ ক্লাউড মাস্টার প্রোডাকশন লোড ও ম্যাট্রিক্স
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            সব স্টাইলের মাসভিত্তিক প্ল্যান, দিন ও কোয়ান্টিটি
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="বায়ার / স্টাইল সার্চ..."
              className="pl-8 pr-8 py-1.5 text-xs rounded-lg bg-panel border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-emerald-500/60 w-56"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <FilterSelect
            label="Buyer"
            value={buyerFilter}
            onChange={setBuyerFilter}
            options={buyerOptions}
          />
          <FilterSelect
            label="Style"
            value={styleFilter}
            onChange={setStyleFilter}
            options={styleOptions}
          />
          {hasFilter && (
            <button
              onClick={() => {
                setBuyerFilter([]);
                setStyleFilter([]);
                setSearch("");
              }}
              className="text-xs font-bold text-red-300 hover:text-red-200 underline"
            >
              Clear
            </button>
          )}
          <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-500/50 px-3 py-1 rounded-lg font-bold ml-auto">
            {filteredPlans.length} / {plans.length} Styles
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm">
          <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
            <tr>
              <th className="p-4 border-r border-border bg-panel-2 sticky left-0 z-10 w-56">
                বায়ার ও স্টাইল
              </th>
              <th className="p-4 border-r border-border text-center text-yellow-400 bg-panel-2">
                মোট প্ল্যান ও দিন
              </th>
              {sortedMonths.map((m) => (
                <th key={m} className="p-4 text-center border-r border-border/60 bg-panel-2/90">
                  {m}
                </th>
              ))}
              {isAdmin && (
                <th className="p-4 border-l border-border text-center text-yellow-400 bg-panel-2 sticky right-0 z-10 w-24">
                  অ্যাকশন
                </th>
              )}
            </tr>
            <tr className="bg-panel-2/95 font-bold border-t border-border">
              <th className="p-3 border-r border-border bg-panel-2 sticky left-0 z-10 text-right uppercase text-[11px] text-muted-foreground">
                ফ্যাক্টরি মান্থলি টোটাল লোড ➔
              </th>
              <th className="p-3 border-r border-border text-center bg-panel-2">
                <span className="block text-yellow-400 font-bold text-sm">
                  {grandQty.toLocaleString()} Pcs
                </span>
                <span className="inline-block mt-1 px-2 py-0.5 bg-yellow-500/20 border border-yellow-500 rounded text-[11px] text-yellow-300 font-bold">
                  ⏱️ {grandDays} Days Total
                </span>
              </th>
              {sortedMonths.map((m) => (
                <th key={m} className="p-3 text-center border-r border-border/60 bg-emerald-950/60">
                  <span className="block font-bold text-sm text-emerald-400">
                    {monthTotals[m].qty.toLocaleString()} Pcs
                  </span>
                  <span className="inline-block mt-1 px-2 py-0.5 bg-emerald-900 border border-emerald-500 rounded text-[11px] text-yellow-300 font-bold">
                    ⏱️ {monthTotals[m].days} Days
                  </span>
                </th>
              ))}
              {isAdmin && (
                <th className="p-3 bg-panel-2 sticky right-0 z-10 border-l border-border" />
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {filteredPlans.map((plan) => {
              const totalPlanned = plan.calc_result?.totalPlannedQty ?? 0;
              const totalDays = plan.calc_result?.totalLineDaysSum ?? 0;
              return (
                <tr key={plan.id} className="hover:bg-panel-2/40 transition">
                  <td className="p-4 border-r border-border bg-panel font-bold sticky left-0 z-10">
                    <div className="flex items-start gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="text-foreground">{plan.buyer}</div>
                        <div className="text-xs text-blue-400 font-normal">
                          {plan.style}
                          {plan.calc_result?.lines?.length > 0 && (
                            <span className="ml-2 text-emerald-500 font-bold">
                              [Line:{" "}
                              {plan.calc_result.lines
                                .map((l) =>
                                  l.name.startsWith("Line - ")
                                    ? l.name.replace("Line - ", "")
                                    : l.name,
                                )
                                .join(", ")}
                              ]
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          try {
                            exportMicroPlan(plan.buyer, plan.style, plan.calc_result);
                            toast.success("মাইক্রো প্ল্যান এক্সপোর্ট হয়েছে।");
                          } catch (e) {
                            toast.error((e as Error).message);
                          }
                        }}
                        className="shrink-0 p-1.5 rounded bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-600 hover:text-white transition"
                        title="Micro Plan — Excel এক্সপোর্ট (per-day, learning curve সহ)"
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                  <td className="p-3 border-r border-border text-center bg-panel/60">
                    <span className="block font-bold text-emerald-400">
                      {totalPlanned.toLocaleString()} Pcs
                    </span>
                    <span className="inline-block mt-1 px-2 py-0.5 bg-yellow-950/60 border border-yellow-700/60 rounded text-[11px] text-yellow-300 font-bold">
                      ⏱️ {totalDays} Days (Sum)
                    </span>
                  </td>
                  {sortedMonths.map((m) => {
                    const d = plan.calc_result?.monthlyBreakdown?.[m];
                    if (!d)
                      return (
                        <td
                          key={m}
                          className="p-4 text-center border-r border-border/60 text-muted-foreground"
                        >
                          -
                        </td>
                      );
                    return (
                      <td
                        key={m}
                        className="p-3 text-center border-r border-border/60 bg-panel-2/30"
                      >
                        <span className="block text-sm font-bold text-teal-300">
                          {d.qty.toLocaleString()}{" "}
                          <small className="text-[10px] font-normal text-muted-foreground">
                            Pcs
                          </small>
                        </span>
                        <span className="inline-block mt-1 px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 rounded text-[11px] text-yellow-300 font-semibold">
                          ⏱️ {d.days} Days
                        </span>
                      </td>
                    );
                  })}
                  {isAdmin && (
                    <td className="p-3 text-center border-l border-border bg-panel sticky right-0 z-10">
                      <div className="flex justify-center gap-1.5">
                        <button
                          onClick={() => {
                            window.dispatchEvent(
                              new CustomEvent("cg:edit-plan", { detail: plan.id }),
                            );
                          }}
                          className="p-2 rounded bg-yellow-600/20 border border-yellow-500/30 text-yellow-400 hover:bg-yellow-600 hover:text-white transition"
                          title="এডিট"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (
                              confirm(
                                `Order Complete করবেন?\n${plan.buyer} — ${plan.style}\n\nComplete করার পর এই style অন্য কোনো ট্যাবে দেখাবে না, কিন্তু "Complete Order" ট্যাব থেকে Restore করা যাবে।`,
                              )
                            )
                              complete.mutate(plan.id);
                          }}
                          className="p-2 rounded bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-600 hover:text-white transition"
                          title="Complete (Ship & archive)"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm("ক্লাউড থেকে প্ল্যানটি স্থায়ীভাবে ডিলিট করবেন?"))
                              del.mutate(plan.id);
                          }}
                          className="p-2 rounded bg-red-600/20 border border-red-500/30 text-red-400 hover:bg-red-600 hover:text-white transition"
                          title="ডিলিট"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
