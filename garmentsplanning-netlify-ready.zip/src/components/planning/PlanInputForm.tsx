import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  calculatePlan,
  deriveLineAllocations,
  formatDate,
  nextWorkingDay,
  type LineInput,
  type PlanResult,
  type TargetAdjustment,
} from "@/lib/plan-calc";
import {
  Loader2,
  Plus,
  X,
  Save,
  Pencil,
  Trash2,
  Calendar as CalIcon,
  CalendarDays,
  Link2,
  Link2Off,
  StickyNote,
  AlertTriangle,
  CheckCircle2,
  Package,
  PackageMinus,
  PackagePlus,
  Zap,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { HolidayCalendarDialog, useGlobalHolidays } from "./HolidayCalendar";
import { PlanNotesDialog } from "./PlanNotesDialog";
import {
  findOverlappingLineBlocks,
  pickAvailableLineName,
  buildLineOptions,
} from "./lineValidation";
import { buildLineLastOutput, lookupLastOutput, normLine } from "./lineLookup";
import { AutocompleteInput } from "./AutocompleteInput";
import { FilterSelect } from "./LineSummaryView";
import { useLinePresets, DEFAULT_LINE_PRESETS } from "@/hooks/use-line-presets";
import { buildPlanSnapshot } from "@/lib/plan-snapshot";
import { logActivity } from "@/lib/audit-logger";

type SavedPlan = {
  id: string;
  buyer: string;
  style: string;
  season?: string | null;
  order_qty: number;
  excess_pct: number;
  daily_target: number;
  num_lines: number;
  shipment_date: string;
  config: {
    lines: LineInput[];
    customHolidays: string[];
    targetAdjustments: TargetAdjustment[];
    targetAdjustmentsEnabled: boolean;
    lineEfficiency?: Record<
      string,
      { smv: number; manpower: number; hours: number; efficiency: number }
    >;
    learningCurve?: number[];
    learningCurveEnabled?: boolean;
    smv?: number | null;
    fabricEta?: string | null;
    cm?: number | null;
  };
  calc_result: PlanResult;
  created_by: string;
};

export type PushbackWarning = {
  lineName: string;
  nextBuyer: string;
  nextStyle: string;
  delayDays: number;
  oldStart: string;
  newStart: string;
};

// Line presets now live in `public.line_presets` (per factory). See useLinePresets.

function makeDefaultLines(
  n: number,
  existing: LineInput[] = [],
  presets: string[] = [],
): LineInput[] {
  const out: LineInput[] = [];
  const used: string[] = [];

  // Ensure we only use lines >= 15 or lettered lines
  const filteredPresets = presets.filter((name) => {
    const normalized = normLine(name);
    const num = parseInt(normalized);
    return isNaN(num) || num >= 15;
  });

  for (let i = 1; i <= n; i++) {
    if (existing[i - 1]) {
      out.push(existing[i - 1]);
      used.push(existing[i - 1].name);
      continue;
    }
    const name = pickAvailableLineName(used, filteredPresets, i);
    used.push(name);
    out.push({
      id: i,
      name,
      startDateStr: new Date().toISOString().slice(0, 10),
      allocatedOrderQty: 0,
      applyLC: true,
    });
  }
  return out;
}

export function PlanInputForm({
  pendingEditId,
  onConsumePendingEdit,
}: {
  pendingEditId?: string | null;
  onConsumePendingEdit?: () => void;
} = {}) {
  const { data: user } = useCurrentUser();
  const qc = useQueryClient();

  // Basic fields
  const [buyer, setBuyer] = useState("");
  const [style, setStyle] = useState("");
  const [season, setSeason] = useState("");
  const [orderQty, setOrderQty] = useState<number | "">("");
  const [excessPct, setExcessPct] = useState<number>(3);
  const [dailyTarget, setDailyTarget] = useState<number | "">("");
  const [numLines, setNumLines] = useState<number>(1);
  const [shipmentDate, setShipmentDate] = useState("");
  const [fabricEta, setFabricEta] = useState("");
  const [cm, setCm] = useState<number | "">("");

  // Line rows
  const [lines, setLines] = useState<LineInput[]>(() => makeDefaultLines(1));

  // Holidays
  const [customHolidays, setCustomHolidays] = useState<string[]>([]);
  const [holidayInput, setHolidayInput] = useState("");

  // Target adjustments
  const [adjEnabled, setAdjEnabled] = useState(false);
  const [adjustments, setAdjustments] = useState<TargetAdjustment[]>([]);
  const [adjLine, setAdjLine] = useState<string>("Line - 15");
  const [adjFrom, setAdjFrom] = useState("");
  const [adjTo, setAdjTo] = useState("");
  const [adjTarget, setAdjTarget] = useState<number | "">("");

  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [savedStyleFilter, setSavedStyleFilter] = useState<string[]>([]);
  const [savedBuyerFilter, setSavedBuyerFilter] = useState<string[]>([]);
  const [customLCEnabled, setCustomLCEnabled] = useState(false);
  const [learningCurveStr, setLearningCurveStr] = useState("20, 40, 60");
  const [saving, setSaving] = useState(false);
  const [pushbackWarnings, setPushbackWarnings] = useState<PushbackWarning[] | null>(null);
  const [planStatusTab, setPlanStatusTab] = useState<"all" | "planned" | "unplanned">("all");
  const [holidayCalOpen, setHolidayCalOpen] = useState(false);
  const [notesPlan, setNotesPlan] = useState<{ id: string; label: string } | null>(null);
  const { data: globalHolidays = [] } = useGlobalHolidays();

  // SMV-based target calculator (per-line supported, multi-select)
  const [calcOpen, setCalcOpen] = useState(false);
  const [calcLinesSel, setCalcLinesSel] = useState<string[]>([]); // empty = all lines
  const [calcPickerOpen, setCalcPickerOpen] = useState(false);
  const [calcSearch, setCalcSearch] = useState("");
  const [smv, setSmv] = useState<number | "">("");
  const [manpower, setManpower] = useState<number | "">("");
  const [workHours, setWorkHours] = useState<number | "">(10);
  const [efficiency, setEfficiency] = useState<number | "">(50);
  // Per-line SMV/manpower/hours/efficiency settings, key = line name (or "__default__")
  const [lineEfficiency, setLineEfficiency] = useState<
    Record<string, { smv: number; manpower: number; hours: number; efficiency: number }>
  >({});
  const computedTarget = useMemo(() => {
    const s = Number(smv),
      m = Number(manpower),
      h = Number(workHours),
      e = Number(efficiency);
    if (!s || !m || !h || !e) return 0;
    return Math.round((m * h * 60 * (e / 100)) / s);
  }, [smv, manpower, workHours, efficiency]);

  // Shared, factory-scoped line presets (synced across users via public.line_presets)
  const { presets: rawPresets, setPresets: setLinePresets } = useLinePresets();
  const linePresets = useMemo(() => {
    return (rawPresets || []).filter((name) => {
      const normalized = normLine(name);
      const num = parseInt(normalized);
      return isNaN(num) || num >= 15;
    });
  }, [rawPresets]);

  const [presetsOpen, setPresetsOpen] = useState(false);
  const [newPresetName, setNewPresetName] = useState("");
  const isLoadingPlanRef = useRef(false);
  const skipNumLinesEffectRef = useRef(false);

  // Adjust lines array to match numLines (ignored when loading an existing plan or manually modifying lines)
  useEffect(() => {
    if (isLoadingPlanRef.current) {
      isLoadingPlanRef.current = false;
      return;
    }
    if (skipNumLinesEffectRef.current) {
      skipNumLinesEffectRef.current = false;
      return;
    }
    setLines((prev) => makeDefaultLines(numLines, prev, linePresets));
  }, [numLines, linePresets]);

  // Load saved plans
  const { data: plans = [], isLoading: plansLoading } = useQuery({
    queryKey: ["plans", "full"],
    queryFn: async (): Promise<SavedPlan[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("*")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as SavedPlan[];
    },
  });

  // Realtime plans
  useEffect(() => {
    const ch = supabase
      .channel("plans-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  function resetForm() {
    setEditingPlanId(null);
    setBuyer("");
    setStyle("");
    setSeason("");
    setOrderQty("");
    setExcessPct(3);
    setDailyTarget("");
    setNumLines(1);
    setShipmentDate("");
    setFabricEta("");
    setCm("");
    setSmv("");
    setLines(makeDefaultLines(1, [], linePresets));
    setCustomHolidays([]);
    setAdjustments([]);
    setAdjEnabled(false);
    setLineEfficiency({});
    setCustomLCEnabled(false);
    setLearningCurveStr("20, 40, 60");
  }

  const loadPlanForEdit = useCallback((p: SavedPlan) => {
    isLoadingPlanRef.current = true;
    setEditingPlanId(p.id);
    setBuyer(p.buyer);
    setStyle(p.style);
    setSeason(p.season ?? "");
    setOrderQty(p.order_qty);
    setExcessPct(Number(p.excess_pct));
    setDailyTarget(p.daily_target);
    const isUnplanned = (p.config as any)?.status === "unplanned";
    const prevLines = (p.config as any)?.previous_lines;
    const initialLines = p.config?.lines?.length
      ? p.config.lines
      : prevLines?.length
        ? prevLines
        : makeDefaultLines(p.num_lines || 1);
    setNumLines(p.num_lines || initialLines.length || 1);
    setShipmentDate(p.shipment_date);
    setFabricEta(
      p.config?.fabricEta ??
        (p.config as any)?.fabric_eta ??
        (p as any)?.fabric_eta ??
        (p as any)?.fabricEta ??
        "",
    );
    setCm(p.config?.cm !== undefined && p.config?.cm !== null ? p.config.cm : "");
    setSmv(
      p.config?.smv !== undefined && p.config?.smv !== null
        ? p.config.smv
        : (p.config?.lineEfficiency?.__default__?.smv ?? ""),
    );
    setLines(initialLines);
    setCustomHolidays(p.config?.customHolidays ?? []);
    setAdjustments(p.config?.targetAdjustments ?? []);
    setAdjEnabled(!!p.config?.targetAdjustmentsEnabled);
    setLineEfficiency(p.config?.lineEfficiency ?? {});
    setCustomLCEnabled(!!p.config?.learningCurveEnabled);
    if (p.config?.learningCurve && p.config.learningCurve.length > 0) {
      setLearningCurveStr(p.config.learningCurve.join(", "));
    } else {
      setLearningCurveStr("20, 40, 60");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (isUnplanned) {
      toast.info(
        `আনপ্ল্যান্ড অর্ডার লোড হয়েছে: ${p.buyer} (${p.style}) — লাইন নির্বাচন করে প্ল্যান সেভ করুন।`,
      );
    } else {
      toast.info(`এডিট করা হচ্ছে: ${p.buyer} (${p.style})`);
    }
  }, []);

  const loadPlanById = useCallback(
    async (id: string) => {
      if (!id) return;
      try {
        // 1. Check in loaded plans / react-query cache first for instant feedback
        const cachedPlans = qc.getQueryData<SavedPlan[]>(["plans", "full"]) ?? plans;
        const existing = cachedPlans.find((p) => p.id === id);
        if (existing) {
          loadPlanForEdit(existing);
          return;
        }

        // 2. Fetch directly from Supabase
        const { data, error } = await supabase.from("plans").select("*").eq("id", id).maybeSingle();
        if (error || !data) {
          toast.error("প্ল্যান লোড করা যায়নি।");
        } else {
          loadPlanForEdit(data as unknown as SavedPlan);
        }
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "প্ল্যান লোড করা যায়নি।");
      }
    },
    [qc, plans, loadPlanForEdit],
  );

  // Load a plan for editing when parent passes a pendingEditId (from PlanBoardView, MatrixView, etc.)
  useEffect(() => {
    if (!pendingEditId) return;
    loadPlanById(pendingEditId).finally(() => {
      onConsumePendingEdit?.();
    });
  }, [pendingEditId, loadPlanById, onConsumePendingEdit]);

  // Also listen directly to the cg:edit-plan custom event for seamless cross-component communication
  useEffect(() => {
    const handleEditEvent = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      const id = typeof detail === "string" ? detail : detail?.id;
      if (!id) return;
      loadPlanById(id);
    };
    window.addEventListener("cg:edit-plan", handleEditEvent as EventListener);
    return () => {
      window.removeEventListener("cg:edit-plan", handleEditEvent as EventListener);
    };
  }, [loadPlanById]);

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const p = plans.find((x) => x.id === id);
      const { error } = await supabase.from("plans").delete().eq("id", id);
      if (error) throw error;
      logActivity({
        action: "PLAN_DELETE",
        details: `প্ল্যান ডিলিট করা হয়েছে: স্টাইল "${p?.style ?? id}" (বায়ার: ${p?.buyer ?? "N/A"})`,
        targetId: id,
        targetName: p?.style,
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("প্ল্যান ডিলিট হয়েছে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function cascadeReflow(mergedGlobalHolidays: string[]): Promise<number> {
    const { data, error } = await supabase.from("plans").select("*").is("completed_at", null);
    if (error || !data) return 0;
    const allPlans = JSON.parse(JSON.stringify(data)) as SavedPlan[];

    const lineNames = new Set<string>();
    for (const p of allPlans)
      for (const l of p.config?.lines ?? []) lineNames.add(normLine(l.name));

    const dirty: Record<string, SavedPlan> = {};
    const prevSnaps: Record<string, ReturnType<typeof buildPlanSnapshot>> = {};
    const byId: Record<string, SavedPlan> = Object.fromEntries(allPlans.map((p) => [p.id, p]));

    for (const lineName of lineNames) {
      // A single style can use the same physical line more than once with a
      // gap. Build the chain from individual blocks, not one row per plan.
      const chain = allPlans
        .flatMap((p) =>
          (p.config?.lines ?? []).flatMap((l, lineIndex) =>
            normLine(l.name) === lineName ? [{ plan: byId[p.id], lineIndex }] : [],
          ),
        )
        .sort((a, b) =>
          a.plan.config.lines[a.lineIndex].startDateStr.localeCompare(
            b.plan.config.lines[b.lineIndex].startDateStr,
          ),
        );
      if (chain.length < 2) continue;

      for (let i = 1; i < chain.length; i++) {
        const prevBlock = chain[i - 1];
        const curBlock = chain[i];
        const prev = prevBlock.plan;
        const cur = curBlock.plan;
        const prevLine = prev.calc_result?.lines?.[prevBlock.lineIndex];
        if (!prevLine?.finishDateStr) continue;
        // A line with no quantity produces nothing — it must never push the
        // next style forward.
        if ((prevLine.plannedQty ?? 0) <= 0 && (prevLine.dailyProduction?.length ?? 0) === 0)
          continue;
        const idx = curBlock.lineIndex;
        const curLine = cur.config.lines[idx];
        if (!curLine) continue;
        if (curLine.chainAuto === false) continue;

        const merged = Array.from(
          new Set([...(mergedGlobalHolidays ?? []), ...(cur.config.customHolidays ?? [])]),
        );
        const desired = nextWorkingDay(prevLine.finishDateStr, merged);
        // Only shift FORWARD — never pull a user-chosen later start date back.
        if (desired <= curLine.startDateStr) continue;

        // Snapshot BEFORE mutating (only once per plan — first shift wins).
        if (!prevSnaps[cur.id]) prevSnaps[cur.id] = buildPlanSnapshot(cur.calc_result);

        cur.config.lines[idx] = { ...curLine, startDateStr: desired };
        const recomputed = calculatePlan({
          buyer: cur.buyer,
          style: cur.style,
          orderQty: cur.order_qty,
          excessPct: Number(cur.excess_pct),
          dailyTargetPerLine: cur.daily_target,
          shipmentDate: cur.shipment_date,
          lines: cur.config.lines,
          customHolidays: merged,
          targetAdjustments: cur.config.targetAdjustments ?? [],
          targetAdjustmentsEnabled: !!cur.config.targetAdjustmentsEnabled,
          learningCurve: cur.config.learningCurveEnabled ? cur.config.learningCurve : undefined,
        });
        cur.calc_result = recomputed;
        dirty[cur.id] = cur;
      }
    }

    const ids = Object.keys(dirty);
    for (const id of ids) {
      const p = dirty[id];
      // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
      await supabase
        .from("plans")
        .update({
          config: p.config,
          calc_result: p.calc_result as any,
          previous_snapshot: prevSnaps[id] as any,
        } as any)
        .eq("id", id);
    }
    return ids.length;
  }

  async function handleSave(forceWithPushback = false) {
    if (!user) return;
    if (!buyer.trim() || !style.trim() || !orderQty || !dailyTarget || !shipmentDate) {
      toast.error("সবগুলো ঘর পূরণ করুন!");
      return;
    }
    const linesForCalc = lines.filter((l) => l.startDateStr);
    if (linesForCalc.length === 0) {
      toast.error("অন্তত একটি লাইন সেট করুন।");
      return;
    }
    // Same line can appear more than once (split blocks with a gap); only
    // overlapping blocks on the same line are rejected — checked after calc.

    setSaving(true);
    try {
      const parsedCurve = learningCurveStr
        .split(/[,\s]+/)
        .map((s) => Number(s.trim()))
        .filter((n) => isFinite(n) && n > 0);
      const activeCurve = customLCEnabled && parsedCurve.length > 0 ? parsedCurve : undefined;
      const mergedHolidays = Array.from(new Set([...(globalHolidays ?? []), ...customHolidays]));
      const result = calculatePlan({
        buyer: buyer.trim(),
        style: style.trim(),
        orderQty: Number(orderQty),
        excessPct: Number(excessPct),
        dailyTargetPerLine: Number(dailyTarget),
        shipmentDate,
        lines: linesForCalc,
        customHolidays: mergedHolidays,
        targetAdjustments: adjustments,
        targetAdjustmentsEnabled: adjEnabled,
        learningCurve: activeCurve,
      });

      // Same line twice is allowed (gap plan), overlap is not.
      const overlap = findOverlappingLineBlocks(
        result.lines
          .filter((l) => (l.plannedQty ?? 0) > 0 && l.finishDateStr)
          .map((l) => ({ name: l.name, start: l.startDateStr, finish: l.finishDateStr })),
      );
      if (overlap) {
        setSaving(false);
        toast.error(
          `"${overlap.name}" লাইনে দুটি ব্লক ওভারল্যাপ করছে (${overlap.a.start}–${overlap.a.finish} ও ${overlap.b.start}–${overlap.b.finish})। দ্বিতীয় ব্লকের স্টার্ট ডেট পরে দিন।`,
        );
        return;
      }

      // Check if this plan will push back downstream styles on any shared line.
      const warnings: PushbackWarning[] = [];
      for (const newLine of result.lines) {
        if (!newLine.finishDateStr) continue;
        if ((newLine.plannedQty ?? 0) <= 0 && (newLine.dailyProduction?.length ?? 0) === 0)
          continue;
        let nextPlan: SavedPlan | null = null;
        let nextStart = "";
        for (const p of plans) {
          if (editingPlanId && p.id === editingPlanId) continue;
          const cl = p.config?.lines?.find((l) => normLine(l.name) === normLine(newLine.name));
          if (!cl) continue;
          if (cl.chainAuto === false) continue;
          if (cl.startDateStr <= newLine.startDateStr) continue;
          if (!nextStart || cl.startDateStr < nextStart) {
            nextPlan = p;
            nextStart = cl.startDateStr;
          }
        }
        if (!nextPlan || !nextStart) continue;
        const desired = nextWorkingDay(newLine.finishDateStr, mergedHolidays);
        if (desired > nextStart) {
          const delay = Math.round(
            (new Date(desired).getTime() - new Date(nextStart).getTime()) / 86400000,
          );
          warnings.push({
            lineName: newLine.name,
            nextBuyer: nextPlan.buyer,
            nextStyle: nextPlan.style,
            delayDays: delay,
            oldStart: nextStart,
            newStart: desired,
          });
        }
      }

      // If warnings exist and user has not confirmed pushback yet, show the warning modal
      if (warnings.length > 0 && !forceWithPushback) {
        setSaving(false);
        setPushbackWarnings(warnings);
        return;
      }

      // User confirmed or no warnings; close dialog and proceed
      setPushbackWarnings(null);

      const payload = {
        buyer: buyer.trim(),
        style: style.trim(),
        season: season.trim() || null,
        order_qty: result.orderQty,
        excess_pct: Number(excessPct),
        daily_target: Number(dailyTarget),
        num_lines: linesForCalc.length,
        shipment_date: shipmentDate,
        config: {
          status: "planned",
          lines: linesForCalc,
          customHolidays,
          targetAdjustments: adjustments,
          targetAdjustmentsEnabled: adjEnabled,
          lineEfficiency,
          learningCurve: activeCurve,
          learningCurveEnabled: !!activeCurve,
          smv: smv !== "" ? Number(smv) : null,
          fabricEta: fabricEta.trim() || null,
          fabric_eta: fabricEta.trim() || null,
          cm: cm !== "" ? Number(cm) : null,
        },
        calc_result: result as unknown as Record<string, unknown>,
        created_by: user.id,
      };

      let savedPlanId: string | null = null;
      if (editingPlanId) {
        const existing = plans.find((p) => p.id === editingPlanId);
        const snap = existing ? buildPlanSnapshot(existing.calc_result) : null;
        const updatePayload = {
          ...payload,
          previous_snapshot: snap as unknown as Record<string, unknown> | null,
        };
        const { error } = await supabase
          .from("plans")
          // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
          .update(updatePayload as any)
          .eq("id", editingPlanId);
        if (error) throw error;
        savedPlanId = editingPlanId;
        logActivity({
          action: "PLAN_EDIT",
          details: `প্ল্যান আপডেট: স্টাইল "${form.style}" (বায়ার: ${form.buyer}, অর্ডার: ${form.orderQty.toLocaleString()})`,
          targetId: editingPlanId,
          targetName: form.style,
        });
        toast.success("প্ল্যান আপডেট হয়েছে।");
      } else {
        // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
        const { data: inserted, error } = await supabase
          .from("plans")
          .insert(payload as any)
          .select("id")
          .single();
        if (error) throw error;
        savedPlanId = (inserted as { id: string } | null)?.id ?? null;
        logActivity({
          action: "PLAN_CREATE",
          details: `নতুন প্ল্যান তৈরি: স্টাইল "${form.style}" (বায়ার: ${form.buyer}, অর্ডার: ${form.orderQty.toLocaleString()}, লাইন: ${result.lines.length}টি)`,
          targetId: savedPlanId ?? undefined,
          targetName: form.style,
        });
        toast.success("প্ল্যান সেভ হয়েছে।");
      }

      if (savedPlanId) {
        try {
          const revSnap = buildPlanSnapshot(result);
          const { data: last } = await supabase
            .from("plan_revisions" as never)
            .select("revision_no")
            .eq("plan_id", savedPlanId)
            .order("revision_no", { ascending: false })
            .limit(1)
            .maybeSingle();
          const nextNo = ((last as { revision_no?: number } | null)?.revision_no ?? 0) + 1;
          await supabase.from("plan_revisions" as never).insert({
            plan_id: savedPlanId,
            revision_no: nextNo,
            buyer: payload.buyer,
            style: payload.style,
            finish_date: revSnap?.finishDate ?? null,
            lines: (revSnap?.lines ?? []) as unknown as Record<string, unknown>,
            created_by: user.id,
            // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
          } as any);
          qc.invalidateQueries({ queryKey: ["plan_revisions"] });
        } catch (e) {
          console.error("revision record failed", e);
        }
      }

      // Cascade: auto-shift downstream styles on same lines
      try {
        const shifted = await cascadeReflow(globalHolidays ?? []);
        if (shifted > 0) {
          toast.success(`🔗 ${shifted} টি ডাউনস্ট্রিম স্টাইলের স্টার্ট ডেট অটো-অ্যাডজাস্ট হয়েছে।`);
        }
      } catch (e) {
        console.error("cascade failed", e);
      }

      qc.invalidateQueries({ queryKey: ["plans"] });
      resetForm();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "সেভ করা যায়নি।");
    } finally {
      setSaving(false);
    }
  }

  async function handleSaveAsUnplanned() {
    if (!user) return;
    if (!buyer.trim() || !style.trim() || !orderQty || !shipmentDate) {
      toast.error("বায়ার, স্টাইল, মোট কোয়ান্টিটি ও শিপমেন্ট তারিখ দিন!");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        buyer: buyer.trim(),
        style: style.trim(),
        season: season.trim() || null,
        order_qty: Number(orderQty),
        excess_pct: Number(excessPct) || 0,
        daily_target: Number(dailyTarget) || 0,
        num_lines: 0,
        shipment_date: shipmentDate,
        config: {
          status: "unplanned",
          lines: [],
          previous_lines: lines,
          customHolidays,
          targetAdjustments: adjustments,
          targetAdjustmentsEnabled: adjEnabled,
          lineEfficiency,
          smv: smv !== "" ? Number(smv) : null,
          fabricEta: fabricEta.trim() || null,
          fabric_eta: fabricEta.trim() || null,
          cm: cm !== "" ? Number(cm) : null,
        },
        calc_result: {
          buyer: buyer.trim(),
          style: style.trim(),
          orderQty: Number(orderQty),
          excessPct: Number(excessPct) || 0,
          totalPlannedQty: Math.round(Number(orderQty) * (1 + (Number(excessPct) || 0) / 100)),
          dailyTargetPerLine: Number(dailyTarget) || 0,
          hasLineAllocation: false,
          lines: [],
          totalLineDaysSum: 0,
          targetAdjustments: [],
          finishDate: "",
          shipmentDate,
          isDelayed: false,
          monthlyBreakdown: {},
          customHolidays: [],
        },
        created_by: user.id,
      };

      if (editingPlanId) {
        const { error } = await supabase
          .from("plans")
          // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
          .update(payload as any)
          .eq("id", editingPlanId);
        if (error) throw error;
        toast.success("অর্ডারটি আনপ্ল্যান্ড হিসেবে আপডেট করা হয়েছে।");
      } else {
        const { error } = await supabase
          .from("plans")
          // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
          .insert(payload as any);
        if (error) throw error;
        toast.success("অর্ডারটি আনপ্ল্যান্ড পুলে সেভ করা হয়েছে।");
      }

      // If an existing planned order was turned into unplanned, reflow other lines
      try {
        await cascadeReflow(globalHolidays ?? []);
      } catch {
        /* noop */
      }

      qc.invalidateQueries({ queryKey: ["plans"] });
      resetForm();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "সেভ করা যায়নি।");
    } finally {
      setSaving(false);
    }
  }

  async function handleUnplanFromTable(p: SavedPlan) {
    try {
      const { error } = await supabase
        .from("plans")
        // biome-ignore lint/suspicious/noExplicitAny: jsonb payload
        .update({
          config: {
            ...(p.config as any),
            status: "unplanned",
            previous_lines: (p.config as any)?.lines,
          },
          calc_result: {
            ...(p.calc_result as any),
            lines: [],
          },
          num_lines: 0,
        } as any)
        .eq("id", p.id);
      if (error) throw error;
      try {
        await cascadeReflow(globalHolidays ?? []);
      } catch {
        /* noop */
      }
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success(`"${p.style}" আনপ্ল্যান্ড পুলে সরানো হয়েছে।`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "আনপ্ল্যান্ড করা যায়নি।");
    }
  }

  function addHoliday() {
    if (!holidayInput) return;
    if (!customHolidays.includes(holidayInput))
      setCustomHolidays([...customHolidays, holidayInput]);
    setHolidayInput("");
  }

  function addAdjustment() {
    if (!adjLine || !adjFrom || !adjTo || !adjTarget) {
      toast.error("অ্যাডজাস্টমেন্টের সব ঘর পূরণ করুন।");
      return;
    }
    setAdjustments((prev) => [
      ...prev,
      {
        id: Date.now(),
        lineName: adjLine,
        fromDate: adjFrom,
        toDate: adjTo,
        newTarget: Number(adjTarget),
      },
    ]);
    setAdjFrom("");
    setAdjTo("");
    setAdjTarget("");
  }

  const usedLineNames = useMemo(() => lines.map((l) => l.name), [lines]);

  // Per-line: last output date across all saved plans (excluding the plan being edited)
  // Names are normalized (whitespace/case-insensitive) so "Line - R" and
  // "Line-R" resolve to the same booking. See lineLookup.ts + its tests.
  const lineLastOutput = useMemo(
    () => buildLineLastOutput(plans, editingPlanId),
    [plans, editingPlanId],
  );

  const mergedHolidaysForHint = useMemo(
    () => Array.from(new Set([...(globalHolidays ?? []), ...customHolidays])),
    [globalHolidays, customHolidays],
  );

  function addLaterBlock(lineName: string, fallbackStart: string) {
    if (numLines >= 20) {
      toast.error("সর্বোচ্চ ২০টি লাইন যোগ করা যাবে।");
      return;
    }
    const lastOut = lookupLastOutput(lineLastOutput, lineName);
    const startDateStr = lastOut ? nextWorkingDay(lastOut, mergedHolidaysForHint) : fallbackStart;
    skipNumLinesEffectRef.current = true;
    setLines((prev) => [
      ...prev,
      {
        id: (prev[prev.length - 1]?.id ?? 0) + 1,
        name: lineName,
        startDateStr,
        allocatedOrderQty: 0,
        applyLC: true,
        chainAuto: false,
      },
    ]);
    setNumLines((n) => Math.min(20, n + 1));
    toast.info(`${lineName} লাইনে ${formatDate(startDateStr)} থেকে নতুন ব্লক যোগ হয়েছে।`);
  }

  // Preview per-line pushback: for each line the user is editing, if the calc
  // would push a downstream (later) style back, show it inline on that card.
  type Pushback = {
    delay: number;
    buyer: string;
    style: string;
    oldStart: string;
    newStart: string;
  };
  const linePushbacks = useMemo<Record<string, Pushback>>(() => {
    const out: Record<string, Pushback> = {};
    if (!orderQty || !dailyTarget || Number(orderQty) <= 0 || Number(dailyTarget) <= 0) return out;
    const linesForCalc = lines.filter((l) => l.startDateStr);
    if (linesForCalc.length === 0) return out;
    try {
      const preview = calculatePlan({
        buyer: buyer || "-",
        style: style || "-",
        orderQty: Number(orderQty),
        excessPct: Number(excessPct),
        dailyTargetPerLine: Number(dailyTarget),
        shipmentDate: shipmentDate || linesForCalc[0].startDateStr,
        lines: linesForCalc,
        customHolidays: mergedHolidaysForHint,
        targetAdjustments: adjustments,
        targetAdjustmentsEnabled: adjEnabled,
        learningCurve: customLCEnabled
          ? learningCurveStr
              .split(/[,\s]+/)
              .map((s) => Number(s.trim()))
              .filter((n) => isFinite(n) && n > 0)
          : undefined,
      });
      for (const nl of preview.lines) {
        if (!nl.finishDateStr) continue;
        if ((nl.plannedQty ?? 0) <= 0 && (nl.dailyProduction?.length ?? 0) === 0) continue;
        let nextPlan: SavedPlan | null = null;
        let nextStart = "";
        for (const p of plans) {
          if (editingPlanId && p.id === editingPlanId) continue;
          const cl = p.config?.lines?.find((l) => normLine(l.name) === normLine(nl.name));
          if (!cl || cl.chainAuto === false) continue;
          if (cl.startDateStr <= nl.startDateStr) continue;
          if (!nextStart || cl.startDateStr < nextStart) {
            nextPlan = p;
            nextStart = cl.startDateStr;
          }
        }
        if (!nextPlan || !nextStart) continue;
        const desired = nextWorkingDay(nl.finishDateStr, mergedHolidaysForHint);
        if (desired > nextStart) {
          const delay = Math.round(
            (new Date(desired).getTime() - new Date(nextStart).getTime()) / 86400000,
          );
          out[nl.name] = {
            delay,
            buyer: nextPlan.buyer,
            style: nextPlan.style,
            oldStart: nextStart,
            newStart: desired,
          };
        }
      }
    } catch {
      /* ignore preview errors */
    }
    return out;
  }, [
    lines,
    orderQty,
    excessPct,
    dailyTarget,
    shipmentDate,
    adjustments,
    adjEnabled,
    mergedHolidaysForHint,
    plans,
    editingPlanId,
    buyer,
    style,
  ]);

  // Smart suggestions from previous entries
  const buyerSuggestions = useMemo(() => {
    const list = plans.map((p) => p.buyer).filter(Boolean);
    return Array.from(new Set(list));
  }, [plans]);

  const styleSuggestions = useMemo(() => {
    const normBuyer = buyer.trim().toLowerCase();
    const buyerStyles: string[] = [];
    const otherStyles: string[] = [];
    for (const p of plans) {
      if (!p.style) continue;
      if (normBuyer && p.buyer?.trim().toLowerCase() === normBuyer) {
        buyerStyles.push(p.style);
      } else {
        otherStyles.push(p.style);
      }
    }
    return Array.from(new Set([...buyerStyles, ...otherStyles]));
  }, [plans, buyer]);

  const seasonSuggestions = useMemo(() => {
    const list = plans.map((p) => p.season ?? "").filter(Boolean);
    return Array.from(new Set(list));
  }, [plans]);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-panel/70 p-5 md:p-6">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
          <div className="flex items-center gap-3 flex-wrap">
            <h2 className="text-base md:text-lg font-extrabold bn-gradient-text">
              {editingPlanId ? "✏️ প্ল্যান এডিট" : "⚙️ নতুন প্রোডাকশন শিডিউল ও লাইন এলোকেশন"}
            </h2>
            {plans.filter((p) => (p.config as any)?.status === "unplanned").length > 0 &&
              !editingPlanId && (
                <button
                  type="button"
                  onClick={() => {
                    setPlanStatusTab("unplanned");
                    const el = document.getElementById("saved-plans-section");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 hover:bg-amber-500/25 text-xs font-bold transition cursor-pointer"
                >
                  <Package className="w-3.5 h-3.5 text-amber-400" />
                  <span>
                    আনপ্ল্যান্ড পুলে{" "}
                    {plans.filter((p) => (p.config as any)?.status === "unplanned").length} টি
                    অর্ডার অপেক্ষমাণ
                  </span>
                  <span className="underline ml-0.5">দেখুন &rarr;</span>
                </button>
              )}
          </div>
          {editingPlanId && (
            <button
              onClick={resetForm}
              className="text-xs font-bold px-3 py-1.5 rounded-lg border border-border bg-panel-2 hover:bg-input"
            >
              ❌ এডিট বাতিল
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Field label="বায়ার">
            <AutocompleteInput
              value={buyer}
              onChange={setBuyer}
              suggestions={buyerSuggestions}
              placeholder="e.g. H&M"
              className={inputCls}
            />
          </Field>
          <Field label="স্টাইল নং">
            <AutocompleteInput
              value={style}
              onChange={setStyle}
              suggestions={styleSuggestions}
              placeholder="FW24-DENIM"
              className={inputCls}
            />
          </Field>
          <Field label="সিজন (Season)">
            <AutocompleteInput
              value={season}
              onChange={setSeason}
              suggestions={seasonSuggestions}
              placeholder="e.g. SS25 / FW25"
              className={inputCls}
            />
          </Field>
          <Field label="মোট অর্ডার কোয়ান্টিটি">
            <input
              type="number"
              value={orderQty}
              onChange={(e) => setOrderQty(e.target.value === "" ? "" : Number(e.target.value))}
              placeholder="100000"
              className={inputCls}
            />
          </Field>
          <Field label="অতিরিক্ত প্রোডাকশন (Excess %)" accent="teal">
            <input
              type="number"
              value={excessPct}
              onChange={(e) => setExcessPct(Number(e.target.value) || 0)}
              className={inputCls + " text-teal-400 font-bold border-teal-500/50"}
            />
          </Field>
          <Field label="বেসিক দৈনিক টার্গেট" accent="blue">
            <input
              type="number"
              value={dailyTarget}
              onChange={(e) => setDailyTarget(e.target.value === "" ? "" : Number(e.target.value))}
              placeholder="1000"
              className={inputCls}
            />
          </Field>
          <Field label="কয়টি লাইনে চলবে?" accent="yellow">
            <input
              type="number"
              min={1}
              max={20}
              value={numLines}
              onChange={(e) => setNumLines(Math.max(1, Math.min(20, Number(e.target.value) || 1)))}
              className={inputCls + " text-yellow-400 font-bold border-yellow-500/50"}
            />
          </Field>
          <Field label="শিপমেন্ট তারিখ" accent="red">
            <input
              type="date"
              value={shipmentDate}
              onChange={(e) => setShipmentDate(e.target.value)}
              className={inputCls}
            />
          </Field>
          <Field label="SMV (Standard Minute Value)" accent="purple">
            <input
              type="number"
              step="0.01"
              value={smv}
              onChange={(e) => setSmv(e.target.value === "" ? "" : Number(e.target.value))}
              placeholder="e.g. 15.5"
              className={inputCls + " text-purple-300 border-purple-500/40"}
            />
          </Field>
          <Field label="Fabric ETA (ফেব্ৰিক আসার তারিখ)" accent="teal">
            <input
              type="date"
              value={fabricEta}
              onChange={(e) => setFabricEta(e.target.value)}
              className={inputCls + " text-teal-300 border-teal-500/40"}
            />
          </Field>
          <Field label="CM (Cost of Making / Doz or Pc)" accent="emerald">
            <input
              type="number"
              step="0.01"
              value={cm}
              onChange={(e) => setCm(e.target.value === "" ? "" : Number(e.target.value))}
              placeholder="e.g. 4.50"
              className={inputCls + " text-emerald-300 border-emerald-500/40 font-mono"}
            />
          </Field>
        </div>

        {/* SMV-based target calculator */}
        <div className="mt-4 p-3 rounded-xl border border-purple-500/40 bg-purple-500/5">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => setCalcOpen((v) => !v)}
              className="text-xs font-bold text-purple-300 hover:text-purple-200"
            >
              🧮 SMV থেকে টার্গেট ক্যালকুলেটর {calcOpen ? "▲" : "▼"}
            </button>
            <span className="text-[10px] text-muted-foreground">
              Target = Manpower × Working Hours × 60 ÷ SMV × Efficiency%
            </span>
          </div>
          {calcOpen && (
            <div className="mt-3 grid grid-cols-2 md:grid-cols-6 gap-3 items-end">
              <Field label="Apply To (multi)">
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setCalcPickerOpen((v) => !v)}
                    className={`${inputCls} text-left flex items-center justify-between`}
                  >
                    <span className="truncate">
                      {calcLinesSel.length === 0 || calcLinesSel.length === lines.length
                        ? `All lines (${lines.length})`
                        : `${calcLinesSel.length} selected`}
                    </span>
                    <span className="text-purple-300 ml-1">{calcPickerOpen ? "▲" : "▼"}</span>
                  </button>
                  {calcPickerOpen && (
                    <div className="absolute z-40 mt-1 w-64 rounded-lg border border-purple-500/40 bg-panel-2 shadow-xl p-2">
                      <input
                        autoFocus
                        value={calcSearch}
                        onChange={(e) => setCalcSearch(e.target.value)}
                        placeholder="🔍 Search line..."
                        className="w-full px-2 py-1.5 mb-2 rounded border border-purple-500/30 bg-panel text-xs"
                      />
                      <div className="flex gap-2 mb-2 text-[10px]">
                        <button
                          type="button"
                          onClick={() => setCalcLinesSel(lines.map((l) => l.name))}
                          className="flex-1 px-2 py-1 rounded bg-purple-500/20 border border-purple-500/40 text-purple-200 font-bold hover:bg-purple-500/30"
                        >
                          Select All
                        </button>
                        <button
                          type="button"
                          onClick={() => setCalcLinesSel([])}
                          className="flex-1 px-2 py-1 rounded bg-white/5 border border-white/10 text-muted-foreground font-bold hover:bg-white/10"
                        >
                          Clear
                        </button>
                      </div>
                      <div className="max-h-56 overflow-auto space-y-0.5">
                        {lines
                          .filter((ln) => ln.name.toLowerCase().includes(calcSearch.toLowerCase()))
                          .map((ln) => {
                            const checked = calcLinesSel.includes(ln.name);
                            return (
                              <label
                                key={ln.id}
                                className={`flex items-center gap-2 px-2 py-1 rounded cursor-pointer text-xs ${
                                  checked ? "bg-purple-500/20 text-purple-100" : "hover:bg-white/5"
                                }`}
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={(e) =>
                                    setCalcLinesSel((prev) =>
                                      e.target.checked
                                        ? [...prev, ln.name]
                                        : prev.filter((n) => n !== ln.name),
                                    )
                                  }
                                />
                                <span>{ln.name}</span>
                              </label>
                            );
                          })}
                        {lines.filter((ln) =>
                          ln.name.toLowerCase().includes(calcSearch.toLowerCase()),
                        ).length === 0 && (
                          <div className="text-center text-[10px] text-muted-foreground py-2">
                            No match
                          </div>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => setCalcPickerOpen(false)}
                        className="w-full mt-2 px-2 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-bold"
                      >
                        Done
                      </button>
                    </div>
                  )}
                </div>
              </Field>
              <Field label="SMV">
                <input
                  type="number"
                  step="0.01"
                  value={smv}
                  onChange={(e) => setSmv(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder="e.g. 15"
                  className={inputCls}
                />
              </Field>
              <Field label="Total Manpower">
                <input
                  type="number"
                  value={manpower}
                  onChange={(e) => setManpower(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder="e.g. 40"
                  className={inputCls}
                />
              </Field>
              <Field label="Working Hours">
                <input
                  type="number"
                  step="0.5"
                  value={workHours}
                  onChange={(e) =>
                    setWorkHours(e.target.value === "" ? "" : Number(e.target.value))
                  }
                  className={inputCls}
                />
              </Field>
              <Field label="Efficiency %">
                <input
                  type="number"
                  value={efficiency}
                  onChange={(e) =>
                    setEfficiency(e.target.value === "" ? "" : Number(e.target.value))
                  }
                  className={inputCls}
                />
              </Field>
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-bold text-muted-foreground">
                  Calculated Target
                </span>
                <div className="flex gap-2">
                  <div className="flex-1 px-3 py-2 rounded-lg border border-purple-500/50 bg-purple-500/10 text-purple-200 font-extrabold text-lg text-center">
                    {computedTarget || "—"}
                  </div>
                  <button
                    type="button"
                    disabled={!computedTarget}
                    onClick={() => {
                      const s = Number(smv),
                        m = Number(manpower),
                        h = Number(workHours),
                        e = Number(efficiency);
                      if (!s || !m || !h || !e) {
                        toast.error("SMV, Manpower, Hours, Efficiency সব দিন।");
                        return;
                      }
                      const settings = { smv: s, manpower: m, hours: h, efficiency: e };
                      const applyAll =
                        calcLinesSel.length === 0 || calcLinesSel.length === lines.length;
                      if (applyAll) {
                        setDailyTarget(computedTarget);
                        setLineEfficiency((prev) => ({ ...prev, __default__: settings }));
                        toast.success(
                          `সব লাইনে দৈনিক টার্গেট ${computedTarget} সেট হয়েছে (Efficiency ${e}%).`,
                        );
                        return;
                      }
                      const targets = lines.filter((l) => calcLinesSel.includes(l.name));
                      if (targets.length === 0) {
                        toast.error("কোনো লাইন সিলেক্ট করা হয়নি।");
                        return;
                      }
                      const to = shipmentDate || "2099-12-31";
                      setAdjEnabled(true);
                      setAdjustments((prev) => {
                        let next = [...prev];
                        let nextId = (next.reduce((mx, a) => Math.max(mx, a.id), 0) || 0) + 1;
                        for (const ln of targets) {
                          const from = ln.startDateStr || new Date().toISOString().slice(0, 10);
                          next = next.filter(
                            (a) =>
                              !(a.lineName === ln.name && a.fromDate === from && a.toDate === to),
                          );
                          next.push({
                            id: nextId++,
                            lineName: ln.name,
                            fromDate: from,
                            toDate: to,
                            newTarget: computedTarget,
                          });
                        }
                        return next;
                      });
                      setLineEfficiency((prev) => {
                        const upd = { ...prev };
                        for (const ln of targets) upd[ln.name] = settings;
                        return upd;
                      });
                      toast.success(
                        `${targets.length} টি লাইনে টার্গেট ${computedTarget} প্রয়োগ হয়েছে (Efficiency ${e}%).`,
                      );
                    }}
                    className="px-3 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold disabled:opacity-40"
                    title="নির্বাচিত লাইনে টার্গেট প্রয়োগ করুন"
                  >
                    Apply
                  </button>
                </div>
              </div>
            </div>
          )}
          {Object.keys(lineEfficiency).length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {Object.entries(lineEfficiency).map(([name, s]) => (
                <span
                  key={name}
                  className="inline-flex items-center gap-1 text-[10px] px-2 py-1 rounded-md border border-purple-500/40 bg-purple-500/10 text-purple-200"
                >
                  <b>{name === "__default__" ? "All lines" : name}:</b>
                  SMV {s.smv} • MP {s.manpower} • {s.hours}h • Eff {s.efficiency}%
                  <button
                    type="button"
                    onClick={() =>
                      setLineEfficiency((prev) => {
                        const { [name]: _, ...rest } = prev;
                        return rest;
                      })
                    }
                    className="ml-1 text-purple-300 hover:text-red-400"
                    title="Remove"
                  >
                    ✕
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Line configuration */}

        <div className="mt-6 p-4 bg-panel-2/60 rounded-xl border border-yellow-500/30">
          <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
            <span className="text-xs font-bold text-yellow-400">🤖 লাইন-ভিত্তিক কনফিগারেশন:</span>
            <button
              type="button"
              onClick={() => setPresetsOpen((v) => !v)}
              className="text-[11px] font-bold px-2.5 py-1 rounded-md border border-yellow-500/40 bg-yellow-500/10 text-yellow-300 hover:bg-yellow-500/20"
            >
              ⚙️ লাইন প্রিসেট ম্যানেজ ({linePresets.length})
            </button>
          </div>

          {presetsOpen && (
            <div className="mb-3 p-3 rounded-lg border border-yellow-500/30 bg-yellow-500/5">
              <p className="text-[11px] text-muted-foreground mb-2">
                আপনার ফ্যাক্টরির লাইনগুলোর নাম এখানে সেভ করে রাখুন — নতুন প্ল্যানে অটো-লোড হবে।
              </p>
              <div className="flex flex-wrap gap-2 mb-2">
                {linePresets.map((name, i) => (
                  <span
                    key={`${name}-${i}`}
                    className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs px-2 py-1 rounded-lg flex items-center gap-1.5"
                  >
                    <input
                      value={name}
                      onChange={(e) =>
                        setLinePresets((prev) => {
                          const next = [...prev];
                          const rawIdx = prev.indexOf(name);
                          if (rawIdx !== -1) next[rawIdx] = e.target.value;
                          return next;
                        })
                      }
                      className="bg-transparent outline-none text-emerald-200 font-bold w-28"
                    />
                    <button
                      type="button"
                      onClick={() => setLinePresets((prev) => prev.filter((p) => p !== name))}
                      className="text-red-400 hover:text-red-300"
                      title="মুছুন"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  value={newPresetName}
                  onChange={(e) => setNewPresetName(e.target.value)}
                  placeholder="যেমন: Sewing Line A"
                  className={inputCls + " py-1.5 text-xs"}
                />
                <button
                  type="button"
                  onClick={() => {
                    const v = newPresetName.trim();
                    if (!v) return;
                    if (linePresets.includes(v)) {
                      toast.error("এই নামে ইতোমধ্যে প্রিসেট আছে।");
                      return;
                    }
                    setLinePresets((prev) => [...prev, v]);
                    setNewPresetName("");
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-1.5 px-3 rounded text-xs whitespace-nowrap"
                >
                  <Plus className="inline w-3 h-3 mr-1" />
                  প্রিসেট যোগ
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("ডিফল্ট Line - 15..35 ও A..S এ রিসেট করবেন?")) {
                      setLinePresets(DEFAULT_LINE_PRESETS);
                    }
                  }}
                  className="bg-panel-2 hover:bg-input border border-border py-1.5 px-3 rounded text-xs font-bold whitespace-nowrap"
                >
                  রিসেট
                </button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {lines.map((line, idx) => {
              const lastOut = lookupLastOutput(lineLastOutput, line.name);
              const nextOpen = lastOut ? nextWorkingDay(lastOut, mergedHolidaysForHint) : "";
              const lineAdjustments = adjustments.filter((a) => a.lineName === line.name);
              // Same line may be reused for a second block after a gap, so the
              // dropdown keeps every preset selectable.
              const pushback = linePushbacks[line.name];
              return (
                <LineCard
                  key={line.id ?? `line-${idx}-${line.name}`}
                  line={line}
                  presets={linePresets}
                  pushback={pushback}
                  lastOutput={lastOut}
                  nextOpen={nextOpen}
                  adjustments={lineAdjustments}
                  onAddAdjustment={(from, to, tgt) => {
                    if (!from || !to || !tgt) {
                      toast.error("তারিখ ও টার্গেট দিন।");
                      return;
                    }
                    if (from > to) {
                      toast.error("শুরু তারিখ শেষ তারিখের পরে হতে পারবে না।");
                      return;
                    }
                    setAdjustments((prev) => [
                      ...prev,
                      {
                        id: Date.now() + Math.floor(Math.random() * 1000),
                        lineName: line.name,
                        fromDate: from,
                        toDate: to,
                        newTarget: tgt,
                      },
                    ]);
                    if (!adjEnabled) setAdjEnabled(true);
                  }}
                  onRemoveAdjustment={(id) =>
                    setAdjustments((prev) => prev.filter((x) => x.id !== id))
                  }
                  onChange={(patch) => {
                    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
                    // If line name changed, cascade to its adjustments — but ONLY when
                    // no other row still holds the old name. Otherwise the earlier
                    // (first) duplicate row keeps ownership of those adjustments.
                    if (patch.name && patch.name !== line.name) {
                      const oldName = line.name;
                      const stillUsed = lines.some((l, i) => i !== idx && l.name === oldName);
                      if (!stillUsed) {
                        setAdjustments((prev) =>
                          prev.map((a) =>
                            a.lineName === oldName ? { ...a, lineName: patch.name! } : a,
                          ),
                        );
                      }
                    }
                  }}
                  canDelete={lines.length > 1}
                  onAddLaterBlock={() => addLaterBlock(line.name, line.startDateStr)}
                  onDelete={() => {
                    if (lines.length <= 1) {
                      toast.error("কমপক্ষে একটি লাইন থাকা আবশ্যক।");
                      return;
                    }
                    const removedName = line.name;
                    const stillUsed = lines.some((l, i) => i !== idx && l.name === removedName);
                    skipNumLinesEffectRef.current = true;
                    const nextLines = lines.filter((_, i) => i !== idx);
                    setLines(nextLines);
                    // Only drop adjustments when no other row keeps that line name —
                    // preserves the earlier duplicate row's data intact.
                    if (!stillUsed) {
                      setAdjustments((prev) => prev.filter((a) => a.lineName !== removedName));
                    }
                    setNumLines(nextLines.length);
                    toast.success(`"${removedName}" লাইনটি মুছে ফেলা হয়েছে।`);
                  }}
                />
              );
            })}
          </div>
          <div className="mt-3 flex justify-center">
            <button
              type="button"
              onClick={() => {
                if (numLines >= 20) {
                  toast.error("সর্বোচ্চ ২০টি লাইন যোগ করা যাবে।");
                  return;
                }
                // Same line can be planned again after a gap. Start after its
                // latest saved output so the new block does not overlap.
                const last = lines[lines.length - 1];
                const repeatedName =
                  last?.name ??
                  linePresets[0] ??
                  DEFAULT_LINE_PRESETS.find((n) => {
                    const normalized = normLine(n);
                    const num = parseInt(normalized);
                    return isNaN(num) || num >= 15;
                  });
                const savedLastOut = lookupLastOutput(lineLastOutput, repeatedName);
                skipNumLinesEffectRef.current = true;
                setLines((prev) => [
                  ...prev,
                  {
                    id: (prev[prev.length - 1]?.id ?? 0) + 1,
                    name: repeatedName,
                    startDateStr: savedLastOut
                      ? nextWorkingDay(savedLastOut, mergedHolidaysForHint)
                      : (last?.startDateStr ?? new Date().toISOString().slice(0, 10)),
                    allocatedOrderQty: 0,
                    applyLC: true,
                    chainAuto: false,
                  },
                ]);
                setNumLines((n) => Math.min(20, n + 1));
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/50 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 px-3 py-1.5 text-xs font-bold"
            >
              <Plus className="w-3.5 h-3.5" /> নতুন লাইন যোগ করুন
            </button>
          </div>

          <AllocationSummary
            lines={lines}
            orderQty={typeof orderQty === "number" ? orderQty : 0}
            excessPct={Number(excessPct) || 0}
            adjustments={adjustments}
            adjEnabled={adjEnabled}
            holidays={mergedHolidaysForHint}
            dailyTarget={Number(dailyTarget) || 0}
            learningCurve={
              customLCEnabled
                ? learningCurveStr
                    .split(/[,\s]+/)
                    .map(Number)
                    .filter((n) => isFinite(n) && n > 0)
                : undefined
            }
          />
        </div>

        {/* Target adjustments (global toggle — per-line rows live inside each line card) */}
        <div className="mt-6 p-3 bg-panel-2/60 rounded-xl border border-blue-500/40 flex items-center justify-between gap-3 flex-wrap">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={adjEnabled}
              onChange={(e) => setAdjEnabled(e.target.checked)}
              className="w-4 h-4 accent-blue-500"
            />
            <span className="text-xs font-bold text-blue-400">
              ⏱️ ডেট-রেঞ্জ ভিত্তিক টার্গেট অ্যাডজাস্টমেন্ট চালু
            </span>
          </label>
          <span className="text-[10px] text-muted-foreground">
            প্রতিটি লাইন কার্ডের নিচে "টার্গেট রেঞ্জ" থেকে যোগ করুন — লাইন-ওয়াইজ, স্টাইল-ওয়াইজ।
            {adjustments.length > 0 && (
              <>
                {" "}
                মোট রেঞ্জ: <b className="text-blue-300">{adjustments.length}</b>
              </>
            )}
          </span>
        </div>

        {/* Holidays */}
        <div className="mt-6 p-4 bg-panel-2/40 rounded-xl border border-border grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <span className="block text-xs font-bold text-muted-foreground mb-2">
              💡 লার্নিং কার্ভ গাইডলাইন
            </span>
            <p className="text-xs text-muted-foreground">
              রিপিট অর্ডারে <b className="text-emerald-400">"প্রযোজ্য নয় (১০০%)"</b> দিন। নতুন
              স্টাইলে <b className="text-blue-400">"প্রযোজ্য (২০%-১০০%)"</b> রাখুন।
            </p>
            <p className="text-[11px] text-muted-foreground mt-2">
              ডিফল্ট কার্ভ:{" "}
              <b className="text-blue-300">Day 1 = 20%, Day 2 = 40%, Day 3 = 60%, Day 4+ = 100%</b>
            </p>
            <div className="mt-3 p-2 rounded-lg border border-purple-500/40 bg-purple-500/10">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={customLCEnabled}
                  onChange={(e) => setCustomLCEnabled(e.target.checked)}
                  className="w-4 h-4 accent-purple-500"
                />
                <span className="text-xs font-bold text-purple-300">
                  🎯 এই স্টাইলে কাস্টম লার্নিং কার্ভ (exception)
                </span>
              </label>
              {customLCEnabled && (
                <div className="mt-2">
                  <input
                    type="text"
                    value={learningCurveStr}
                    onChange={(e) => setLearningCurveStr(e.target.value)}
                    placeholder="e.g. 30, 50, 70, 85"
                    className="w-full bg-input border border-border rounded p-2 text-xs font-mono outline-none focus:border-purple-400"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    কমা দিয়ে দিন-ভিত্তিক % লিখুন (Day 1, Day 2, ...)। বাকি দিন 100%। যেসব লাইনে
                    "লার্নিং কার্ভ প্রযোজ্য নয়" সেগুলোতে প্রভাব পড়বে না।
                  </p>
                </div>
              )}
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2 gap-2 flex-wrap">
              <span className="block text-xs font-bold text-muted-foreground">
                🏖️ কাস্টম ছুটি (এই স্টাইলের জন্য)
              </span>
              <button
                type="button"
                onClick={() => setHolidayCalOpen(true)}
                className="text-[11px] font-bold px-2.5 py-1 rounded-md border border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20 inline-flex items-center gap-1"
                title="সব প্ল্যানের জন্য গ্লোবাল ছুটির ক্যালেন্ডার"
              >
                <CalendarDays className="w-3.5 h-3.5" />
                গ্লোবাল ছুটির ক্যালেন্ডার ({globalHolidays.length})
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="date"
                value={holidayInput}
                onChange={(e) => setHolidayInput(e.target.value)}
                className={inputCls + " py-1.5 text-xs"}
              />
              <button
                onClick={addHoliday}
                className="bg-panel-2 hover:bg-input px-3 py-1.5 rounded text-xs font-bold border border-border"
              >
                <Plus className="inline w-3 h-3 mr-1" />
                ছুটি
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 mt-2">
              {customHolidays.map((d) => (
                <span
                  key={d}
                  className="bg-red-500/20 border border-red-500/40 text-red-300 text-xs px-2 py-0.5 rounded flex items-center gap-1 font-mono"
                >
                  {d}
                  <button
                    onClick={() => setCustomHolidays(customHolidays.filter((x) => x !== d))}
                    className="hover:text-white font-bold"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>

        {Object.keys(linePushbacks).length > 0 && (
          <div className="mt-4 p-3 rounded-xl bg-amber-950/40 border border-amber-500/50 flex items-start gap-2.5 text-xs text-amber-200">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-amber-300">⚠️ পুশব্যাক সতর্কতা:</span> এলোকেশন
              কোয়ান্টিটি বেশি হওয়ার কারণে {Object.keys(linePushbacks).length}টি লাইনে পরবর্তী
              স্টাইল পিছিয়ে যাবে। সেভ করার সময় আপনাকে সতর্কবার্তা ও নিশ্চিতকরণ অপশন দেখানো হবে।
            </div>
          </div>
        )}

        <div className="mt-6 flex flex-wrap items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={handleSaveAsUnplanned}
            disabled={saving}
            title="লাইন শিডিউল না করে শুধুমাত্র অর্ডার তথ্য আনপ্ল্যান্ড পুলে সংরক্ষণ করুন"
            className="px-5 py-3 rounded-xl border border-amber-500/50 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-bold text-xs transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <PackagePlus className="w-4 h-4" />
            {editingPlanId
              ? "📦 আনপ্ল্যান্ড হিসেবে রূপান্তর করুন"
              : "📦 আনপ্ল্যান্ড হিসেবে সেভ করুন"}
          </button>
          <button
            onClick={() => handleSave(false)}
            disabled={saving}
            className={`text-white font-bold py-3 px-8 rounded-xl shadow-lg transition ${
              editingPlanId
                ? "bg-gradient-to-r from-yellow-600 via-amber-600 to-orange-600"
                : "bg-gradient-to-r from-blue-600 via-teal-600 to-emerald-600"
            } hover:opacity-90 disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer flex items-center gap-2`}
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin inline" />
            ) : editingPlanId ? (
              <>
                <Save className="w-4 h-4 inline mr-1.5" /> ক্লাউডে লাইন প্ল্যান সেভ করুন
              </>
            ) : (
              <>⚡ এখনই লাইন প্ল্যানসহ সেভ করুন</>
            )}
          </button>
        </div>
      </div>

      {/* Pushback Warning & Save Confirmation Dialog */}
      <Dialog
        open={!!pushbackWarnings && pushbackWarnings.length > 0}
        onOpenChange={(open) => {
          if (!open && !saving) setPushbackWarnings(null);
        }}
      >
        <DialogContent className="max-w-md bg-panel border-amber-500/60 text-foreground shadow-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-400 font-extrabold text-base">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
              ⚠️ শিডিউল পুশব্যাক সতর্কতা
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground text-left mt-1">
              এই প্ল্যানে এলোকেশন কোয়ান্টিটি বেশি হওয়ার কারণে নিচের লাইনে পরবর্তী স্টাইল(গুলো)
              পিছিয়ে যাবে:
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2.5 my-2 max-h-64 overflow-y-auto pr-1">
            {pushbackWarnings?.map((w, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg bg-amber-950/40 border border-amber-500/40 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="text-amber-300 font-mono text-xs">{w.lineName}</span>
                  <span className="bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded text-[11px] font-extrabold border border-amber-500/30">
                    +{w.delayDays} দিন পিছাবে
                  </span>
                </div>
                <div className="text-foreground/90 font-medium">
                  {w.nextBuyer} —{" "}
                  <span className="text-emerald-400 font-semibold">{w.nextStyle}</span>
                </div>
                <div className="text-[11px] text-muted-foreground">
                  স্টার্ট ডেট:{" "}
                  <span className="line-through text-red-400 font-mono">
                    {formatDate(w.oldStart)}
                  </span>
                  {" → "}
                  <span className="text-emerald-300 font-bold font-mono">
                    {formatDate(w.newStart)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="p-2.5 rounded bg-panel-2 border border-border text-[11px] text-muted-foreground">
            💡 আপনি সেভ নিশ্চিত করলে এই প্ল্যানটি সেভ হবে এবং একই সাথে সংশ্লিষ্ট ডাউনস্ট্রিম
            স্টাইলগুলোর স্টার্ট ডেট নতুন তারিখে অটো-অ্যাডজাস্ট (অটো-শিফট) হয়ে যাবে।
          </div>

          <DialogFooter className="flex flex-col sm:flex-row gap-2 mt-2">
            <button
              type="button"
              disabled={saving}
              onClick={() => setPushbackWarnings(null)}
              className="w-full sm:w-auto px-4 py-2 rounded-lg border border-border bg-panel-2 hover:bg-input text-foreground text-xs font-bold transition cursor-pointer"
            >
              বাতিল ও সংশোধন
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => handleSave(true)}
              className="w-full sm:w-auto px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs transition flex items-center justify-center gap-1.5 shadow-lg shadow-amber-900/40 cursor-pointer disabled:opacity-50"
            >
              {saving ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  সেভ হচ্ছে...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  হ্যাঁ, পুশব্যাক করে সেভ করুন
                </>
              )}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Saved plans list */}
      {(() => {
        const styleOptions = Array.from(new Set(plans.map((p) => p.style))).sort();
        const buyerOptions = Array.from(new Set(plans.map((p) => p.buyer))).sort();
        const unplannedCount = plans.filter(
          (p) => (p.config as any)?.status === "unplanned",
        ).length;
        const plannedCount = plans.length - unplannedCount;

        const statusFilteredPlans = plans.filter((p) => {
          const isUnplanned = (p.config as any)?.status === "unplanned";
          if (planStatusTab === "planned") return !isUnplanned;
          if (planStatusTab === "unplanned") return isUnplanned;
          return true;
        });

        const filteredPlans = statusFilteredPlans.filter(
          (p) =>
            (savedStyleFilter.length === 0 || savedStyleFilter.includes(p.style)) &&
            (savedBuyerFilter.length === 0 || savedBuyerFilter.includes(p.buyer)),
        );
        return (
          <div
            id="saved-plans-section"
            className="rounded-2xl border border-border bg-panel/70 overflow-hidden"
          >
            <div className="p-4 md:p-5 border-b border-border flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3 flex-wrap">
                <h3 className="text-sm md:text-base font-bold text-foreground">
                  📋 সেভ করা অর্ডার ও প্ল্যান
                </h3>
                {/* Status Segmented Control */}
                <div className="flex items-center gap-1 p-1 rounded-xl bg-panel-2 border border-border text-xs">
                  <button
                    type="button"
                    onClick={() => setPlanStatusTab("all")}
                    className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                      planStatusTab === "all"
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    সকল ({plans.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPlanStatusTab("planned")}
                    className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                      planStatusTab === "planned"
                        ? "bg-emerald-600 text-white shadow-sm"
                        : "text-emerald-400 hover:text-emerald-300"
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    শিডিউল্ড ({plannedCount})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPlanStatusTab("unplanned")}
                    className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                      planStatusTab === "unplanned"
                        ? "bg-amber-600 text-black shadow-sm"
                        : "text-amber-400 hover:text-amber-300"
                    }`}
                  >
                    <Package className="w-3.5 h-3.5" />
                    আনপ্ল্যান্ড পুল ({unplannedCount})
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <FilterSelect
                  label="Buyer"
                  value={savedBuyerFilter}
                  onChange={setSavedBuyerFilter}
                  options={buyerOptions}
                />
                <FilterSelect
                  label="Style"
                  value={savedStyleFilter}
                  onChange={setSavedStyleFilter}
                  options={styleOptions}
                />
                {savedStyleFilter.length || savedBuyerFilter.length ? (
                  <button
                    onClick={() => {
                      setSavedStyleFilter([]);
                      setSavedBuyerFilter([]);
                    }}
                    className="text-xs font-bold text-red-300 hover:text-red-200 underline"
                  >
                    Clear
                  </button>
                ) : null}
                <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-500/50 px-3 py-1 rounded-lg font-bold">
                  {filteredPlans.length} / {plans.length} Orders
                </span>
              </div>
            </div>
            {plansLoading ? (
              <div className="p-8 flex justify-center">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            ) : plans.length === 0 ? (
              <p className="p-8 text-center text-sm text-muted-foreground">
                এখনো কোনো প্ল্যান সেভ হয়নি।
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="text-xs uppercase text-muted-foreground bg-panel-2/60">
                    <tr>
                      <th className="p-3">বায়ার / স্টাইল</th>
                      <th className="p-3">কোয়ান্টিটি</th>
                      <th className="p-3">লাইন</th>
                      <th className="p-3">ফিনিশ</th>
                      <th className="p-3">শিপমেন্ট</th>
                      <th className="p-3 text-center">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredPlans.map((p) => {
                      const isUnplanned = (p.config as any)?.status === "unplanned";
                      const delayed = !isUnplanned && p.calc_result?.isDelayed;
                      return (
                        <tr key={p.id} className="hover:bg-panel-2/40">
                          <td className="p-3">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-foreground">{p.buyer}</span>
                              {isUnplanned ? (
                                <span className="text-[10px] font-extrabold text-amber-300 bg-amber-500/20 border border-amber-500/40 px-1.5 py-0.5 rounded flex items-center gap-1">
                                  <Package className="w-2.5 h-2.5" /> আনপ্ল্যান্ড
                                </span>
                              ) : (
                                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                                  ✓ শিডিউল্ড
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">{p.style}</div>
                            <div className="flex flex-wrap items-center gap-1.5 mt-1">
                              {p.season && (
                                <span className="text-[10px] font-semibold text-purple-400 bg-purple-500/10 border border-purple-500/20 px-1.5 py-0.5 rounded">
                                  🗓 {p.season}
                                </span>
                              )}
                              {(p.config?.smv ?? p.config?.lineEfficiency?.__default__?.smv) && (
                                <span className="text-[10px] font-semibold text-purple-300 bg-purple-500/10 border border-purple-500/20 px-1.5 py-0.5 rounded">
                                  ⚡ SMV:{" "}
                                  {p.config?.smv ?? p.config?.lineEfficiency?.__default__?.smv}
                                </span>
                              )}
                              {p.config?.fabricEta && (
                                <span className="text-[10px] font-semibold text-teal-300 bg-teal-500/10 border border-teal-500/20 px-1.5 py-0.5 rounded">
                                  🧵 ETA: {formatDate(p.config.fabricEta)}
                                </span>
                              )}
                              {p.config?.cm !== undefined && p.config?.cm !== null && (
                                <span className="text-[10px] font-semibold text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded font-mono">
                                  💲 CM: ${p.config.cm}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="font-mono text-emerald-400 font-bold">
                              {p.order_qty.toLocaleString()}
                            </div>
                            <div className="text-[10px] text-muted-foreground">
                              +{p.excess_pct}% ={" "}
                              {(p.calc_result?.totalPlannedQty ?? p.order_qty).toLocaleString()}
                            </div>
                          </td>
                          <td className="p-3">
                            {isUnplanned ? (
                              <span className="text-xs text-muted-foreground italic">
                                লাইন বরাদ্দ নেই
                              </span>
                            ) : (
                              <>
                                <div className="text-xs text-muted-foreground">
                                  {p.num_lines} লাইন
                                </div>
                                <div className="text-[10px] font-mono text-yellow-400">
                                  {p.daily_target}/day
                                </div>
                              </>
                            )}
                          </td>
                          <td className="p-3">
                            {isUnplanned ? (
                              <span className="text-xs text-amber-400/80 font-mono">অপেক্ষমান</span>
                            ) : (
                              <>
                                <div
                                  className={`text-xs font-bold ${delayed ? "text-red-400" : "text-emerald-400"}`}
                                >
                                  <CalIcon className="w-3 h-3 inline mr-1" />
                                  {formatDate(p.calc_result?.finishDate ?? "")}
                                </div>
                                {delayed && (
                                  <div className="text-[10px] text-red-400 font-bold">
                                    ⚠ বিলম্বিত
                                  </div>
                                )}
                              </>
                            )}
                          </td>
                          <td className="p-3 text-xs font-mono text-muted-foreground">
                            {formatDate(p.shipment_date)}
                          </td>
                          <td className="p-3">
                            <div className="flex items-center justify-center gap-1.5">
                              {isUnplanned ? (
                                <button
                                  type="button"
                                  onClick={() => loadPlanForEdit(p)}
                                  className="px-2.5 py-1 rounded bg-emerald-600/20 border border-emerald-600/50 text-emerald-300 hover:bg-emerald-600/30 text-xs font-bold flex items-center gap-1 cursor-pointer"
                                  title="এই অর্ডারের জন্য লাইন শিডিউল নির্ধারণ করুন"
                                >
                                  <Zap className="w-3 h-3 text-emerald-400" />
                                  প্ল্যান করুন
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleUnplanFromTable(p)}
                                  className="p-1.5 rounded bg-amber-500/15 border border-amber-500/40 text-amber-300 hover:bg-amber-500/25 cursor-pointer"
                                  title="প্ল্যান মুছে আনপ্ল্যান্ড পুলে ফেরত পাঠান (লাইন খালি হবে)"
                                >
                                  <PackageMinus className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button
                                onClick={() => loadPlanForEdit(p)}
                                className="p-1.5 rounded bg-yellow-600/20 border border-yellow-600/40 text-yellow-400 hover:bg-yellow-600/40 cursor-pointer"
                                title="এডিট"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() =>
                                  setNotesPlan({ id: p.id, label: `${p.buyer} — ${p.style}` })
                                }
                                className="p-1.5 rounded bg-blue-600/20 border border-blue-600/40 text-blue-400 hover:bg-blue-600/40 cursor-pointer"
                                title="নোটস (তারিখ ভিত্তিক)"
                              >
                                <StickyNote className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => deleteMutation.mutate(p.id)}
                                className="p-1.5 rounded bg-red-600/20 border border-red-600/40 text-red-400 hover:bg-red-600/40 cursor-pointer"
                                title="ডিলিট"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        );
      })()}
      <HolidayCalendarDialog open={holidayCalOpen} onClose={() => setHolidayCalOpen(false)} />
      <PlanNotesDialog
        open={!!notesPlan}
        onClose={() => setNotesPlan(null)}
        planId={notesPlan?.id ?? null}
        planLabel={notesPlan?.label}
      />
    </div>
  );
}

const inputCls =
  "w-full bg-input border border-border rounded-lg p-2.5 text-sm outline-none focus:border-primary transition";

function Field({
  label,
  children,
  accent,
}: {
  label: string;
  children: React.ReactNode;
  accent?: "teal" | "blue" | "yellow" | "red" | "purple" | "emerald";
}) {
  const colorMap: Record<string, string> = {
    teal: "text-teal-400",
    blue: "text-blue-400",
    yellow: "text-yellow-400",
    red: "text-red-400",
    purple: "text-purple-400",
    emerald: "text-emerald-400",
  };
  return (
    <div>
      <label
        className={`block text-xs font-semibold mb-2 ${accent ? colorMap[accent] : "text-muted-foreground"}`}
      >
        {label}
      </label>
      {children}
    </div>
  );
}

function LineCard({
  line,
  presets,
  lastOutput,
  nextOpen,
  pushback,
  adjustments,
  onAddAdjustment,
  onRemoveAdjustment,
  onChange,
  onAddLaterBlock,
  canDelete,
  onDelete,
}: {
  line: LineInput;
  presets: string[];
  lastOutput?: string;
  nextOpen?: string;
  pushback?: { delay: number; buyer: string; style: string; oldStart: string; newStart: string };
  adjustments: TargetAdjustment[];
  onAddAdjustment: (from: string, to: string, tgt: number) => void;
  onRemoveAdjustment: (id: number) => void;
  onChange: (patch: Partial<LineInput>) => void;
  onAddLaterBlock: () => void;
  canDelete?: boolean;
  onDelete?: () => void;
}) {
  const chainOn = line.chainAuto !== false;
  const [rFrom, setRFrom] = useState("");
  const [rTo, setRTo] = useState("");
  const [rTgt, setRTgt] = useState<number | "">("");
  const options = buildLineOptions(line.name, [], presets).filter((name) => {
    const normalized = normLine(name);
    const num = parseInt(normalized);
    return isNaN(num) || num >= 15;
  });
  const borderCls = pushback ? "border-amber-500" : "border-border";
  return (
    <div className={`bg-panel-2 p-3 rounded-lg border ${borderCls} flex flex-col gap-2`}>
      <div className="flex justify-between items-center border-b border-border pb-1.5 gap-2">
        <select
          value={line.name}
          onChange={(e) => onChange({ name: e.target.value })}
          className={`bg-input border border-emerald-500/50 text-emerald-400 font-bold rounded px-2 py-1 text-xs outline-none w-full`}
        >
          {options.map((n) => (
            <option key={n} value={n}>
              {n.startsWith("Line - ") ? n.replace("Line - ", "") : n}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => onChange({ chainAuto: !chainOn })}
          title={
            chainOn
              ? "চেইন অন — আগের স্টাইল শেষ হলে এই লাইনের স্টার্ট ডেট অটো-শিফট হবে"
              : "চেইন অফ — এই লাইনের স্টার্ট ডেট ম্যানুয়াল, অটো-শিফট হবে না"
          }
          className={`shrink-0 p-1 rounded border text-[10px] font-bold ${
            chainOn
              ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-300"
              : "bg-panel border-border text-muted-foreground"
          }`}
        >
          {chainOn ? <Link2 className="w-3 h-3" /> : <Link2Off className="w-3 h-3" />}
        </button>
        <button
          type="button"
          onClick={onAddLaterBlock}
          title="এই একই লাইনে পরের ওপেন ডেট থেকে আবার প্ল্যান করুন"
          className="shrink-0 inline-flex items-center gap-1 rounded border border-sky-500/50 bg-sky-500/10 px-1.5 py-1 text-[10px] font-bold text-sky-300 hover:bg-sky-500/20"
        >
          <Plus className="w-3 h-3" /> আবার
        </button>
        {onDelete && (
          <button
            type="button"
            onClick={onDelete}
            disabled={!canDelete}
            title={canDelete ? `"${line.name}" লাইনটি মুছুন` : "কমপক্ষে একটি লাইন থাকা আবশ্যক"}
            className={`shrink-0 p-1 rounded border transition ${
              canDelete
                ? "border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20 hover:text-red-200 cursor-pointer"
                : "border-border/30 bg-panel/30 text-muted-foreground/30 cursor-not-allowed opacity-40"
            }`}
          >
            <Trash2 className="w-3 h-3" />
          </button>
        )}
      </div>
      {pushback && (
        <div className="px-2 py-1.5 rounded-md bg-amber-950/60 border border-amber-500/60 text-[10px] text-amber-200 leading-tight">
          <div className="font-bold text-amber-300">
            ⚠️ এই লাইনে পরের স্টাইল {pushback.delay} দিন পিছিয়ে যাবে
          </div>
          <div className="text-amber-200/90 mt-0.5">
            "{pushback.buyer} / {pushback.style}" —{" "}
            <span className="font-mono">{formatDate(pushback.oldStart)}</span> →{" "}
            <span className="font-mono">{formatDate(pushback.newStart)}</span>
          </div>
        </div>
      )}
      {lastOutput ? (
        <div className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-md bg-emerald-950/40 border border-emerald-500/30 text-[10px]">
          <div className="leading-tight">
            <div className="text-emerald-300 font-bold">
              শেষ আউটপুট: <span className="font-mono">{formatDate(lastOutput)}</span>
            </div>
            {nextOpen && (
              <div className="text-amber-300">
                পরবর্তী ওপেন: <span className="font-mono">{formatDate(nextOpen)}</span>
              </div>
            )}
          </div>
          {nextOpen && line.startDateStr !== nextOpen && (
            <button
              type="button"
              onClick={() => onChange({ startDateStr: nextOpen })}
              className="shrink-0 px-2 py-1 rounded bg-amber-500/20 border border-amber-500/50 text-amber-200 font-bold hover:bg-amber-500/30"
              title="এই লাইনের পরবর্তী ওপেন ডেট থেকে শুরু করুন"
            >
              ব্যবহার করুন →
            </button>
          )}
        </div>
      ) : (
        <div className="px-2 py-1 rounded-md bg-panel/60 border border-border/60 text-[10px] text-muted-foreground">
          এই লাইনে আগের কোনো প্ল্যান নেই — যেকোনো তারিখ থেকে শুরু করুন।
        </div>
      )}
      <div className="grid grid-cols-4 gap-2 mt-1">
        <div>
          <label className="block text-[10px] text-muted-foreground mb-1">১ম আউটপুট</label>
          <input
            type="date"
            value={line.startDateStr}
            onChange={(e) => onChange({ startDateStr: e.target.value })}
            className="w-full bg-input border border-border rounded p-1.5 text-xs text-yellow-400 font-bold"
          />
        </div>
        <div>
          <label className="block text-[10px] text-muted-foreground mb-1">এলোকেশন</label>
          <input
            type="number"
            value={line.allocatedOrderQty || ""}
            onChange={(e) => onChange({ allocatedOrderQty: Number(e.target.value) || 0 })}
            placeholder="50000"
            className="w-full bg-input border border-border rounded p-1.5 text-xs text-yellow-300 font-bold"
          />
        </div>
        <div>
          <label className="block text-[10px] text-muted-foreground mb-1">ব্যতিক্রম টার্গেট</label>
          <input
            type="number"
            value={line.targetOverride || ""}
            onChange={(e) => onChange({ targetOverride: Number(e.target.value) || null })}
            placeholder="ডিফল্ট"
            title="এই লাইনে এই স্টাইলের আলাদা ডেইলি টার্গেট (খালি রাখলে ডিফল্ট/SMV টার্গেট)"
            className={`w-full bg-input border rounded p-1.5 text-xs font-bold ${
              line.targetOverride
                ? "border-fuchsia-500/60 text-fuchsia-300"
                : "border-border text-foreground"
            }`}
          />
        </div>
        <div>
          <label className="block text-[10px] text-muted-foreground mb-1">লার্নিং কার্ভ</label>
          <select
            value={line.applyLC ? "yes" : "no"}
            onChange={(e) => onChange({ applyLC: e.target.value === "yes" })}
            className="w-full bg-input border border-border rounded p-1.5 text-xs font-semibold"
          >
            <option value="yes">প্রযোজ্য</option>
            <option value="no">প্রযোজ্য নয়</option>
          </select>
        </div>
      </div>

      {/* Per-line target ranges */}
      <div className="mt-2 pt-2 border-t border-border/60">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] font-bold text-blue-300">
            ⏱️ টার্গেট রেঞ্জ (এই লাইনে, এই স্টাইলে)
          </span>
          {adjustments.length > 0 && (
            <span className="text-[10px] text-muted-foreground">{adjustments.length} রেঞ্জ</span>
          )}
        </div>
        <div className="grid grid-cols-[1fr_1fr_80px_auto] gap-1.5 items-end">
          <div>
            <label className="block text-[9px] text-muted-foreground">শুরু</label>
            <input
              type="date"
              value={rFrom}
              onChange={(e) => setRFrom(e.target.value)}
              className="w-full bg-input border border-border rounded p-1 text-[11px]"
            />
          </div>
          <div>
            <label className="block text-[9px] text-muted-foreground">শেষ</label>
            <input
              type="date"
              value={rTo}
              onChange={(e) => setRTo(e.target.value)}
              className="w-full bg-input border border-border rounded p-1 text-[11px]"
            />
          </div>
          <div>
            <label className="block text-[9px] text-muted-foreground">টার্গেট</label>
            <input
              type="number"
              value={rTgt}
              onChange={(e) => setRTgt(e.target.value === "" ? "" : Number(e.target.value))}
              placeholder="1400"
              className="w-full bg-input border border-border rounded p-1 text-[11px] text-blue-300 font-bold"
            />
          </div>
          <button
            type="button"
            onClick={() => {
              if (rFrom && rTo && rTgt !== "" && Number(rTgt) > 0) {
                onAddAdjustment(rFrom, rTo, Number(rTgt));
                setRFrom("");
                setRTo("");
                setRTgt("");
              } else {
                toast.error("তারিখ ও টার্গেট দিন।");
              }
            }}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-1 px-2 rounded text-[11px]"
            title="এই লাইনে টার্গেট রেঞ্জ যোগ করুন"
          >
            <Plus className="w-3 h-3" />
          </button>
        </div>
        {adjustments.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {adjustments.map((a) => (
              <span
                key={a.id}
                className="bg-blue-950 border border-blue-500/50 text-blue-300 text-[10px] px-2 py-0.5 rounded-md flex items-center gap-1.5"
              >
                {formatDate(a.fromDate)}–{formatDate(a.toDate)} ➔{" "}
                <b className="text-emerald-400">{a.newTarget}/d</b>
                <button
                  type="button"
                  onClick={() => onRemoveAdjustment(a.id)}
                  className="text-red-400 font-bold"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AllocationSummary({
  lines,
  orderQty,
  excessPct,
  adjustments,
  adjEnabled,
  holidays,
  dailyTarget,
  learningCurve,
}: {
  lines: { name: string; allocatedOrderQty: number; startDateStr: string }[];
  orderQty: number;
  excessPct: number;
  adjustments: TargetAdjustment[];
  adjEnabled: boolean;
  holidays: string[];
  dailyTarget: number;
  learningCurve?: number[];
}) {
  const rows = useMemo(() => {
    if (!orderQty || orderQty <= 0 || !dailyTarget || dailyTarget <= 0) return [];
    const derived = deriveLineAllocations({
      lines,
      orderQty,
      excessPct,
      targetAdjustments: adjustments,
      targetAdjustmentsEnabled: adjEnabled,
      holidays,
    });
    return derived.map((d) => {
      // Re-calculate plan for this specific line to find its finish date
      const singleLineResult = calculatePlan({
        buyer: "TEMP",
        style: "TEMP",
        orderQty: d.alloc,
        excessPct: excessPct,
        dailyTargetPerLine: dailyTarget,
        shipmentDate: "2099-12-31",
        lines: [
          {
            id: 1,
            name: d.name,
            startDateStr:
              lines.find((l) => l.name === d.name)?.startDateStr ||
              new Date().toISOString().slice(0, 10),
            allocatedOrderQty: d.alloc,
            applyLC: true,
          },
        ],
        customHolidays: holidays,
        targetAdjustments: adjustments.filter((a) => a.lineName === d.name),
        targetAdjustmentsEnabled: adjEnabled,
        learningCurve: learningCurve,
      });

      return {
        name: d.name,
        alloc: d.alloc,
        source: d.source,
        rangeDays: d.rangeDays,
        rangeCapacity: d.rangeCapacity,
        finishesEarly: !!d.finishesEarly,
        manual: d.source === "manual",
        auto: d.source === "auto",
        range: d.source === "range",
        planQty: d.planQty,
        finishDate: singleLineResult.lines[0]?.finishDateStr || "",
      };
    });
  }, [lines, orderQty, excessPct, adjustments, adjEnabled, holidays, dailyTarget, learningCurve]);

  const totalAlloc = rows.reduce((s, r) => s + r.alloc, 0);
  const totalPlan = rows.reduce((s, r) => s + r.planQty, 0);
  const diff = totalAlloc - (orderQty || 0);
  const unplanned = Math.max(0, (orderQty || 0) - totalAlloc);

  if (!orderQty || orderQty <= 0 || !dailyTarget || dailyTarget <= 0 || rows.length === 0)
    return null;

  return (
    <div className="mt-5 rounded-xl border border-border bg-panel-2/50 p-4">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <h3 className="text-sm font-extrabold bn-gradient-text">📊 এলোকেশন সামারি</h3>
        <div className="text-[11px] text-muted-foreground">
          Excess: <span className="font-bold text-teal-400">{excessPct}%</span>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-left text-muted-foreground border-b border-border">
              <th className="py-2 pr-3 font-bold">লাইন</th>
              <th className="py-2 pr-3 font-bold text-right">Allocated Qty</th>
              <th className="py-2 pr-3 font-bold text-right">+ Excess</th>
              <th className="py-2 pr-3 font-bold text-right">Plan Qty</th>
              <th className="py-2 pr-3 font-bold text-right">% of Order</th>
              <th className="py-2 pr-3 font-bold text-right text-emerald-400">Finish Date</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-b border-border/50">
                <td className="py-2 pr-3 font-semibold">
                  {r.name}
                  {r.manual && (
                    <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300 border border-sky-500/40">
                      manual
                    </span>
                  )}
                  {r.range && (
                    <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-violet-500/15 text-violet-300 border border-violet-500/40">
                      range{r.rangeDays ? ` · ${r.rangeDays}d` : ""}
                    </span>
                  )}
                  {r.finishesEarly && (
                    <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/40">
                      আগেই শেষ · ক্যাপাসিটি {r.rangeCapacity?.toLocaleString()}
                    </span>
                  )}

                  {r.auto && (
                    <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/40">
                      auto
                    </span>
                  )}
                </td>
                <td className="py-2 pr-3 text-right tabular-nums">{r.alloc.toLocaleString()}</td>
                <td className="py-2 pr-3 text-right tabular-nums text-teal-400">
                  +{Math.max(0, r.planQty - r.alloc).toLocaleString()}
                </td>
                <td className="py-2 pr-3 text-right tabular-nums font-bold">
                  {r.planQty.toLocaleString()}
                </td>
                <td className="py-2 pr-3 text-right tabular-nums text-muted-foreground">
                  {orderQty > 0 ? ((r.alloc / orderQty) * 100).toFixed(1) : "0.0"}%
                </td>
                <td className="py-2 pr-3 text-right tabular-nums text-emerald-400 font-mono">
                  {formatDate(r.finishDate)}
                </td>
              </tr>
            ))}
            <tr className="bg-panel/60">
              <td className="py-2 pr-3 font-extrabold">মোট</td>
              <td className="py-2 pr-3 text-right tabular-nums font-extrabold">
                {totalAlloc.toLocaleString()}
              </td>
              <td className="py-2 pr-3 text-right tabular-nums font-extrabold text-teal-400">
                +{Math.max(0, totalPlan - totalAlloc).toLocaleString()}
              </td>
              <td className="py-2 pr-3 text-right tabular-nums font-extrabold">
                {totalPlan.toLocaleString()}
              </td>
              <td className="py-2 pr-3 text-right tabular-nums">
                {orderQty > 0 ? ((totalAlloc / orderQty) * 100).toFixed(1) : "0.0"}%
              </td>
              <td className="py-2 pr-3" />
            </tr>
            {unplanned > 0 && (
              <tr className="bg-rose-500/10">
                <td className="py-2 pr-3 font-extrabold text-rose-300">
                  আন-প্ল্যান্ড (কোনো লাইনে বসেনি)
                </td>
                <td className="py-2 pr-3 text-right tabular-nums font-extrabold text-rose-300">
                  {unplanned.toLocaleString()}
                </td>
                <td className="py-2 pr-3" />
                <td className="py-2 pr-3" />
                <td className="py-2 pr-3 text-right tabular-nums text-rose-300">
                  {((unplanned / orderQty) * 100).toFixed(1)}%
                </td>
                <td className="py-2 pr-3" />
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {unplanned > 0 && (
        <div className="mt-3 rounded-lg border border-rose-500/40 bg-rose-500/10 p-2 text-xs text-rose-200">
          ⚠️ {unplanned.toLocaleString()} pcs এখনো <b>unplanned</b> — সব লাইনেই manual allocation বা
          date-range টার্গেট দেওয়া আছে, তাই auto-allocation করার মতো কোনো লাইন খালি নেই। নতুন লাইন
          যোগ করুন অথবা কোনো লাইনের allocation qty খালি রাখুন।
        </div>
      )}

      <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
        <div className="rounded-lg border border-border bg-panel/60 p-2">
          <div className="text-[10px] text-muted-foreground font-bold">অর্ডার Qty (input)</div>
          <div className="font-extrabold tabular-nums">{orderQty.toLocaleString()}</div>
        </div>
        <div className="rounded-lg border border-border bg-panel/60 p-2">
          <div className="text-[10px] text-muted-foreground font-bold">মোট Allocated</div>
          <div className="font-extrabold tabular-nums">{totalAlloc.toLocaleString()}</div>
        </div>
        <div
          className={
            "rounded-lg border p-2 " +
            (diff === 0
              ? "border-emerald-500/40 bg-emerald-500/10"
              : diff > 0
                ? "border-amber-500/40 bg-amber-500/10"
                : "border-rose-500/40 bg-rose-500/10")
          }
        >
          <div className="text-[10px] font-bold opacity-80">পার্থক্য (Allocated − Order)</div>
          <div className="font-extrabold tabular-nums">
            {diff > 0 ? "+" : ""}
            {diff.toLocaleString()}
            {diff === 0 && <span className="ml-2 text-emerald-300">✓ মিলে গেছে</span>}
            {diff > 0 && <span className="ml-2 text-amber-300">অতিরিক্ত এলোকেশন</span>}
            {diff < 0 && <span className="ml-2 text-rose-300">কম এলোকেশন</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
