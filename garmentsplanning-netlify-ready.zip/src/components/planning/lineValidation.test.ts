import { describe, it, expect } from "vitest";
import { findDuplicateLineName, buildLineOptions, pickAvailableLineName } from "./lineValidation";

const PRESETS = ["Line - 1", "Line - 2", "Line - 3", "Line - 4", "Line - 5"];

describe("findDuplicateLineName", () => {
  it("returns null when all line names are unique", () => {
    expect(
      findDuplicateLineName([{ name: "Line - 1" }, { name: "Line - 2" }, { name: "Line - 3" }]),
    ).toBeNull();
  });

  it("detects a duplicate when the same line is selected twice", () => {
    expect(
      findDuplicateLineName([{ name: "Line - 1" }, { name: "Line - 2" }, { name: "Line - 1" }]),
    ).toBe("Line - 1");
  });

  it("detects duplicate that appears after reordering rows", () => {
    // Simulate: user moves row-A (Line-2) below row-B (Line-2 originally different, then edited)
    const reordered = [{ name: "Line - 3" }, { name: "Line - 2" }, { name: "Line - 2" }];
    expect(findDuplicateLineName(reordered)).toBe("Line - 2");
  });

  it("detects duplicate when a user edits row 1 to match row 15", () => {
    const twenty = Array.from({ length: 20 }, (_, i) => ({ name: `Line - ${i + 1}` }));
    twenty[0] = { name: "Line - 15" }; // user edits row 1 to duplicate row 15
    expect(findDuplicateLineName(twenty)).toBe("Line - 15");
  });

  it("returns null for an empty list", () => {
    expect(findDuplicateLineName([])).toBeNull();
  });

  it("is case-sensitive (different casing is not a duplicate)", () => {
    expect(findDuplicateLineName([{ name: "Line - 1" }, { name: "line - 1" }])).toBeNull();
  });
});

describe("buildLineOptions", () => {
  it("excludes names taken by other rows", () => {
    const opts = buildLineOptions("Line - 3", ["Line - 1", "Line - 2"], PRESETS);
    expect(opts).toEqual(["Line - 3", "Line - 4", "Line - 5"]);
  });

  it("always includes the current row's own name even if duplicated elsewhere", () => {
    // Row currently shows Line - 2 but another row also has Line - 2 (duplicate state).
    // The select must still be able to render its current value.
    const opts = buildLineOptions("Line - 2", ["Line - 2", "Line - 1"], PRESETS);
    expect(opts).toContain("Line - 2");
  });

  it("returns full preset list when no other rows are taken", () => {
    expect(buildLineOptions("Line - 1", [], PRESETS)).toEqual(PRESETS);
  });

  it("prepends current name when it isn't in presets (custom name)", () => {
    const opts = buildLineOptions("Custom Line", ["Line - 1"], PRESETS);
    expect(opts[0]).toBe("Custom Line");
    expect(opts).not.toContain("Line - 1");
  });
});

describe("pickAvailableLineName", () => {
  it("picks the first free preset when adding a new line", () => {
    expect(pickAvailableLineName(["Line - 1", "Line - 2"], PRESETS, 3)).toBe("Line - 3");
  });

  it("skips already-used presets even if the free one is non-sequential", () => {
    expect(
      pickAvailableLineName(["Line - 1", "Line - 2", "Line - 3", "Line - 5"], PRESETS, 5),
    ).toBe("Line - 4");
  });

  it("falls back to Line - N when every preset is taken", () => {
    expect(pickAvailableLineName(PRESETS, PRESETS, 6)).toBe("Line - 6");
  });

  it("increments fallback when the fallback name is also taken", () => {
    expect(pickAvailableLineName([...PRESETS, "Line - 6", "Line - 7"], PRESETS, 6)).toBe(
      "Line - 8",
    );
  });
});

describe("integration: reorder + edit scenarios", () => {
  it("adding a new line after reorder does not create a duplicate", () => {
    // User has rows [Line-2, Line-1, Line-3] (reordered) and adds a new line.
    const existing = ["Line - 2", "Line - 1", "Line - 3"];
    const newName = pickAvailableLineName(existing, PRESETS, existing.length + 1);
    const lines = [...existing, newName].map((n) => ({ name: n }));
    expect(findDuplicateLineName(lines)).toBeNull();
    expect(newName).toBe("Line - 4");
  });

  it("editing a row to match another row is caught by validation", () => {
    const lines = [{ name: "Line - 1" }, { name: "Line - 2" }, { name: "Line - 3" }];
    // Simulate edit of index 2 -> "Line - 1"
    lines[2] = { name: "Line - 1" };
    expect(findDuplicateLineName(lines)).toBe("Line - 1");
  });

  it("buildLineOptions hides names of siblings so the dropdown cannot introduce a duplicate", () => {
    const lines = [{ name: "Line - 1" }, { name: "Line - 2" }, { name: "Line - 3" }];
    // Options rendered for row index 1 (Line - 2)
    const others = lines.filter((_, i) => i !== 1).map((l) => l.name);
    const opts = buildLineOptions("Line - 2", others, PRESETS);
    expect(opts).not.toContain("Line - 1");
    expect(opts).not.toContain("Line - 3");
    expect(opts).toContain("Line - 2");
  });
});
