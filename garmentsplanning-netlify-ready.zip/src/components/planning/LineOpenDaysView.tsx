import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import type { PlanResult } from "@/lib/plan-calc";
import { getLocalDateStr } from "@/lib/plan-calc";
import { useGlobalHolidays } from "./HolidayCalendar";
import { FilterSelect } from "./LineSummaryView";
import {
  buildLinePresetLookup,
  canonicalLineName,
  normLine,
  sortLineNamesByPreset,
} from "./lineLookup";
import { useLinePresets } from "@/hooks/use-line-presets";

type Row = {
  id: string;
  buyer: string;
  style: string;
  calc_result: PlanResult;
};

type MonthCell = {
  month: string; // "Apr 2025"
  workingDays: number;
  plannedDays: number;
  openDays: number;
};

type LineOpen = {
  line: string;
  months: Record<string, MonthCell>;
  totalOpen: number;
  totalWorking: number;
  totalPlanned: number;
};

function monthKey(y: number, m: number) {
  return new Date(y, m, 1).toLocaleString("en-US", { month: "short", year: "numeric" });
}

function workingDaysInMonth(year: number, month: number, holidays: Set<string>) {
  const last = new Date(year, month + 1, 0).getDate();
  let count = 0;
  for (let d = 1; d <= last; d++) {
    const dt = new Date(year, month, d);
    const ds = getLocalDateStr(dt);
    if (dt.getDay() === 5) continue;
    if (holidays.has(ds)) continue;
    count++;
  }
  return count;
}

function computeLineOpen(plans: Row[], holidays: string[], linePresets: string[]) {
  const holidaySet = new Set(holidays);
  const presetLookup = buildLinePresetLookup(linePresets);

  // Group planned dates by normalized line key, but keep a display name
  const byLine: Record<string, Set<string>> = {};
  const displayName: Record<string, string> = {};
  plans.forEach((p) => {
    (p.calc_result?.lines ?? []).forEach((ln) => {
      if (!ln?.name) return;
      const key = normLine(ln.name);
      if (!key) return;
      if (!displayName[key]) displayName[key] = canonicalLineName(ln.name, presetLookup);
      const set = (byLine[key] ??= new Set());
      (ln.dailyProduction ?? []).forEach((dp) => set.add(dp.date));
    });
  });

  // Determine month span across all plans
  const allDates: string[] = [];
  Object.values(byLine).forEach((s) => s.forEach((d) => allDates.push(d)));
  if (allDates.length === 0) return { lines: [] as LineOpen[], months: [] as string[] };

  allDates.sort();
  const first = new Date(allDates[0]);
  const last = new Date(allDates[allDates.length - 1]);

  // Build month list from first to last
  const monthList: { key: string; y: number; m: number }[] = [];
  const cur = new Date(first.getFullYear(), first.getMonth(), 1);
  const end = new Date(last.getFullYear(), last.getMonth(), 1);
  while (cur <= end) {
    monthList.push({
      key: monthKey(cur.getFullYear(), cur.getMonth()),
      y: cur.getFullYear(),
      m: cur.getMonth(),
    });
    cur.setMonth(cur.getMonth() + 1);
  }

  // Precompute working days per month
  const workingByMonth: Record<string, number> = {};
  monthList.forEach((mo) => {
    workingByMonth[mo.key] = workingDaysInMonth(mo.y, mo.m, holidaySet);
  });

  const lines: LineOpen[] = [];
  Object.entries(byLine).forEach(([lineKey, plannedSet]) => {
    // Count planned days per month for this line
    const plannedByMonth: Record<string, number> = {};
    plannedSet.forEach((ds) => {
      const dt = new Date(ds);
      const k = monthKey(dt.getFullYear(), dt.getMonth());
      plannedByMonth[k] = (plannedByMonth[k] ?? 0) + 1;
    });

    const months: Record<string, MonthCell> = {};
    let totalOpen = 0;
    let totalWorking = 0;
    let totalPlanned = 0;
    monthList.forEach((mo) => {
      const w = workingByMonth[mo.key] ?? 0;
      const p = plannedByMonth[mo.key] ?? 0;
      const open = Math.max(0, w - p);
      months[mo.key] = { month: mo.key, workingDays: w, plannedDays: p, openDays: open };
      totalWorking += w;
      totalPlanned += p;
      totalOpen += open;
    });

    lines.push({
      line: displayName[lineKey] ?? lineKey,
      months,
      totalOpen,
      totalWorking,
      totalPlanned,
    });
  });

  const sortedNames = sortLineNamesByPreset(
    lines.map((l) => l.line),
    linePresets,
  );
  const sortOrder = new Map(sortedNames.map((line, index) => [line, index]));
  lines.sort((a, b) => (sortOrder.get(a.line) ?? 0) - (sortOrder.get(b.line) ?? 0));

  return { lines, months: monthList.map((m) => m.key), workingByMonth };
}

export function LineOpenDaysView() {
  const qc = useQueryClient();
  const { data: holidays = [] } = useGlobalHolidays();
  const { presets: linePresets } = useLinePresets();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "line-open"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-line-open-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const {
    lines: allLines,
    months,
    workingByMonth = {},
  } = useMemo(() => computeLineOpen(plans, holidays, linePresets), [plans, holidays, linePresets]);

  const [lineFilter, setLineFilter] = useState<string[]>([]);
  const lineOptions = useMemo(
    () =>
      sortLineNamesByPreset(
        allLines.map((l) => l.line),
        linePresets,
      ),
    [allLines, linePresets],
  );
  const lines = useMemo(
    () =>
      lineFilter.length === 0 ? allLines : allLines.filter((l) => lineFilter.includes(l.line)),
    [allLines, lineFilter],
  );

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (allLines.length === 0) {
    return (
      <div className="p-12 text-center">
        <p className="text-sm text-muted-foreground">কোনো লাইন ওপেন ডে নেই।</p>
        <p className="text-xs text-muted-foreground mt-1">
          প্ল্যান সেভ হলে এখানে গ্যাপ/ওপেন ডে দেখা যাবে।
        </p>
      </div>
    );
  }

  // Grand totals per month (filtered)
  const monthOpenTotal: Record<string, number> = {};
  months.forEach((m) => (monthOpenTotal[m] = 0));
  let grandOpen = 0;
  lines.forEach((l) => {
    grandOpen += l.totalOpen;
    months.forEach((m) => (monthOpenTotal[m] += l.months[m].openDays));
  });

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40">
        <h2 className="text-base md:text-lg font-bold text-amber-400">🕒 Line Open Days</h2>
        <p className="text-xs text-muted-foreground mt-1">
          মাস-ভিত্তিক ওপেন ডে = (মাসের ওয়ার্কিং ডে − শুক্রবার − কাস্টম ছুটি) − ঐ মাসে প্ল্যান করা
          দিন
        </p>
      </div>
      <div className="p-3 md:p-4 border-b border-border bg-panel/40 flex flex-wrap items-center gap-2">
        <FilterSelect
          label="Line"
          value={lineFilter}
          onChange={setLineFilter}
          options={lineOptions}
        />
        {lineFilter.length > 0 && (
          <button
            onClick={() => setLineFilter([])}
            className="text-xs font-bold text-red-300 hover:text-red-200 underline"
          >
            Clear
          </button>
        )}
        <span className="inline-flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] font-bold text-amber-300">
          🕒 Σ Open Days ({lineFilter.length === 0 ? "all" : `${lines.length} selected`}):{" "}
          <span className="font-mono">{lines.reduce((s, l) => s + l.totalOpen, 0)}d</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-[11px] font-bold text-emerald-300">
          Planned:{" "}
          <span className="font-mono">{lines.reduce((s, l) => s + l.totalPlanned, 0)}d</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-md border border-sky-500/40 bg-sky-500/10 px-2 py-1 text-[11px] font-bold text-sky-300">
          Working:{" "}
          <span className="font-mono">{lines.reduce((s, l) => s + l.totalWorking, 0)}d</span>
        </span>
        <span className="text-[11px] text-muted-foreground ml-auto">
          {lines.length} / {allLines.length} lines
        </span>
      </div>
      <div className="overflow-auto max-h-[75vh]">
        <table className="w-full text-left border-collapse text-sm">
          <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
            <tr>
              <th className="p-4 border-r border-border bg-panel-2 sticky left-0 top-0 z-30 w-40">
                লাইন
              </th>
              {months.map((m) => (
                <th
                  key={m}
                  className="p-3 text-center border-r border-border/60 bg-panel-2/95 sticky top-0 z-20"
                >
                  <div>{m}</div>
                  <div className="text-[10px] normal-case text-muted-foreground/70 font-normal mt-0.5">
                    Working: {workingByMonth[m] ?? 0}d
                  </div>
                </th>
              ))}
              <th className="p-3 text-center bg-panel-2 text-yellow-400 sticky top-0 z-20">
                টোটাল
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {lines.map((l) => (
              <tr key={l.line} className="hover:bg-panel-2/40 transition align-top">
                <td className="p-4 border-r border-border bg-panel font-bold sticky left-0 z-10">
                  <div className="text-foreground">
                    {l.line.startsWith("Line - ") ? l.line.replace("Line - ", "") : l.line}
                  </div>
                  <div className="text-[10px] text-muted-foreground font-normal mt-1">
                    Planned {l.totalPlanned}d / Working {l.totalWorking}d
                  </div>
                </td>
                {months.map((m) => {
                  const cell = l.months[m];
                  return (
                    <td key={m} className="p-3 text-center border-r border-border/60 bg-panel-2/20">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold border ${
                          cell.openDays > 0
                            ? "bg-amber-900/60 border-amber-600/60 text-amber-200"
                            : "bg-emerald-950/60 border-emerald-700/60 text-emerald-300"
                        }`}
                      >
                        {cell.openDays}d Open
                      </span>
                      <div className="text-[10px] text-muted-foreground mt-1 leading-tight">
                        {cell.plannedDays}d planned
                      </div>
                    </td>
                  );
                })}
                <td className="p-3 text-center bg-panel/60">
                  <span className="inline-block px-2 py-0.5 bg-amber-950/60 border border-amber-700/60 rounded text-[11px] text-amber-300 font-bold">
                    🕒 {l.totalOpen}d
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-panel-2/95 font-bold border-t-2 border-border">
            <tr>
              <td className="p-4 border-r border-border bg-panel-2 sticky left-0 z-10 text-right uppercase text-xs text-muted-foreground">
                মান্থলি টোটাল ওপেন ➔
              </td>
              {months.map((m) => (
                <td key={m} className="p-4 text-center border-r border-border/60 bg-amber-950/60">
                  <span className="inline-block px-2.5 py-0.5 bg-amber-900 border border-amber-500 rounded text-xs text-amber-200 font-bold">
                    {monthOpenTotal[m]}d
                  </span>
                </td>
              ))}
              <td className="p-4 text-center bg-panel-2">
                <span className="inline-block px-2.5 py-0.5 bg-amber-500/20 border border-amber-500 rounded text-xs text-amber-300 font-bold">
                  🕒 {grandOpen}d Total
                </span>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
