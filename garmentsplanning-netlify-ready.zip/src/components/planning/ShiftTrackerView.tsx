import { Fragment, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Loader2,
  FileDown,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Save as SaveIcon,
} from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import {
  calculatePlan,
  formatDate,
  nextWorkingDay,
  type PlanResult,
  type LineInput,
  type TargetAdjustment,
} from "@/lib/plan-calc";
import { buildPlanSnapshot, daysBetween, type PlanSnapshot } from "@/lib/plan-snapshot";
import { useGlobalHolidays } from "./HolidayCalendar";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  normLine,
  sortLineNamesByPreset,
} from "./lineLookup";

type SavedPlan = {
  id: string;
  buyer: string;
  style: string;
  order_qty: number;
  excess_pct: number;
  daily_target: number;
  num_lines: number;
  shipment_date: string;
  config: {
    lines: LineInput[];
    customHolidays: string[];
    targetAdjustments: TargetAdjustment[];
    targetAdjustmentsEnabled: boolean;
  };
  calc_result: PlanResult;
  previous_snapshot: PlanSnapshot | null;
};

type Row = {
  planId: string;
  line: string;
  rawLine: string;
  buyer: string;
  style: string;
  prevFirst: string;
  curFirst: string;
  prevLast: string;
  curLast: string;
  firstShift: number; // + = pushed back, - = advanced
  lastShift: number;
};

function buildRows(plans: SavedPlan[], linePresets: string[]): Row[] {
  const rows: Row[] = [];
  const presetLookup = buildLinePresetLookup(linePresets);
  for (const p of plans) {
    const snap = p.previous_snapshot;
    if (!snap || !snap.lines?.length) continue;
    const curLines = p.calc_result?.lines ?? [];
    for (const prevLine of snap.lines) {
      const prevKey = normLine(prevLine.name);
      const cur = curLines.find((l) => normLine(l.name) === prevKey);
      if (!cur) continue;
      const daily = cur.dailyProduction ?? [];
      const curFirst = daily.length ? daily[0].date : (cur.startDateStr ?? "");
      const curLast = cur.finishDateStr ?? (daily.length ? daily[daily.length - 1].date : "");
      const firstShift = daysBetween(prevLine.firstOutput, curFirst);
      const lastShift = daysBetween(prevLine.lastOutput, curLast);
      rows.push({
        planId: p.id,
        line: canonicalLineName(prevLine.name, presetLookup),
        rawLine: cur.name,
        buyer: p.buyer,
        style: p.style,
        prevFirst: prevLine.firstOutput,
        curFirst,
        prevLast: prevLine.lastOutput,
        curLast,
        firstShift,
        lastShift,
      });
    }
  }
  return rows;
}

export function ShiftTrackerView() {
  const qc = useQueryClient();
  const { data: globalHolidays = [] } = useGlobalHolidays();
  const { presets: linePresets } = useLinePresets();
  const [onlyChanged, setOnlyChanged] = useState(true);
  const [rangeFrom, setRangeFrom] = useState("");
  const [rangeTo, setRangeTo] = useState("");
  const [rangeField, setRangeField] = useState<"curFirst" | "prevFirst">("curFirst");
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>("");
  const [savingKey, setSavingKey] = useState<string | null>(null);

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "shift-tracker"],
    queryFn: async (): Promise<SavedPlan[]> => {
      const { data, error } = await supabase.from("plans").select("*").is("completed_at", null);
      if (error) throw error;
      return (data ?? []) as unknown as SavedPlan[];
    },
  });

  const rows = useMemo(() => {
    let list = buildRows(plans, linePresets);
    if (onlyChanged) list = list.filter((r) => r.firstShift !== 0 || r.lastShift !== 0);
    if (rangeFrom) list = list.filter((r) => (r[rangeField] || "") >= rangeFrom);
    if (rangeTo) list = list.filter((r) => (r[rangeField] || "") <= rangeTo);
    list.sort(
      (a, b) =>
        sortLineNamesByPreset([a.line, b.line], linePresets).indexOf(a.line) -
          sortLineNamesByPreset([a.line, b.line], linePresets).indexOf(b.line) ||
        (a.curFirst || "").localeCompare(b.curFirst || ""),
    );
    return list;
  }, [plans, onlyChanged, rangeFrom, rangeTo, rangeField, linePresets]);

  const grouped = useMemo(() => {
    const g: Record<string, Row[]> = {};
    for (const r of rows) (g[r.line] ??= []).push(r);
    return g;
  }, [rows]);

  function exportExcel() {
    const aoa: (string | number)[][] = [
      [
        "Line",
        "Buyer",
        "Style",
        "Prev 1st Out",
        "Curr 1st Out",
        "1st Shift (d)",
        "Prev Last Out",
        "Curr Last Out",
        "Last Shift (d)",
      ],
    ];
    for (const line of Object.keys(grouped)) {
      for (const r of grouped[line]) {
        aoa.push([
          r.line,
          r.buyer,
          r.style,
          r.prevFirst ? formatDate(r.prevFirst) : "",
          r.curFirst ? formatDate(r.curFirst) : "",
          r.firstShift,
          r.prevLast ? formatDate(r.prevLast) : "",
          r.curLast ? formatDate(r.curLast) : "",
          r.lastShift,
        ]);
      }
    }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [10, 14, 16, 12, 12, 10, 12, 12, 10].map((wch) => ({ wch }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Shift Tracker");
    XLSX.writeFile(wb, `ShiftTracker_${new Date().toISOString().slice(0, 10)}.xlsx`);
  }

  async function saveInlineEdit(row: Row, newFirstOut: string, keyToSave?: string) {
    if (!newFirstOut) return;
    const plan = plans.find((p) => p.id === row.planId);
    if (!plan) {
      toast.error("প্ল্যান খুঁজে পাওয়া যায়নি।");
      return;
    }
    const idx = plan.config.lines.findIndex((l) => l.name === row.rawLine);
    if (idx < 0) {
      toast.error("লাইন খুঁজে পাওয়া যায়নি।");
      return;
    }
    setSavingKey(keyToSave || `${row.planId}::${row.rawLine}`);
    try {
      const merged = Array.from(
        new Set([...(globalHolidays ?? []), ...(plan.config.customHolidays ?? [])]),
      );
      const newStart = nextWorkingDay(
        new Date(new Date(newFirstOut).getTime() - 86400000).toISOString().slice(0, 10),
        merged,
      );
      const newLines = plan.config.lines.map((l, i) =>
        i === idx ? { ...l, startDateStr: newStart } : l,
      );
      const recomputed = calculatePlan({
        buyer: plan.buyer,
        style: plan.style,
        orderQty: plan.order_qty,
        excessPct: Number(plan.excess_pct),
        dailyTargetPerLine: plan.daily_target,
        shipmentDate: plan.shipment_date,
        lines: newLines,
        customHolidays: merged,
        targetAdjustments: plan.config.targetAdjustments ?? [],
        targetAdjustmentsEnabled: !!plan.config.targetAdjustmentsEnabled,
      });
      const snap = buildPlanSnapshot(plan.calc_result);
      const { error } = await supabase
        .from("plans")
        .update({
          config: { ...plan.config, lines: newLines },
          // biome-ignore lint/suspicious/noExplicitAny: jsonb
          calc_result: recomputed as any,
          // biome-ignore lint/suspicious/noExplicitAny: jsonb
          previous_snapshot: snap as any,
          // biome-ignore lint/suspicious/noExplicitAny: partial update
        } as any)
        .eq("id", row.planId);
      if (error) throw error;
      toast.success("1st output ডেট আপডেট হয়েছে।");
      setEditingKey(null);
      qc.invalidateQueries({ queryKey: ["plans"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "সেভ করা যায়নি।");
    } finally {
      setSavingKey(null);
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  const pushed = rows.filter((r) => r.lastShift > 0).length;
  const advanced = rows.filter((r) => r.lastShift < 0).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3 items-end p-4 rounded-xl border border-border bg-panel">
        <div>
          <label className="block text-[11px] text-muted-foreground mb-1">Range field</label>
          <select
            value={rangeField}
            onChange={(e) => setRangeField(e.target.value as "curFirst" | "prevFirst")}
            className="rounded-lg border border-border bg-input px-3 py-1.5 text-sm"
          >
            <option value="curFirst">Current 1st Output</option>
            <option value="prevFirst">Previous 1st Output</option>
          </select>
        </div>
        <div>
          <label className="block text-[11px] text-muted-foreground mb-1">From</label>
          <input
            type="date"
            value={rangeFrom}
            onChange={(e) => setRangeFrom(e.target.value)}
            className="rounded-lg border border-border bg-input px-3 py-1.5 text-sm"
          />
        </div>
        <div>
          <label className="block text-[11px] text-muted-foreground mb-1">To</label>
          <input
            type="date"
            value={rangeTo}
            onChange={(e) => setRangeTo(e.target.value)}
            className="rounded-lg border border-border bg-input px-3 py-1.5 text-sm"
          />
        </div>
        <label className="inline-flex items-center gap-2 text-sm text-foreground">
          <input
            type="checkbox"
            checked={onlyChanged}
            onChange={(e) => setOnlyChanged(e.target.checked)}
          />
          শুধু shift ≠ 0 দেখাও
        </label>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            🔴 পিছিয়েছে: <b className="text-red-400">{pushed}</b> &nbsp; 🟢 এগিয়েছে:{" "}
            <b className="text-emerald-400">{advanced}</b>
          </span>
          <button
            onClick={exportExcel}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 text-white px-3 py-1.5 text-xs font-bold hover:bg-emerald-500"
          >
            <FileDown className="w-3.5 h-3.5" /> Export Excel
          </button>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">
          কোন push/advance shift নেই — প্ল্যান এডিট বা cascade reflow হলে এখানে দেখাবে।
        </div>
      ) : (
        <div className="rounded-xl border border-border bg-panel overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-panel-2 sticky top-0">
              <tr className="text-left">
                <th className="px-3 py-2 font-bold">Line</th>
                <th className="px-3 py-2 font-bold">Buyer</th>
                <th className="px-3 py-2 font-bold">Style</th>
                <th className="px-3 py-2 font-bold">Prev 1st Out</th>
                <th className="px-3 py-2 font-bold">Curr 1st Out</th>
                <th className="px-3 py-2 font-bold">1st Shift</th>
                <th className="px-3 py-2 font-bold">Prev Last Out</th>
                <th className="px-3 py-2 font-bold">Curr Last Out</th>
                <th className="px-3 py-2 font-bold">Last Shift</th>
                <th className="px-3 py-2 font-bold">Replan</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(grouped).map((line) => (
                <Fragment key={line}>
                  <tr className="bg-panel-2/60">
                    <td colSpan={10} className="px-3 py-1.5 text-xs font-bold text-primary">
                      📍 {line.startsWith("Line - ") ? line.replace("Line - ", "") : line}
                    </td>
                  </tr>
                  {grouped[line].map((r, rIdx) => {
                    const key = `${r.planId}::${r.rawLine}::${r.curFirst || "none"}::${rIdx}`;
                    const editing = editingKey === key;
                    return (
                      <tr key={key} className="border-t border-border hover:bg-panel-2/40">
                        <td className="px-3 py-2 font-mono text-xs">{r.line}</td>
                        <td className="px-3 py-2">{r.buyer}</td>
                        <td className="px-3 py-2">{r.style}</td>
                        <td className="px-3 py-2 font-mono text-xs text-muted-foreground">
                          {r.prevFirst ? formatDate(r.prevFirst) : "—"}
                        </td>
                        <td className="px-3 py-2 font-mono text-xs">
                          {editing ? (
                            <input
                              type="date"
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              className="rounded border border-border bg-input px-2 py-1 text-xs"
                            />
                          ) : (
                            formatDate(r.curFirst)
                          )}
                        </td>
                        <td className="px-3 py-2">
                          <ShiftBadge d={r.firstShift} />
                        </td>
                        <td className="px-3 py-2 font-mono text-xs text-muted-foreground">
                          {r.prevLast ? formatDate(r.prevLast) : "—"}
                        </td>
                        <td className="px-3 py-2 font-mono text-xs">
                          {r.curLast ? formatDate(r.curLast) : "—"}
                        </td>
                        <td className="px-3 py-2">
                          <ShiftBadge d={r.lastShift} />
                        </td>
                        <td className="px-3 py-2">
                          {editing ? (
                            <div className="flex gap-1">
                              <button
                                disabled={savingKey === key}
                                onClick={() => saveInlineEdit(r, editValue, key)}
                                className="inline-flex items-center gap-1 rounded bg-emerald-600 text-white px-2 py-1 text-xs font-bold hover:bg-emerald-500 disabled:opacity-50"
                              >
                                {savingKey === key ? (
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                ) : (
                                  <SaveIcon className="w-3 h-3" />
                                )}{" "}
                                Save
                              </button>
                              <button
                                onClick={() => setEditingKey(null)}
                                className="rounded border border-border px-2 py-1 text-xs"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setEditingKey(key);
                                setEditValue(r.curFirst || "");
                              }}
                              className="rounded border border-border px-2 py-1 text-xs hover:bg-panel-2"
                            >
                              Replan
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ShiftBadge({ d }: { d: number }) {
  if (d === 0) {
    return (
      <span className="inline-flex items-center gap-1 text-muted-foreground text-xs">
        <Minus className="w-3 h-3" /> 0
      </span>
    );
  }
  if (d > 0) {
    return (
      <span className="inline-flex items-center gap-1 rounded bg-red-500/15 text-red-400 px-2 py-0.5 text-xs font-bold">
        <ArrowDownRight className="w-3 h-3" /> +{d}d
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded bg-emerald-500/15 text-emerald-400 px-2 py-0.5 text-xs font-bold">
      <ArrowUpRight className="w-3 h-3" /> {d}d
    </span>
  );
}
