import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentUser } from "@/hooks/use-current-user";
import { toast } from "sonner";
import { Loader2, RotateCcw, Trash2, Search, PackageCheck } from "lucide-react";
import { formatDate, type PlanResult } from "@/lib/plan-calc";

type CompletedPlan = {
  id: string;
  buyer: string;
  style: string;
  order_qty: number;
  shipment_date: string;
  completed_at: string;
  created_by: string;
  calc_result: PlanResult;
};

export function CompleteOrderView() {
  const { data: user } = useCurrentUser();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "completed"],
    queryFn: async (): Promise<CompletedPlan[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, order_qty, shipment_date, completed_at, created_by, calc_result")
        .not("completed_at", "is", null)
        .order("completed_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as CompletedPlan[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-complete-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const restore = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("plans")
        .update({ completed_at: null } as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("Restore হয়েছে — এখন Plan Input / Matrix থেকে update করা যাবে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("plans").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("প্ল্যান স্থায়ীভাবে ডিলিট হয়েছে।");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return plans;
    return plans.filter(
      (p) => p.buyer?.toLowerCase().includes(s) || p.style?.toLowerCase().includes(s),
    );
  }, [plans, search]);

  const isAdmin = user?.role === "admin";

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[200px]">
          <h2 className="text-base md:text-lg font-bold text-emerald-400 flex items-center gap-2">
            <PackageCheck className="w-5 h-5" /> Complete Order
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            Shipment হয়ে যাওয়া / সম্পন্ন অর্ডারগুলো এখানে জমা আছে। Restore করলে আবার সব ট্যাবে
            দেখাবে।
          </p>
        </div>
        <div className="relative">
          <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buyer / Style search…"
            className="rounded-lg border border-border bg-input pl-8 pr-3 py-1.5 text-sm w-56"
          />
        </div>
        <div className="text-xs text-muted-foreground">
          মোট: <b className="text-emerald-400">{filtered.length}</b>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="p-12 text-center">
          <p className="text-sm text-muted-foreground">এখনও কোনো Complete Order নেই।</p>
          <p className="text-xs text-muted-foreground mt-1">
            Matrix View তে যেকোনো style-এর পাশের ✅ Complete বাটনে ক্লিক করলে এখানে চলে আসবে।
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
              <tr>
                <th className="p-3 border-r border-border">Buyer</th>
                <th className="p-3 border-r border-border">Style</th>
                <th className="p-3 border-r border-border text-right">Order Qty</th>
                <th className="p-3 border-r border-border text-right">Planned</th>
                <th className="p-3 border-r border-border">Shipment</th>
                <th className="p-3 border-r border-border">Finish</th>
                <th className="p-3 border-r border-border">Completed</th>
                {isAdmin && <th className="p-3 text-center">অ্যাকশন</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-panel-2/40 transition">
                  <td className="p-3 border-r border-border font-bold text-foreground">
                    {p.buyer}
                  </td>
                  <td className="p-3 border-r border-border text-blue-400">{p.style}</td>
                  <td className="p-3 border-r border-border text-right">
                    {(p.order_qty ?? 0).toLocaleString()}
                  </td>
                  <td className="p-3 border-r border-border text-right text-emerald-400 font-bold">
                    {(p.calc_result?.totalPlannedQty ?? 0).toLocaleString()}
                  </td>
                  <td className="p-3 border-r border-border font-mono text-xs">
                    {p.shipment_date ? formatDate(p.shipment_date) : "—"}
                  </td>
                  <td className="p-3 border-r border-border font-mono text-xs">
                    {p.calc_result?.finishDate ? formatDate(p.calc_result.finishDate) : "—"}
                  </td>
                  <td className="p-3 border-r border-border font-mono text-xs text-muted-foreground">
                    {p.completed_at ? new Date(p.completed_at).toLocaleDateString() : "—"}
                  </td>
                  {isAdmin && (
                    <td className="p-3 text-center">
                      <div className="flex justify-center gap-1.5">
                        <button
                          onClick={() => {
                            if (
                              confirm(
                                `Restore করবেন?\n${p.buyer} — ${p.style}\n\nRestore করলে আবার Plan Input / Matrix সহ সব ট্যাবে দেখাবে এবং update করা যাবে।`,
                              )
                            )
                              restore.mutate(p.id);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded bg-amber-600/20 border border-amber-500/30 text-amber-300 hover:bg-amber-600 hover:text-white transition text-xs font-bold"
                          title="Restore — আবার active করুন"
                        >
                          <RotateCcw className="w-3.5 h-3.5" /> Restore
                        </button>
                        <button
                          onClick={() => {
                            if (confirm("স্থায়ীভাবে ডিলিট করবেন? এটি undo করা যাবে না।"))
                              del.mutate(p.id);
                          }}
                          className="p-1.5 rounded bg-red-600/20 border border-red-500/30 text-red-400 hover:bg-red-600 hover:text-white transition"
                          title="স্থায়ী ডিলিট"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
