import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import type { PlanResult } from "@/lib/plan-calc";
import { getLocalDateStr, formatDate } from "@/lib/plan-calc";
import { useGlobalHolidays } from "./HolidayCalendar";
import { FilterSelect } from "./LineSummaryView";
import { useLinePresets } from "@/hooks/use-line-presets";
import {
  buildLinePresetLookup,
  canonicalLineName,
  normLine,
  sortLineNamesByPreset,
} from "./lineLookup";

type Row = {
  id: string;
  buyer: string;
  style: string;
  calc_result: PlanResult;
};

type FreeRange = { from: string; to: string; days: number };
type LineFree = {
  line: string;
  months: Record<string, FreeRange[]>;
  totalFree: number;
  nextOpen: string | null;
  lastPlanned: string | null;
};

function monthKey(y: number, m: number) {
  return new Date(y, m, 1).toLocaleString("en-US", { month: "short", year: "numeric" });
}

function computeFreeSlots(plans: Row[], holidays: string[], linePresets: string[]) {
  const holidaySet = new Set(holidays);
  const presetLookup = buildLinePresetLookup(linePresets);

  const byLine: Record<string, Set<string>> = {};
  const displayName: Record<string, string> = {};
  plans.forEach((p) => {
    (p.calc_result?.lines ?? []).forEach((ln) => {
      if (!ln?.name) return;
      const key = normLine(ln.name);
      if (!key) return;
      if (!displayName[key]) displayName[key] = canonicalLineName(ln.name, presetLookup);
      const set = (byLine[key] ??= new Set());
      (ln.dailyProduction ?? []).forEach((dp) => set.add(dp.date));
    });
  });

  const allDates: string[] = [];
  Object.values(byLine).forEach((s) => s.forEach((d) => allDates.push(d)));
  if (allDates.length === 0) return { lines: [] as LineFree[], months: [] as string[] };

  allDates.sort();
  const first = new Date(allDates[0]);
  const last = new Date(allDates[allDates.length - 1]);
  // Extend 2 months beyond the last planned date so users can plan future styles.
  const scanEnd = new Date(last.getFullYear(), last.getMonth() + 3, 0);

  const monthList: { key: string; y: number; m: number }[] = [];
  const cur = new Date(first.getFullYear(), first.getMonth(), 1);
  const end = new Date(scanEnd.getFullYear(), scanEnd.getMonth(), 1);
  while (cur <= end) {
    monthList.push({
      key: monthKey(cur.getFullYear(), cur.getMonth()),
      y: cur.getFullYear(),
      m: cur.getMonth(),
    });
    cur.setMonth(cur.getMonth() + 1);
  }

  const lines: LineFree[] = [];
  Object.entries(byLine).forEach(([lineKey, plannedSet]) => {
    const months: Record<string, FreeRange[]> = {};
    monthList.forEach((mo) => (months[mo.key] = []));
    let totalFree = 0;

    monthList.forEach((mo) => {
      const lastDay = new Date(mo.y, mo.m + 1, 0).getDate();
      let runStart: string | null = null;
      let runEnd: string | null = null;
      let runDays = 0;

      const flush = () => {
        if (runStart && runEnd) {
          months[mo.key].push({ from: runStart, to: runEnd, days: runDays });
          totalFree += runDays;
        }
        runStart = null;
        runEnd = null;
        runDays = 0;
      };

      for (let d = 1; d <= lastDay; d++) {
        const dt = new Date(mo.y, mo.m, d);
        const ds = getLocalDateStr(dt);
        const isWorking = dt.getDay() !== 5 && !holidaySet.has(ds);
        if (!isWorking) {
          // skip Fridays / holidays without breaking the free run
          continue;
        }
        if (!plannedSet.has(ds)) {
          if (!runStart) runStart = ds;
          runEnd = ds;
          runDays++;
        } else {
          flush();
        }
      }
      flush();
    });

    const sortedPlanned = Array.from(plannedSet).sort();
    const lastPlanned = sortedPlanned.length ? sortedPlanned[sortedPlanned.length - 1] : null;
    let nextOpen: string | null = null;
    if (lastPlanned) {
      const dt = new Date(lastPlanned);
      dt.setDate(dt.getDate() + 1);
      while (dt.getDay() === 5 || holidaySet.has(getLocalDateStr(dt))) {
        dt.setDate(dt.getDate() + 1);
      }
      nextOpen = getLocalDateStr(dt);
    }

    lines.push({ line: displayName[lineKey] ?? lineKey, months, totalFree, nextOpen, lastPlanned });
  });

  const sortedNames = sortLineNamesByPreset(
    lines.map((l) => l.line),
    linePresets,
  );
  const sortOrder = new Map(sortedNames.map((line, index) => [line, index]));
  lines.sort((a, b) => (sortOrder.get(a.line) ?? 0) - (sortOrder.get(b.line) ?? 0));

  return { lines, months: monthList.map((m) => m.key) };
}

export function FreeSlotsView() {
  const qc = useQueryClient();
  const { data: holidays = [] } = useGlobalHolidays();
  const { presets: linePresets } = useLinePresets();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "free-slots"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-free-slots-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const { lines: allLines, months } = useMemo(
    () => computeFreeSlots(plans, holidays, linePresets),
    [plans, holidays, linePresets],
  );

  const [lineFilter, setLineFilter] = useState<string[]>([]);
  const lineOptions = useMemo(
    () =>
      sortLineNamesByPreset(
        allLines.map((l) => l.line),
        linePresets,
      ),
    [allLines, linePresets],
  );
  const lines = useMemo(
    () =>
      lineFilter.length === 0 ? allLines : allLines.filter((l) => lineFilter.includes(l.line)),
    [allLines, lineFilter],
  );

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (allLines.length === 0) {
    return (
      <div className="p-12 text-center">
        <p className="text-sm text-muted-foreground">কোনো ফ্রি স্লট নেই।</p>
        <p className="text-xs text-muted-foreground mt-1">
          প্ল্যান সেভ হলে এখানে খালি ডেট রেঞ্জ দেখা যাবে।
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40">
        <h2 className="text-base md:text-lg font-bold text-sky-400">
          🗓️ Free Slots (ফ্রি ডেট রেঞ্জ)
        </h2>
        <p className="text-xs text-muted-foreground mt-1">
          প্রতিটি লাইনে যে date-range গুলোতে কোনো প্ল্যান নেই — এখান থেকে নতুন স্টাইল প্ল্যান করতে
          পারবেন। শুক্রবার ও কাস্টম ছুটি বাদ।
        </p>
      </div>
      <div className="p-3 md:p-4 border-b border-border bg-panel/40 flex flex-wrap items-center gap-2">
        <FilterSelect
          label="Line"
          value={lineFilter}
          onChange={setLineFilter}
          options={lineOptions}
        />
        {lineFilter.length > 0 && (
          <button
            onClick={() => setLineFilter([])}
            className="text-xs font-bold text-red-300 hover:text-red-200 underline"
          >
            Clear
          </button>
        )}
        <span className="text-[11px] text-muted-foreground ml-auto">
          {lines.length} / {allLines.length} lines
        </span>
      </div>
      <div className="overflow-auto max-h-[75vh]">
        <table className="w-full text-left border-collapse text-sm">
          <thead className="text-muted-foreground text-xs uppercase tracking-wider sticky top-0 z-20">
            <tr>
              <th className="p-4 border-r border-border bg-panel-2 sticky left-0 top-0 z-30 w-40">
                লাইন
              </th>
              <th className="p-3 text-center border-r border-border bg-panel-2 min-w-[140px] text-emerald-300">
                Next Open
              </th>
              {months.map((m) => (
                <th
                  key={m}
                  className="p-3 text-center border-r border-border/60 bg-panel-2 min-w-[180px]"
                >
                  {m}
                </th>
              ))}
              <th className="p-3 text-center bg-panel-2 text-sky-400">টোটাল ফ্রি</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {lines.map((l) => (
              <tr key={l.line} className="hover:bg-panel-2/40 transition align-top">
                <td className="p-4 border-r border-border bg-panel font-bold sticky left-0 z-10">
                  <div className="text-foreground">
                    {l.line.startsWith("Line - ") ? l.line.replace("Line - ", "") : l.line}
                  </div>
                </td>
                <td className="p-3 text-center border-r border-border/60 bg-panel-2/20">
                  {l.nextOpen ? (
                    <div className="inline-flex flex-col items-center">
                      <span className="px-2 py-0.5 rounded border bg-emerald-950/60 border-emerald-700/60 text-emerald-200 text-[11px] font-bold">
                        {formatDate(l.nextOpen)}
                      </span>
                      {l.lastPlanned && (
                        <span className="text-[10px] text-muted-foreground mt-1">
                          last: {formatDate(l.lastPlanned)}
                        </span>
                      )}
                    </div>
                  ) : (
                    <span className="text-[11px] text-muted-foreground/60 italic">—</span>
                  )}
                </td>

                {months.map((m) => {
                  const ranges = l.months[m] ?? [];
                  return (
                    <td key={m} className="p-2 border-r border-border/60 bg-panel-2/20 align-top">
                      {ranges.length === 0 ? (
                        <span className="text-[11px] text-muted-foreground/60 italic">—</span>
                      ) : (
                        <div className="space-y-1">
                          {ranges.map((r, i) => (
                            <div
                              key={i}
                              className="px-2 py-1 rounded border bg-sky-950/50 border-sky-700/60 text-sky-200 text-[11px] font-semibold leading-tight"
                              title={`${r.from} → ${r.to}`}
                            >
                              {r.from === r.to ? (
                                <>{formatDate(r.from)}</>
                              ) : (
                                <>
                                  {formatDate(r.from)} → {formatDate(r.to)}
                                </>
                              )}
                              <span className="ml-1 text-[10px] text-sky-300/80 font-normal">
                                ({r.days}d)
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </td>
                  );
                })}
                <td className="p-3 text-center bg-panel/60">
                  <span className="inline-block px-2 py-0.5 bg-sky-950/60 border border-sky-700/60 rounded text-[11px] text-sky-300 font-bold">
                    🗓️ {l.totalFree}d
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
