import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, FileDown, TrendingUp, TrendingDown, Minus } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { formatDate, getLocalDateStr, type PlanResult } from "@/lib/plan-calc";
import { FilterSelect } from "./LineSummaryView";
import { useLinePresets } from "@/hooks/use-line-presets";
import { buildLinePresetLookup, canonicalLineName, uniqueCanonicalLineNames } from "./lineLookup";

type PlanRow = {
  id: string;
  buyer: string;
  style: string;
  shipment_date: string;
  calc_result: PlanResult;
};

type UpdateRow = {
  plan_id: string;
  line_name: string;
  update_date: string;
  actual_qty: number;
};

type ResultRow = {
  planId: string;
  line: string;
  buyer: string;
  style: string;
  plannedQty: number;
  actualQty: number;
  remainingQty: number;
  plannedFinish: string;
  projectedFinish: string;
  shipDate: string;
  varianceDays: number; // + = early, - = late
  actualDailyAvg: number;
  plannedDailyAvg: number;
  status: "complete" | "early" | "ontime" | "late";
};

function todayStr() {
  return getLocalDateStr(new Date());
}

function addWorkingDays(startStr: string, days: number, holidays: Set<string>): string {
  const d = new Date(startStr);
  let added = 0;
  while (added < days) {
    d.setDate(d.getDate() + 1);
    const s = getLocalDateStr(d);
    if (d.getDay() === 5 || holidays.has(s)) continue;
    added++;
  }
  return getLocalDateStr(d);
}

function diffCalendarDays(a: string, b: string): number {
  const da = new Date(a).getTime();
  const db = new Date(b).getTime();
  return Math.round((db - da) / (1000 * 60 * 60 * 24));
}

function buildRows(
  plans: PlanRow[],
  updates: UpdateRow[],
  from: string,
  to: string,
  linePresets: string[],
  today: string,
): ResultRow[] {
  const out: ResultRow[] = [];
  const presetLookup = buildLinePresetLookup(linePresets);
  const updByPlanLine = new Map<string, UpdateRow[]>();
  for (const u of updates) {
    const k = `${u.plan_id}::${u.line_name}`;
    if (!updByPlanLine.has(k)) updByPlanLine.set(k, []);
    updByPlanLine.get(k)!.push(u);
  }

  for (const p of plans) {
    const lines = p.calc_result?.lines ?? [];
    const holidays = new Set(p.calc_result?.customHolidays ?? []);
    for (const l of lines) {
      if (!l?.name || (l.plannedQty ?? 0) <= 0) continue;
      const daily = l.dailyProduction ?? [];
      if (daily.length === 0) continue;

      const key = `${p.id}::${l.name}`;
      const ups = (updByPlanLine.get(key) ?? []).filter(
        (u) => u.update_date >= from && u.update_date <= to,
      );
      const actualQty = ups.reduce((s, u) => s + (u.actual_qty || 0), 0);
      const producedDays = new Set(
        ups.filter((u) => (u.actual_qty || 0) > 0).map((u) => u.update_date),
      ).size;

      const plannedQty = l.plannedQty;
      const remainingQty = Math.max(0, plannedQty - actualQty);
      const plannedFinish = l.finishDateStr || daily[daily.length - 1].date;
      const plannedDailyAvg = l.workingDays > 0 ? plannedQty / l.workingDays : 0;
      const actualDailyAvg = producedDays > 0 ? actualQty / producedDays : 0;

      let projectedFinish = plannedFinish;
      let status: ResultRow["status"] = "ontime";

      if (actualQty >= plannedQty) {
        // complete — projected finish is the last date they produced (or "to")
        const lastProd = ups
          .filter((u) => (u.actual_qty || 0) > 0)
          .map((u) => u.update_date)
          .sort()
          .pop();
        projectedFinish = lastProd || to;
        status = "complete";
      } else {
        // projected finish = today + (remaining qty / target per day of that line), skipping holidays & Fridays
        const targetPerDay = plannedDailyAvg;
        if (targetPerDay > 0) {
          const daysNeeded = Math.ceil(remainingQty / targetPerDay);
          projectedFinish =
            today < daily[0].date ? plannedFinish : addWorkingDays(today, daysNeeded, holidays);
        }
      }

      const varianceDays = diffCalendarDays(projectedFinish, plannedFinish);
      if (status !== "complete") {
        if (varianceDays > 0) status = "early";
        else if (varianceDays < 0) status = "late";
        else status = "ontime";
      }

      out.push({
        planId: p.id,
        line: canonicalLineName(l.name, presetLookup),
        buyer: p.buyer,
        style: p.style,
        plannedQty,
        actualQty,
        remainingQty,
        plannedFinish,
        projectedFinish,
        shipDate: p.shipment_date,
        varianceDays,
        actualDailyAvg,
        plannedDailyAvg,
        status,
      });
    }
  }

  out.sort((a, b) => {
    // late first, then by variance ascending (most late on top)
    if (a.status === "late" && b.status !== "late") return -1;
    if (b.status === "late" && a.status !== "late") return 1;
    if (a.varianceDays !== b.varianceDays) return a.varianceDays - b.varianceDays;
    return a.line.localeCompare(b.line, undefined, { numeric: true });
  });

  return out;
}

export function EarlyDelayView() {
  const { presets: linePresets } = useLinePresets();
  const today = todayStr();
  const [fromDate, setFromDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return getLocalDateStr(d);
  });
  const [toDate, setToDate] = useState<string>(today);
  const [lineFilter, setLineFilter] = useState<string[]>([]);
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [styleFilter, setStyleFilter] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string[]>([]);

  const { data: plans = [], isLoading: plansLoading } = useQuery({
    queryKey: ["plans", "early-delay"],
    queryFn: async (): Promise<PlanRow[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, shipment_date, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PlanRow[];
    },
  });

  const { data: updates = [], isLoading: updLoading } = useQuery({
    queryKey: ["production_updates", "early-delay", fromDate, toDate],
    queryFn: async (): Promise<UpdateRow[]> => {
      const { data, error } = await supabase
        .from("production_updates")
        .select("plan_id, line_name, update_date, actual_qty")
        .gte("update_date", fromDate)
        .lte("update_date", toDate);
      if (error) throw error;
      return (data ?? []) as UpdateRow[];
    },
  });

  const allRows = useMemo(
    () => buildRows(plans, updates, fromDate, toDate, linePresets, today),
    [plans, updates, fromDate, toDate, linePresets, today],
  );

  const lineOptions = useMemo(
    () =>
      uniqueCanonicalLineNames(
        allRows.map((r) => r.line),
        linePresets,
      ),
    [allRows, linePresets],
  );
  const buyerOptions = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.buyer))).sort(),
    [allRows],
  );
  const styleOptions = useMemo(
    () => Array.from(new Set(allRows.map((r) => r.style))).sort(),
    [allRows],
  );
  const statusOptions = ["complete", "early", "ontime", "late"];

  const rows = useMemo(() => {
    return allRows.filter((r) => {
      if (lineFilter.length && !lineFilter.includes(r.line)) return false;
      if (buyerFilter.length && !buyerFilter.includes(r.buyer)) return false;
      if (styleFilter.length && !styleFilter.includes(r.style)) return false;
      if (statusFilter.length && !statusFilter.includes(r.status)) return false;
      return true;
    });
  }, [allRows, lineFilter, buyerFilter, styleFilter, statusFilter]);

  const summary = useMemo(() => {
    const s = { complete: 0, early: 0, ontime: 0, late: 0, totalLateDays: 0, totalEarlyDays: 0 };
    for (const r of rows) {
      s[r.status] += 1;
      if (r.status === "late") s.totalLateDays += -r.varianceDays;
      if (r.status === "early") s.totalEarlyDays += r.varianceDays;
    }
    return s;
  }, [rows]);

  const loading = plansLoading || updLoading;

  function exportExcel() {
    if (rows.length === 0) {
      toast.error("Export করার মতো ডেটা নেই");
      return;
    }
    const aoa: (string | number)[][] = [
      [`Early/Delay Report — ${fromDate} to ${toDate}`],
      [],
      [
        "Line",
        "Buyer",
        "Style",
        "Plan Qty",
        "Actual",
        "Remaining",
        "Planned Finish",
        "Projected Finish",
        "Ship Date",
        "Variance (days)",
        "Status",
        "Actual Daily Avg",
        "Planned Daily Avg",
      ],
    ];
    for (const r of rows) {
      aoa.push([
        r.line,
        r.buyer,
        r.style,
        r.plannedQty,
        r.actualQty,
        r.remainingQty,
        formatDate(r.plannedFinish),
        formatDate(r.projectedFinish),
        formatDate(r.shipDate),
        r.varianceDays,
        r.status,
        Math.round(r.actualDailyAvg),
        Math.round(r.plannedDailyAvg),
      ]);
    }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [
      { wch: 10 },
      { wch: 16 },
      { wch: 16 },
      { wch: 10 },
      { wch: 10 },
      { wch: 10 },
      { wch: 14 },
      { wch: 16 },
      { wch: 12 },
      { wch: 14 },
      { wch: 10 },
      { wch: 14 },
      { wch: 14 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Early-Delay");
    XLSX.writeFile(wb, `EarlyDelay_${fromDate}_to_${toDate}.xlsx`);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">From</label>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="rounded-md border border-border bg-input px-2 py-1.5 text-xs text-foreground"
          />
        </div>
        <div>
          <label className="block text-[11px] font-bold text-muted-foreground mb-1">To</label>
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="rounded-md border border-border bg-input px-2 py-1.5 text-xs text-foreground"
          />
        </div>
        <FilterSelect
          label="Line"
          value={lineFilter}
          onChange={setLineFilter}
          options={lineOptions}
        />
        <FilterSelect
          label="Buyer"
          value={buyerFilter}
          onChange={setBuyerFilter}
          options={buyerOptions}
        />
        <FilterSelect
          label="Style"
          value={styleFilter}
          onChange={setStyleFilter}
          options={styleOptions}
        />
        <FilterSelect
          label="Status"
          value={statusFilter}
          onChange={setStatusFilter}
          options={statusOptions}
        />
        <button
          onClick={exportExcel}
          className="inline-flex items-center gap-1.5 rounded-md border border-border bg-input hover:bg-panel-2 px-3 py-1.5 text-xs font-bold text-foreground"
        >
          <FileDown className="w-3.5 h-3.5" /> Export Excel
        </button>
      </div>

      <div className="flex flex-wrap gap-2 text-[11px]">
        <span className="rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-emerald-300 font-bold">
          ✓ Complete: {summary.complete}
        </span>
        <span className="rounded-md border border-sky-500/40 bg-sky-500/10 px-2 py-1 text-sky-300 font-bold">
          ↑ Early: {summary.early} ({summary.totalEarlyDays}d)
        </span>
        <span className="rounded-md border border-slate-500/40 bg-slate-500/10 px-2 py-1 text-slate-300 font-bold">
          = On-time: {summary.ontime}
        </span>
        <span className="rounded-md border border-red-500/40 bg-red-500/10 px-2 py-1 text-red-300 font-bold">
          ↓ Late: {summary.late} ({summary.totalLateDays}d)
        </span>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      ) : rows.length === 0 ? (
        <div className="text-center py-16 text-sm text-muted-foreground">
          কোনো ডেটা নেই। তারিখ পরিসীমা বা ফিল্টার পরিবর্তন করে দেখুন।
        </div>
      ) : (
        <div className="overflow-auto rounded-lg border border-border bg-panel">
          <table className="w-full text-xs">
            <thead className="bg-panel-2 sticky top-0 z-10">
              <tr className="text-left">
                <th className="px-3 py-2 font-bold">Line</th>
                <th className="px-3 py-2 font-bold">Buyer</th>
                <th className="px-3 py-2 font-bold">Style</th>
                <th className="px-3 py-2 font-bold text-right">Plan Qty</th>
                <th className="px-3 py-2 font-bold text-right">Actual</th>
                <th className="px-3 py-2 font-bold text-right">Remain</th>
                <th className="px-3 py-2 font-bold">Planned Finish</th>
                <th className="px-3 py-2 font-bold">Projected Finish</th>
                <th className="px-3 py-2 font-bold">Ship Date</th>
                <th className="px-3 py-2 font-bold text-right">Variance</th>
                <th className="px-3 py-2 font-bold text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const statusClr =
                  r.status === "late"
                    ? "text-red-300"
                    : r.status === "early"
                      ? "text-sky-300"
                      : r.status === "complete"
                        ? "text-emerald-300"
                        : "text-slate-300";
                const rowClr =
                  r.status === "late" ? "bg-red-500/5" : r.status === "early" ? "bg-sky-500/5" : "";
                const Icon =
                  r.status === "late" ? TrendingDown : r.status === "early" ? TrendingUp : Minus;
                return (
                  <tr
                    key={`${r.planId}-${r.line}-${i}`}
                    className={`border-t border-border ${rowClr}`}
                  >
                    <td className="px-3 py-2 font-bold">
                      {r.line.startsWith("Line - ") ? r.line.replace("Line - ", "") : r.line}
                    </td>
                    <td className="px-3 py-2">{r.buyer}</td>
                    <td className="px-3 py-2">{r.style}</td>
                    <td className="px-3 py-2 text-right">{r.plannedQty}</td>
                    <td className="px-3 py-2 text-right">{r.actualQty}</td>
                    <td className="px-3 py-2 text-right">{r.remainingQty}</td>
                    <td className="px-3 py-2">{formatDate(r.plannedFinish)}</td>
                    <td className="px-3 py-2">{formatDate(r.projectedFinish)}</td>
                    <td className="px-3 py-2">{formatDate(r.shipDate)}</td>
                    <td className={`px-3 py-2 text-right font-bold ${statusClr}`}>
                      {r.varianceDays > 0 ? `+${r.varianceDays}d` : `${r.varianceDays}d`}
                    </td>
                    <td className={`px-3 py-2 text-center font-bold uppercase ${statusClr}`}>
                      <span className="inline-flex items-center gap-1">
                        <Icon className="w-3 h-3" /> {r.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
