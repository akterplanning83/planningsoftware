import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Search, X } from "lucide-react";
import type { PlanResult } from "@/lib/plan-calc";
import { FilterSelect } from "./LineSummaryView";

type Row = {
  id: string;
  buyer: string;
  style: string;
  season: string | null;
  excess_pct: number;
  calc_result: PlanResult;
};

export function BuyerMonthlyView() {
  const qc = useQueryClient();
  const [buyerFilter, setBuyerFilter] = useState<string[]>([]);
  const [seasonFilter, setSeasonFilter] = useState<string[]>([]);
  const [search, setSearch] = useState("");

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["plans", "buyer-monthly"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase
        .from("plans")
        .select("id, buyer, style, season, excess_pct, calc_result")
        .is("completed_at", null)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("plans-buyer-monthly-watch")
      .on("postgres_changes", { event: "*", schema: "public", table: "plans" }, () =>
        qc.invalidateQueries({ queryKey: ["plans"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const buyerOptions = useMemo(
    () => Array.from(new Set(plans.map((p) => p.buyer))).sort(),
    [plans],
  );
  const seasonOptions = useMemo(
    () =>
      Array.from(
        new Set(plans.map((p) => (p.season && p.season.trim()) || "— (No Season)")),
      ).sort(),
    [plans],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return plans.filter((p) => {
      const seasonKey = (p.season && p.season.trim()) || "— (No Season)";
      return (
        (buyerFilter.length === 0 || buyerFilter.includes(p.buyer)) &&
        (seasonFilter.length === 0 || seasonFilter.includes(seasonKey)) &&
        (q === "" ||
          p.buyer.toLowerCase().includes(q) ||
          (p.season ?? "").toLowerCase().includes(q))
      );
    });
  }, [plans, buyerFilter, seasonFilter, search]);

  // Collect months
  const monthSet = new Set<string>();
  filtered.forEach((p) => {
    for (const m in p.calc_result?.monthlyBreakdown ?? {}) monthSet.add(m);
  });
  const sortedMonths = Array.from(monthSet).sort(
    (a, b) => new Date("1 " + a).getTime() - new Date("1 " + b).getTime(),
  );

  // Aggregate by buyer + season → month → orderQty (excluding excess)
  type Group = { buyer: string; season: string; months: Record<string, number>; total: number };
  const groupsMap = new Map<string, Group>();

  filtered.forEach((p) => {
    const seasonKey = (p.season && p.season.trim()) || "";
    const key = `${p.buyer}||${seasonKey}`;
    let g = groupsMap.get(key);
    if (!g) {
      g = { buyer: p.buyer, season: seasonKey, months: {}, total: 0 };
      groupsMap.set(key, g);
    }
    const divisor = 1 + (Number(p.excess_pct) || 0) / 100;
    for (const m in p.calc_result?.monthlyBreakdown ?? {}) {
      const plannedQty = p.calc_result.monthlyBreakdown[m].qty;
      const orderQty = divisor > 0 ? Math.round(plannedQty / divisor) : plannedQty;
      g.months[m] = (g.months[m] ?? 0) + orderQty;
      g.total += orderQty;
    }
  });

  const groups = Array.from(groupsMap.values()).sort((a, b) => {
    if (a.buyer !== b.buyer) return a.buyer.localeCompare(b.buyer);
    return a.season.localeCompare(b.season);
  });

  const monthTotals: Record<string, number> = {};
  sortedMonths.forEach((m) => (monthTotals[m] = 0));
  let grandTotal = 0;
  groups.forEach((g) => {
    grandTotal += g.total;
    sortedMonths.forEach((m) => {
      monthTotals[m] += g.months[m] ?? 0;
    });
  });

  const hasFilter = buyerFilter.length > 0 || seasonFilter.length > 0 || search.trim() !== "";

  if (isLoading) {
    return (
      <div className="p-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-panel/70 overflow-hidden shadow-xl">
      <div className="p-4 md:p-6 border-b border-border bg-panel-2/40 space-y-3">
        <div>
          <h2 className="text-base md:text-lg font-bold text-cyan-400">
            🧾 Buyer × Season — Month-wise Order Quantity
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            মাসভিত্তিক অর্ডার কোয়ান্টিটি (Excess% বাদ দিয়ে) — Buyer ও Season অনুযায়ী গ্রুপ্ড
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buyer / Season সার্চ..."
              className="pl-8 pr-8 py-1.5 text-xs rounded-lg bg-panel border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-cyan-500/60 w-56"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <FilterSelect
            label="Buyer"
            value={buyerFilter}
            onChange={setBuyerFilter}
            options={buyerOptions}
          />
          <FilterSelect
            label="Season"
            value={seasonFilter}
            onChange={setSeasonFilter}
            options={seasonOptions}
          />
          {hasFilter && (
            <button
              onClick={() => {
                setBuyerFilter([]);
                setSeasonFilter([]);
                setSearch("");
              }}
              className="text-xs font-bold text-red-300 hover:text-red-200 underline"
            >
              Clear
            </button>
          )}
          <span className="text-xs bg-cyan-950 text-cyan-400 border border-cyan-500/50 px-3 py-1 rounded-lg font-bold ml-auto">
            {groups.length} Groups
          </span>
        </div>
      </div>

      {groups.length === 0 ? (
        <div className="p-12 text-center text-sm text-muted-foreground">কোনো ডাটা নেই।</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead className="bg-panel-2 text-muted-foreground text-xs uppercase tracking-wider">
              <tr>
                <th className="p-4 border-r border-border bg-panel-2 sticky left-0 z-10 w-48">
                  Buyer
                </th>
                <th className="p-4 border-r border-border bg-panel-2 w-40">Season</th>
                <th className="p-4 border-r border-border text-center text-yellow-400 bg-panel-2">
                  Total Order Qty
                </th>
                {sortedMonths.map((m) => (
                  <th key={m} className="p-4 text-center border-r border-border/60 bg-panel-2/90">
                    {m}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {groups.map((g, i) => (
                <tr key={i} className="hover:bg-panel-2/40 transition">
                  <td className="p-4 border-r border-border bg-panel font-bold text-foreground sticky left-0 z-10">
                    {g.buyer}
                  </td>
                  <td className="p-4 border-r border-border bg-panel/60 text-xs">
                    {g.season ? (
                      <span className="text-amber-400 font-semibold">{g.season}</span>
                    ) : (
                      <span className="text-muted-foreground italic">— (No Season)</span>
                    )}
                  </td>
                  <td className="p-3 border-r border-border text-center bg-panel/60">
                    <span className="block font-bold text-cyan-300">
                      {g.total.toLocaleString()} Pcs
                    </span>
                  </td>
                  {sortedMonths.map((m) => {
                    const v = g.months[m] ?? 0;
                    if (!v)
                      return (
                        <td
                          key={m}
                          className="p-4 text-center border-r border-border/60 text-muted-foreground"
                        >
                          -
                        </td>
                      );
                    return (
                      <td
                        key={m}
                        className="p-3 text-center border-r border-border/60 bg-panel-2/30"
                      >
                        <span className="block text-sm font-bold text-teal-300">
                          {v.toLocaleString()}{" "}
                          <small className="text-[10px] font-normal text-muted-foreground">
                            Pcs
                          </small>
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-panel-2/95 font-bold border-t-2 border-border">
              <tr>
                <td
                  colSpan={2}
                  className="p-4 border-r border-border bg-panel-2 sticky left-0 z-10 text-right uppercase text-xs text-muted-foreground"
                >
                  Grand Total ➔
                </td>
                <td className="p-4 border-r border-border text-center bg-panel-2">
                  <span className="block text-yellow-400 font-bold text-base">
                    {grandTotal.toLocaleString()} Pcs
                  </span>
                </td>
                {sortedMonths.map((m) => (
                  <td key={m} className="p-4 text-center border-r border-border/60 bg-cyan-950/60">
                    <span className="block font-bold text-base text-cyan-400">
                      {monthTotals[m].toLocaleString()} Pcs
                    </span>
                  </td>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}
