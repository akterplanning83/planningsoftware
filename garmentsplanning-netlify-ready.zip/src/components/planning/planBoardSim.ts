import { normLine } from "./lineLookup";
import {
  calculatePlan,
  nextWorkingDay,
  type LineInput,
  type PlanResult,
  type TargetAdjustment,
} from "@/lib/plan-calc";

export type PlanRow = {
  id: string;
  buyer: string;
  style: string;
  order_qty: number;
  excess_pct: number;
  daily_target: number;
  shipment_date: string;
  config: {
    lines: LineInput[];
    customHolidays: string[];
    targetAdjustments?: TargetAdjustment[];
    targetAdjustmentsEnabled?: boolean;
    learningCurve?: number[];
    learningCurveEnabled?: boolean;
  };
  calc_result: PlanResult;
};

export function shiftDateStr(dateStr: string, deltaDays: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + deltaDays);
  return d.toISOString().slice(0, 10);
}

export function recomputePlan(p: PlanRow, globalHolidays: string[]): PlanResult {
  const merged = Array.from(
    new Set([...(globalHolidays ?? []), ...(p.config?.customHolidays ?? [])]),
  );
  return calculatePlan({
    buyer: p.buyer,
    style: p.style,
    orderQty: p.order_qty,
    excessPct: Number(p.excess_pct),
    dailyTargetPerLine: p.daily_target,
    shipmentDate: p.shipment_date,
    lines: p.config.lines,
    customHolidays: merged,
    targetAdjustments: p.config.targetAdjustments ?? [],
    targetAdjustmentsEnabled: !!p.config.targetAdjustmentsEnabled,
    learningCurve: p.config.learningCurveEnabled ? p.config.learningCurve : undefined,
  });
}

function reflowLine(plans: PlanRow[], lineName: string, globalHolidays: string[]) {
  const chain = plans
    .filter((p) => p.config.lines.some((l) => normLine(l.name) === normLine(lineName)))
    .sort((a, b) => {
      const aL = a.config.lines.find((l) => normLine(l.name) === normLine(lineName))!;
      const bL = b.config.lines.find((l) => normLine(l.name) === normLine(lineName))!;
      return aL.startDateStr.localeCompare(bL.startDateStr);
    });
  for (let i = 1; i < chain.length; i++) {
    const prev = chain[i - 1];
    const cur = chain[i];
    const prevLine = prev.calc_result?.lines?.find((l) => normLine(l.name) === normLine(lineName));
    if (!prevLine?.finishDateStr) continue;
    if ((prevLine.plannedQty ?? 0) <= 0 && (prevLine.dailyProduction?.length ?? 0) === 0) continue;
    const idx = cur.config.lines.findIndex((l) => normLine(l.name) === normLine(lineName));
    const curLine = cur.config.lines[idx];
    if (curLine.chainAuto === false) continue;
    const merged = Array.from(
      new Set([...(globalHolidays ?? []), ...(cur.config.customHolidays ?? [])]),
    );
    const desired = nextWorkingDay(prevLine.finishDateStr, merged);
    if (desired <= curLine.startDateStr) continue;
    cur.config.lines[idx] = { ...curLine, startDateStr: desired };
    cur.calc_result = recomputePlan(cur, globalHolidays);
  }
}

export type LineChange = {
  planId: string;
  buyer: string;
  style: string;
  lineName: string;
  oldStart: string;
  newStart: string;
  oldFirstOutput: string;
  newFirstOutput: string;
  oldLastOutput: string;
  newLastOutput: string;
  oldLineName?: string;
  reason: "moved" | "cascade";
};

export function simulateDrop(args: {
  plans: PlanRow[];
  editPlanId: string;
  origLineName: string;
  newLineName: string;
  deltaDays: number;
  globalHolidays: string[];
}): { after: PlanRow[]; changes: LineChange[] } {
  const { plans, editPlanId, origLineName, newLineName, deltaDays, globalHolidays } = args;
  const cloned: PlanRow[] = JSON.parse(JSON.stringify(plans));
  const target = cloned.find((p) => p.id === editPlanId);
  if (!target) return { after: cloned, changes: [] };

  const idx = target.config.lines.findIndex((l) => normLine(l.name) === normLine(origLineName));
  if (idx < 0) return { after: cloned, changes: [] };
  const line = target.config.lines[idx];
  const newStart = shiftDateStr(line.startDateStr, deltaDays);
  target.config.lines[idx] = { ...line, name: newLineName, startDateStr: newStart };
  target.calc_result = recomputePlan(target, globalHolidays);

  const linesToReflow = new Set<string>([origLineName, newLineName]);
  for (const ln of linesToReflow) reflowLine(cloned, ln, globalHolidays);

  const changes: LineChange[] = [];
  const origById = new Map(plans.map((p) => [p.id, p]));
  for (const p of cloned) {
    const o = origById.get(p.id);
    if (!o) continue;
    for (const nl of p.config.lines) {
      const ol =
        p.id === editPlanId && nl.name === newLineName
          ? o.config.lines.find((l) => l.name === origLineName)
          : o.config.lines.find((l) => l.name === nl.name);
      const oCalc =
        p.id === editPlanId && nl.name === newLineName
          ? o.calc_result?.lines?.find((l) => l.name === origLineName)
          : o.calc_result?.lines?.find((l) => l.name === nl.name);
      const nCalc = p.calc_result?.lines?.find((l) => l.name === nl.name);
      if (!ol || !oCalc || !nCalc) continue;
      const startChanged = ol.startDateStr !== nl.startDateStr;
      const finishChanged = (oCalc.finishDateStr ?? "") !== (nCalc.finishDateStr ?? "");
      const lineChanged = p.id === editPlanId && origLineName !== newLineName;
      if (!startChanged && !finishChanged && !lineChanged) continue;
      changes.push({
        planId: p.id,
        buyer: p.buyer,
        style: p.style,
        lineName: nl.name,
        oldLineName: lineChanged ? origLineName : undefined,
        oldStart: ol.startDateStr,
        newStart: nl.startDateStr,
        oldFirstOutput: (oCalc.dailyProduction?.[0]?.date ?? oCalc.startDateStr) || "",
        newFirstOutput: (nCalc.dailyProduction?.[0]?.date ?? nCalc.startDateStr) || "",
        oldLastOutput: oCalc.finishDateStr ?? "",
        newLastOutput: nCalc.finishDateStr ?? "",
        reason: p.id === editPlanId ? "moved" : "cascade",
      });
    }
  }
  return { after: cloned, changes };
}
