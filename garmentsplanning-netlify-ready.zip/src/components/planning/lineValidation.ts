import { normLine } from "./lineLookup";
import type { LineInput } from "@/lib/plan-calc";

/**
 * Returns the first duplicated line name in the array, or null when all are unique.
 * Case-sensitive exact match (line names are dropdown-selected presets).
 */
export function findDuplicateLineName(lines: Pick<LineInput, "name">[]): string | null {
  const counts = new Map<string, number>();
  for (const l of lines) {
    counts.set(l.name, (counts.get(l.name) ?? 0) + 1);
  }
  for (const [name, count] of counts) {
    if (count > 1) return name;
  }
  return null;
}

/**
 * Given the names already used by other rows and the available presets,
 * returns the option list a LineCard should render for a row currently
 * showing `currentName`. The current row's own name is always included so
 * the <select> can keep its value; other rows' names are filtered out.
 */
export function buildLineOptions(
  currentName: string,
  otherTakenNames: string[],
  presets: string[],
): string[] {
  const taken = new Set(otherTakenNames);
  const base = presets.filter((p) => !taken.has(p) || p === currentName);
  return base.includes(currentName) ? base : [currentName, ...base];
}

/**
 * Picks a preset name for a newly added line row that isn't already used
 * by the existing rows. Falls back to `Line - N` if no preset is free.
 */
export function pickAvailableLineName(
  existingNames: string[],
  presets: string[],
  fallbackIndex: number,
): string {
  const used = new Set(existingNames);
  const free = presets.find((p) => !used.has(p));
  if (free) return free;
  let k = Math.max(1, fallbackIndex);
  while (used.has(`Line - ${k}`)) k++;
  return `Line - ${k}`;
}

/**
 * Same line may be used more than once in one plan (split blocks with a gap),
 * e.g. Line-15 runs 20,000 pcs, then another style, then 30,000 pcs of the
 * same style again. Only *overlapping* date blocks on the same physical line
 * are invalid.
 */
export type LineBlock = { name: string; start: string; finish: string };

export function findOverlappingLineBlocks(
  blocks: LineBlock[],
): { name: string; a: LineBlock; b: LineBlock } | null {
  const byLine = new Map<string, LineBlock[]>();
  for (const b of blocks) {
    if (!b.start || !b.finish) continue;
    const key = normLine(b.name);
    if (!key) continue;
    const arr = byLine.get(key) ?? [];
    arr.push(b);
    byLine.set(key, arr);
  }
  for (const arr of byLine.values()) {
    const sorted = [...arr].sort((x, y) => x.start.localeCompare(y.start));
    for (let i = 1; i < sorted.length; i++) {
      const prev = sorted[i - 1];
      const cur = sorted[i];
      if (cur.start <= prev.finish) return { name: cur.name, a: prev, b: cur };
    }
  }
  return null;
}
