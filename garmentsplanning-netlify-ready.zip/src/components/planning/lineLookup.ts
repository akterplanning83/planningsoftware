// Line-name lookup helpers.
// Names typed/saved over time can vary in spacing/case ("Line - R" vs
// "Line-R" vs "line r"). Normalize before comparing so a saved plan's last
// output can still be matched against the current preset name.

export function normLine(s: string): string {
  // Strip everything except alphanumerics and normalize case.
  // "Line - 15", "Line-15", "line 15", "15" all collapse to "15".
  // "Line - A", "Line-A", "line a", "a" all collapse to "a".
  const raw = (s || "").normalize("NFKC").toLowerCase();
  // If it matches "line - X" or "line X" or "line-X", extract X.
  // If no "line" prefix, just take the alphanumerics.
  const match = raw.match(/line[^\p{L}\p{N}]*([\p{L}\p{N}]+)/u);
  if (match && match[1]) return match[1];
  return raw.replace(/[^\p{L}\p{N}]+/gu, "");
}

export function buildLinePresetLookup(presets: string[]): Record<string, string> {
  const lookup: Record<string, string> = {};
  for (const preset of presets) {
    const clean = (preset || "").trim();
    const key = normLine(clean);
    if (key && !lookup[key]) lookup[key] = clean;
  }
  return lookup;
}

export function canonicalLineName(
  lineName: string,
  presetsOrLookup: string[] | Record<string, string>,
): string {
  const raw = (lineName || "").trim();
  const key = normLine(raw);
  if (!key) return raw;
  const lookup = Array.isArray(presetsOrLookup)
    ? buildLinePresetLookup(presetsOrLookup)
    : presetsOrLookup;
  return lookup[key] ?? raw;
}

export function sortLineNamesByPreset(names: string[], presets: string[]): string[] {
  const order = new Map<string, number>();
  presets.forEach((preset, index) => {
    const key = normLine(preset);
    if (key && !order.has(key)) order.set(key, index);
  });

  return [...names].sort((a, b) => {
    const ak = normLine(a);
    const bk = normLine(b);
    const ai = order.get(ak);
    const bi = order.get(bk);
    if (ai !== undefined || bi !== undefined) {
      if (ai === undefined) return 1;
      if (bi === undefined) return -1;
      if (ai !== bi) return ai - bi;
    }
    return a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" });
  });
}

export function uniqueCanonicalLineNames(rawNames: string[], presets: string[]): string[] {
  const lookup = buildLinePresetLookup(presets);
  const byKey = new Map<string, string>();
  for (const raw of rawNames) {
    const key = normLine(raw);
    if (!key || byKey.has(key)) continue;
    byKey.set(key, canonicalLineName(raw, lookup));
  }
  return sortLineNamesByPreset(Array.from(byKey.values()), presets);
}

export type PlanLikeForLookup = {
  id: string;
  calc_result?: { lines?: Array<{ name?: string; finishDateStr?: string }> } | null;
};

/**
 * Build { normalizedLineName -> latest finishDateStr } across saved plans.
 * `excludePlanId` skips the plan currently being edited so its own booking
 * doesn't block itself.
 */
export function buildLineLastOutput(
  plans: PlanLikeForLookup[],
  excludePlanId?: string | null,
): Record<string, string> {
  const map: Record<string, string> = {};
  for (const p of plans) {
    if (excludePlanId && p.id === excludePlanId) continue;
    const rlines = p.calc_result?.lines ?? [];
    for (const l of rlines) {
      if (!l?.name || !l.finishDateStr) continue;
      const key = normLine(l.name);
      if (!map[key] || l.finishDateStr > map[key]) {
        map[key] = l.finishDateStr;
      }
    }
  }
  return map;
}

export function lookupLastOutput(
  map: Record<string, string>,
  lineName: string,
): string | undefined {
  return map[normLine(lineName)];
}
