import fs from "node:fs";
import path from "node:path";

const rootDir = process.cwd();
const distDir = path.join(rootDir, "dist");
const distClientDir = path.join(distDir, "client");
const netlifyInternalDir = path.join(rootDir, ".netlify", "functions-internal");
const netlifyServerDir = path.join(netlifyInternalDir, "server");
const distServerDir = path.join(distDir, "server");

console.log("[postbuild] Running Netlify deployment asset preparation...");

// 1. Ensure dist directory exists
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

// 2. Ensure .netlify/functions-internal directory exists so Netlify doesn't fail
if (!fs.existsSync(netlifyInternalDir)) {
  fs.mkdirSync(netlifyInternalDir, { recursive: true });
}

// 3. If Nitro output server into dist/server instead of .netlify/functions-internal/server, sync it
if (fs.existsSync(distServerDir) && !fs.existsSync(netlifyServerDir)) {
  console.log("[postbuild] Copying dist/server to .netlify/functions-internal/server...");
  fs.mkdirSync(netlifyServerDir, { recursive: true });
  fs.cpSync(distServerDir, netlifyServerDir, { recursive: true });
}

// 4. Ensure dist/client directory exists
if (!fs.existsSync(distClientDir)) {
  fs.mkdirSync(distClientDir, { recursive: true });
}

// 5. Sync client assets from dist to dist/client (so both dist and dist/client are fully populated)
try {
  const distEntries = fs.readdirSync(distDir, { withFileTypes: true });
  for (const entry of distEntries) {
    if (entry.name === "client" || entry.name === "server" || entry.name === "nitro.json") {
      continue;
    }
    const srcPath = path.join(distDir, entry.name);
    const destPath = path.join(distClientDir, entry.name);
    fs.cpSync(srcPath, destPath, { recursive: true, force: true });
  }
} catch (err) {
  console.warn("[postbuild] Warning while syncing dist to dist/client:", err);
}

// 6. Ensure _redirects is present in both dist and dist/client for Netlify SSR routing
const redirectRule = "/*  /.netlify/functions/server  200\n";

const distRedirects = path.join(distDir, "_redirects");
const distClientRedirects = path.join(distClientDir, "_redirects");

fs.writeFileSync(distRedirects, redirectRule, "utf8");
fs.writeFileSync(distClientRedirects, redirectRule, "utf8");

console.log("[postbuild] Successfully prepared dist, dist/client, and .netlify/functions-internal.");
