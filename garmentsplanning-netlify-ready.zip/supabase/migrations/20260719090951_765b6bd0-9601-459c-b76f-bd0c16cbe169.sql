
-- 1. Add team_leader_id column to plans
ALTER TABLE public.plans ADD COLUMN IF NOT EXISTS team_leader_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS plans_team_leader_id_idx ON public.plans(team_leader_id);

-- 2. Backfill existing plans
-- For plans by team_leader: use creator
UPDATE public.plans p SET team_leader_id = p.created_by
FROM public.user_roles ur
WHERE ur.user_id = p.created_by AND ur.role = 'team_leader' AND p.team_leader_id IS NULL;

-- For plans by user: use their team_leader_id
UPDATE public.plans p SET team_leader_id = pr.team_leader_id
FROM public.profiles pr
WHERE pr.id = p.created_by AND pr.team_leader_id IS NOT NULL AND p.team_leader_id IS NULL;

-- For plans by admin: pick first team_leader in same factory (fallback to any)
UPDATE public.plans p SET team_leader_id = (
  SELECT pr.id FROM public.profiles pr
  JOIN public.user_roles ur2 ON ur2.user_id = pr.id AND ur2.role = 'team_leader'
  WHERE pr.factory_id IS NOT DISTINCT FROM p.factory_id
  ORDER BY pr.created_at ASC LIMIT 1
)
WHERE p.team_leader_id IS NULL;

-- 3. Trigger to auto-set team_leader_id on insert
CREATE OR REPLACE FUNCTION public.plans_set_team_leader_id()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_tl BOOLEAN;
  v_tl UUID;
BEGIN
  IF NEW.team_leader_id IS NOT NULL THEN
    RETURN NEW;
  END IF;

  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = NEW.created_by AND role = 'team_leader') INTO v_is_tl;
  IF v_is_tl THEN
    NEW.team_leader_id := NEW.created_by;
    RETURN NEW;
  END IF;

  SELECT team_leader_id INTO v_tl FROM public.profiles WHERE id = NEW.created_by;
  IF v_tl IS NOT NULL THEN
    NEW.team_leader_id := v_tl;
    RETURN NEW;
  END IF;

  -- Admin (or user without TL): pick first TL in same factory
  SELECT pr.id INTO v_tl
  FROM public.profiles pr
  JOIN public.user_roles ur2 ON ur2.user_id = pr.id AND ur2.role = 'team_leader'
  WHERE pr.factory_id IS NOT DISTINCT FROM NEW.factory_id
  ORDER BY pr.created_at ASC LIMIT 1;

  NEW.team_leader_id := v_tl;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS plans_set_team_leader_id_trg ON public.plans;
CREATE TRIGGER plans_set_team_leader_id_trg
BEFORE INSERT ON public.plans
FOR EACH ROW EXECUTE FUNCTION public.plans_set_team_leader_id();

-- 4. Update RLS policies on plans to use team_leader_id
DROP POLICY IF EXISTS "plans_select" ON public.plans;
DROP POLICY IF EXISTS "plans_insert" ON public.plans;
DROP POLICY IF EXISTS "plans_update" ON public.plans;
DROP POLICY IF EXISTS "plans_delete" ON public.plans;

CREATE POLICY "plans_select" ON public.plans FOR SELECT TO authenticated
USING (
  auth.uid() = created_by
  OR public.has_role(auth.uid(), 'admin')
  OR (team_leader_id IS NOT NULL AND (
    auth.uid() = team_leader_id
    OR EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.id = auth.uid() AND pr.team_leader_id = plans.team_leader_id)
  ))
);

CREATE POLICY "plans_insert" ON public.plans FOR INSERT TO authenticated
WITH CHECK (auth.uid() = created_by);

CREATE POLICY "plans_update" ON public.plans FOR UPDATE TO authenticated
USING (
  auth.uid() = created_by
  OR public.has_role(auth.uid(), 'admin')
  OR (team_leader_id IS NOT NULL AND (
    auth.uid() = team_leader_id
    OR EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.id = auth.uid() AND pr.team_leader_id = plans.team_leader_id)
  ))
);

CREATE POLICY "plans_delete" ON public.plans FOR DELETE TO authenticated
USING (
  auth.uid() = created_by
  OR public.has_role(auth.uid(), 'admin')
  OR (team_leader_id IS NOT NULL AND auth.uid() = team_leader_id)
);

-- 5. Update production_updates policies to piggyback on plans visibility
DROP POLICY IF EXISTS "pu_select" ON public.production_updates;
DROP POLICY IF EXISTS "pu_insert" ON public.production_updates;
DROP POLICY IF EXISTS "pu_update" ON public.production_updates;
DROP POLICY IF EXISTS "pu_delete" ON public.production_updates;

CREATE POLICY "pu_select" ON public.production_updates FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.plans p WHERE p.id = plan_id));

CREATE POLICY "pu_insert" ON public.production_updates FOR INSERT TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM public.plans p WHERE p.id = plan_id));

CREATE POLICY "pu_update" ON public.production_updates FOR UPDATE TO authenticated
USING (EXISTS (SELECT 1 FROM public.plans p WHERE p.id = plan_id));

CREATE POLICY "pu_delete" ON public.production_updates FOR DELETE TO authenticated
USING (EXISTS (SELECT 1 FROM public.plans p WHERE p.id = plan_id));
