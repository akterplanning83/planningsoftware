
-- 1) Add factory_id to plans (auto-tags each plan with a factory for team visibility)
ALTER TABLE public.plans ADD COLUMN IF NOT EXISTS factory_id UUID REFERENCES public.factories(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS plans_factory_id_idx ON public.plans(factory_id);

-- 2) Trigger to auto-populate factory_id from creator's profile on insert (if not provided)
CREATE OR REPLACE FUNCTION public.plans_set_factory_id()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_factory UUID;
  v_only_factory UUID;
BEGIN
  IF NEW.factory_id IS NULL THEN
    SELECT factory_id INTO v_factory FROM public.profiles WHERE id = NEW.created_by;
    IF v_factory IS NOT NULL THEN
      NEW.factory_id := v_factory;
    ELSE
      -- If creator has no factory but exactly one factory exists in the system, tag to it.
      SELECT id INTO v_only_factory FROM public.factories LIMIT 2;
      IF (SELECT COUNT(*) FROM public.factories) = 1 THEN
        SELECT id INTO NEW.factory_id FROM public.factories LIMIT 1;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_plans_set_factory_id ON public.plans;
CREATE TRIGGER trg_plans_set_factory_id
BEFORE INSERT ON public.plans
FOR EACH ROW EXECUTE FUNCTION public.plans_set_factory_id();

-- 3) Backfill existing plans
UPDATE public.plans p
SET factory_id = pr.factory_id
FROM public.profiles pr
WHERE p.factory_id IS NULL AND pr.id = p.created_by AND pr.factory_id IS NOT NULL;

-- For plans where creator has no factory, if only one factory exists, tag to it.
UPDATE public.plans SET factory_id = (SELECT id FROM public.factories LIMIT 1)
WHERE factory_id IS NULL
  AND (SELECT COUNT(*) FROM public.factories) = 1;

-- 4) Update SELECT policy: visible to team OR anyone in the plan's factory
DROP POLICY IF EXISTS "plans select team" ON public.plans;
CREATE POLICY "plans select team or factory"
ON public.plans FOR SELECT
TO authenticated
USING (
  public.same_team(auth.uid(), created_by)
  OR (
    plans.factory_id IS NOT NULL
    AND EXISTS (SELECT 1 FROM public.profiles pr
                WHERE pr.id = auth.uid() AND pr.factory_id = plans.factory_id)
  )
  OR public.has_role(auth.uid(), 'admin')
);

-- 5) Update UPDATE policy similarly (owner, admin, TL of owner, or same factory member)
DROP POLICY IF EXISTS "plans update owner tl or admin" ON public.plans;
CREATE POLICY "plans update team or factory"
ON public.plans FOR UPDATE
TO authenticated
USING (
  auth.uid() = created_by
  OR public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.profiles p
             WHERE p.id = plans.created_by AND p.team_leader_id = auth.uid())
  OR (
    plans.factory_id IS NOT NULL
    AND EXISTS (SELECT 1 FROM public.profiles pr
                WHERE pr.id = auth.uid() AND pr.factory_id = plans.factory_id)
  )
)
WITH CHECK (
  auth.uid() = created_by
  OR public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.profiles p
             WHERE p.id = plans.created_by AND p.team_leader_id = auth.uid())
  OR (
    plans.factory_id IS NOT NULL
    AND EXISTS (SELECT 1 FROM public.profiles pr
                WHERE pr.id = auth.uid() AND pr.factory_id = plans.factory_id)
  )
);

-- 6) Update DELETE policy similarly
DROP POLICY IF EXISTS "plans delete owner tl or admin" ON public.plans;
CREATE POLICY "plans delete team or factory"
ON public.plans FOR DELETE
TO authenticated
USING (
  auth.uid() = created_by
  OR public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.profiles p
             WHERE p.id = plans.created_by AND p.team_leader_id = auth.uid())
  OR (
    plans.factory_id IS NOT NULL
    AND EXISTS (SELECT 1 FROM public.profiles pr
                WHERE pr.id = auth.uid() AND pr.factory_id = plans.factory_id)
  )
);

-- 7) Extend production_updates SELECT/UPDATE/DELETE via the plan's factory as well
DROP POLICY IF EXISTS "prod updates select team" ON public.production_updates;
CREATE POLICY "prod updates select team or factory"
ON public.production_updates FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p
             WHERE p.id = production_updates.plan_id
               AND (
                 public.same_team(auth.uid(), p.created_by)
                 OR (p.factory_id IS NOT NULL AND EXISTS (
                   SELECT 1 FROM public.profiles pr
                   WHERE pr.id = auth.uid() AND pr.factory_id = p.factory_id
                 ))
               ))
);

DROP POLICY IF EXISTS "prod updates update team" ON public.production_updates;
CREATE POLICY "prod updates update team or factory"
ON public.production_updates FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p
             WHERE p.id = production_updates.plan_id
               AND (
                 p.created_by = auth.uid()
                 OR EXISTS (SELECT 1 FROM public.profiles pr
                            WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
                 OR (p.factory_id IS NOT NULL AND EXISTS (
                   SELECT 1 FROM public.profiles pr
                   WHERE pr.id = auth.uid() AND pr.factory_id = p.factory_id
                 ))
               ))
)
WITH CHECK (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p
             WHERE p.id = production_updates.plan_id
               AND (
                 p.created_by = auth.uid()
                 OR EXISTS (SELECT 1 FROM public.profiles pr
                            WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
                 OR (p.factory_id IS NOT NULL AND EXISTS (
                   SELECT 1 FROM public.profiles pr
                   WHERE pr.id = auth.uid() AND pr.factory_id = p.factory_id
                 ))
               ))
);

DROP POLICY IF EXISTS "prod updates delete team" ON public.production_updates;
CREATE POLICY "prod updates delete team or factory"
ON public.production_updates FOR DELETE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR EXISTS (SELECT 1 FROM public.plans p
             WHERE p.id = production_updates.plan_id
               AND (
                 p.created_by = auth.uid()
                 OR EXISTS (SELECT 1 FROM public.profiles pr
                            WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
                 OR (p.factory_id IS NOT NULL AND EXISTS (
                   SELECT 1 FROM public.profiles pr
                   WHERE pr.id = auth.uid() AND pr.factory_id = p.factory_id
                 ))
               ))
);

DROP POLICY IF EXISTS "prod updates insert team" ON public.production_updates;
CREATE POLICY "prod updates insert team or factory"
ON public.production_updates FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = created_by
  AND (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.plans p
               WHERE p.id = production_updates.plan_id
                 AND (
                   p.created_by = auth.uid()
                   OR EXISTS (SELECT 1 FROM public.profiles pr
                              WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
                   OR (p.factory_id IS NOT NULL AND EXISTS (
                     SELECT 1 FROM public.profiles pr
                     WHERE pr.id = auth.uid() AND pr.factory_id = p.factory_id
                   ))
                 ))
  )
);
