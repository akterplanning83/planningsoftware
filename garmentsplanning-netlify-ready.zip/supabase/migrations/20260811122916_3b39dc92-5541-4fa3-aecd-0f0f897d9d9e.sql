-- Ensure RLS is enabled and policies are set correctly for floor clusters
ALTER TABLE public.budget_floor_clusters ENABLE ROW LEVEL SECURITY;

-- Grant access to authenticated users
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_floor_clusters TO authenticated;
GRANT ALL ON public.budget_floor_clusters TO service_role;

-- Policy to allow users to see and manage clusters within their factory
DROP POLICY IF EXISTS "Users can manage clusters in their factory" ON public.budget_floor_clusters;

CREATE POLICY "Users can manage clusters in their factory"
ON public.budget_floor_clusters
FOR ALL
TO authenticated
USING (
    factory_id IN (
        SELECT factory_id 
        FROM public.profiles 
        WHERE id = auth.uid()
    )
)
WITH CHECK (
    factory_id IN (
        SELECT factory_id 
        FROM public.profiles 
        WHERE id = auth.uid()
    )
);

-- Fix profile factory_id if it's missing (utility for current user)
DO $$
DECLARE
    first_factory_id uuid;
BEGIN
    SELECT id INTO first_factory_id FROM public.factories LIMIT 1;
    
    IF first_factory_id IS NOT NULL THEN
        UPDATE public.profiles 
        SET factory_id = first_factory_id 
        WHERE factory_id IS NULL;
    END IF;
END $$;
