-- Ensure tables exist and permissions are granted
CREATE TABLE IF NOT EXISTS public.budget_line_details (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    line_name text NOT NULL,
    cost_head text NOT NULL,
    budget_value numeric DEFAULT 0,
    actual_value numeric DEFAULT 0,
    entry_date date DEFAULT CURRENT_DATE,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Handle unique constraint separately to ensure it exists
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'budget_line_details_factory_id_month_line_name_cost_head_entry_date_key') THEN
        ALTER TABLE public.budget_line_details 
        ADD CONSTRAINT budget_line_details_factory_id_month_line_name_cost_head_entry_date_key 
        UNIQUE(factory_id, month, line_name, cost_head, entry_date);
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.budget_department_details (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    month date NOT NULL,
    department text NOT NULL,
    cost_head text NOT NULL,
    budget_value numeric DEFAULT 0,
    actual_value numeric DEFAULT 0,
    entry_date date DEFAULT CURRENT_DATE,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Handle unique constraint separately
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'budget_department_details_factory_id_month_department_cost_head_entry_date_key') THEN
        ALTER TABLE public.budget_department_details 
        ADD CONSTRAINT budget_department_details_factory_id_month_department_cost_head_entry_date_key 
        UNIQUE(factory_id, month, department, cost_head, entry_date);
    END IF;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_line_details TO authenticated;
GRANT ALL ON public.budget_line_details TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_department_details TO authenticated;
GRANT ALL ON public.budget_department_details TO service_role;

ALTER TABLE public.budget_line_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_department_details ENABLE ROW LEVEL SECURITY;

-- Re-create policies to ensure they are correct
DROP POLICY IF EXISTS "Manage factory budget line details" ON public.budget_line_details;
CREATE POLICY "Manage factory budget line details" ON public.budget_line_details
    FOR ALL TO authenticated
    USING (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()))
    WITH CHECK (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()));

DROP POLICY IF EXISTS "Manage factory budget dept details" ON public.budget_department_details;
CREATE POLICY "Manage factory budget dept details" ON public.budget_department_details
    FOR ALL TO authenticated
    USING (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()))
    WITH CHECK (factory_id IN (SELECT factory_id FROM public.profiles WHERE id = auth.uid()));
