-- Step 1: Add new roles to app_role enum. Cannot be used in same tx.
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'team_leader';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'user';