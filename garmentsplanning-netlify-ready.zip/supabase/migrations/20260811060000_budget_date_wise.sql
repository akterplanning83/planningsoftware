ALTER TABLE public.budget_line_details 
DROP CONSTRAINT IF EXISTS budget_line_details_factory_id_month_line_name_cost_head_key;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'budget_line_details' AND column_name = 'entry_date') THEN
        ALTER TABLE public.budget_line_details ADD COLUMN entry_date date DEFAULT CURRENT_DATE;
    END IF;
END
$$;

ALTER TABLE public.budget_line_details 
DROP CONSTRAINT IF EXISTS budget_line_details_factory_id_month_line_name_cost_head_entry_date_key;

ALTER TABLE public.budget_line_details 
ADD CONSTRAINT budget_line_details_factory_id_month_line_name_cost_head_entry_date_key 
UNIQUE(factory_id, month, line_name, cost_head, entry_date);

ALTER TABLE public.budget_department_details
DROP CONSTRAINT IF EXISTS budget_department_details_factory_id_month_department_cost_he_key;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'budget_department_details' AND column_name = 'entry_date') THEN
        ALTER TABLE public.budget_department_details ADD COLUMN entry_date date DEFAULT CURRENT_DATE;
    END IF;
END
$$;

ALTER TABLE public.budget_department_details 
DROP CONSTRAINT IF EXISTS budget_department_details_factory_id_month_dept_cost_entry_key;

ALTER TABLE public.budget_department_details 
ADD CONSTRAINT budget_department_details_factory_id_month_dept_cost_entry_key 
UNIQUE(factory_id, month, department, cost_head, entry_date);
