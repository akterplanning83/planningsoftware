
CREATE TABLE public.line_presets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  factory_id UUID NOT NULL UNIQUE REFERENCES public.factories(id) ON DELETE CASCADE,
  presets TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.line_presets TO authenticated;
GRANT ALL ON public.line_presets TO service_role;

ALTER TABLE public.line_presets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View line presets in own factory or admin"
  ON public.line_presets FOR SELECT TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    OR factory_id = (SELECT factory_id FROM public.profiles WHERE id = auth.uid())
  );

CREATE POLICY "Admin or TL insert line presets"
  ON public.line_presets FOR INSERT TO authenticated
  WITH CHECK (
    public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'team_leader')
      AND factory_id = (SELECT factory_id FROM public.profiles WHERE id = auth.uid())
    )
  );

CREATE POLICY "Admin or TL update line presets"
  ON public.line_presets FOR UPDATE TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'team_leader')
      AND factory_id = (SELECT factory_id FROM public.profiles WHERE id = auth.uid())
    )
  )
  WITH CHECK (
    public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'team_leader')
      AND factory_id = (SELECT factory_id FROM public.profiles WHERE id = auth.uid())
    )
  );

CREATE POLICY "Admin delete line presets"
  ON public.line_presets FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER line_presets_set_updated_at
  BEFORE UPDATE ON public.line_presets
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Seed 37 lines for the existing factory
INSERT INTO public.line_presets (factory_id, presets)
SELECT id, ARRAY(SELECT 'Line - ' || g FROM generate_series(1, 37) AS g)
FROM public.factories
ON CONFLICT (factory_id) DO NOTHING;
