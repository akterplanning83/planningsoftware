
CREATE TABLE public.plan_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  note_date DATE NOT NULL DEFAULT CURRENT_DATE,
  note TEXT NOT NULL,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.plan_notes TO authenticated;
GRANT ALL ON public.plan_notes TO service_role;

ALTER TABLE public.plan_notes ENABLE ROW LEVEL SECURITY;

-- Read: anyone who can see the plan (via same_team on plan.created_by) can see the notes
CREATE POLICY "plan_notes_select_team" ON public.plan_notes
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.plans p
    WHERE p.id = plan_notes.plan_id
      AND public.same_team(auth.uid(), p.created_by)
  )
);

-- Insert: any team member who can see the plan
CREATE POLICY "plan_notes_insert_team" ON public.plan_notes
FOR INSERT TO authenticated
WITH CHECK (
  created_by = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.plans p
    WHERE p.id = plan_notes.plan_id
      AND public.same_team(auth.uid(), p.created_by)
  )
);

-- Update/Delete: only the note author or admin
CREATE POLICY "plan_notes_update_own" ON public.plan_notes
FOR UPDATE TO authenticated
USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "plan_notes_delete_own" ON public.plan_notes
FOR DELETE TO authenticated
USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE INDEX plan_notes_plan_id_idx ON public.plan_notes(plan_id, note_date DESC);

CREATE TRIGGER plan_notes_set_updated_at
  BEFORE UPDATE ON public.plan_notes
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
