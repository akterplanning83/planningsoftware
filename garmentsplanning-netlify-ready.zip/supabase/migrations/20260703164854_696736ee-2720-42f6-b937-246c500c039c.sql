
CREATE OR REPLACE FUNCTION public.bootstrap_admin_if_needed()
RETURNS public.app_role
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_has_admin BOOLEAN;
  v_role public.app_role;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') INTO v_has_admin;

  IF NOT v_has_admin THEN
    v_role := 'admin';
  ELSE
    v_role := 'manager';
  END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (v_uid, v_role)
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN v_role;
END;
$$;

REVOKE ALL ON FUNCTION public.bootstrap_admin_if_needed() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.bootstrap_admin_if_needed() TO authenticated;
