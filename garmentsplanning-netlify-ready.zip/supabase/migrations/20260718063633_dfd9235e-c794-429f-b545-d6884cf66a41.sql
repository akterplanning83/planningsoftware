-- Add team_leader_id to profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS team_leader_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_profiles_team_leader_id ON public.profiles(team_leader_id);

-- Migrate existing manager rows to team_leader
UPDATE public.user_roles SET role = 'team_leader' WHERE role = 'manager';

-- Update handle_new_user: first user = admin, otherwise 'user'
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_has_admin BOOLEAN;
  v_role public.app_role;
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1))
  )
  ON CONFLICT (id) DO NOTHING;

  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') INTO v_has_admin;
  v_role := CASE WHEN v_has_admin THEN 'user'::public.app_role ELSE 'admin'::public.app_role END;

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, v_role)
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN NEW;
END;
$$;

-- same_team helper: admin OR same team leader OR one is TL of the other OR self
CREATE OR REPLACE FUNCTION public.same_team(_a uuid, _b uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    _a = _b
    OR public.has_role(_a, 'admin')
    OR EXISTS (
      SELECT 1 FROM public.profiles pa, public.profiles pb
      WHERE pa.id = _a AND pb.id = _b
        AND (
          -- same team leader
          (pa.team_leader_id IS NOT NULL AND pa.team_leader_id = pb.team_leader_id)
          -- a is team leader of b
          OR pb.team_leader_id = pa.id
          -- b is team leader of a
          OR pa.team_leader_id = pb.id
        )
    )
$$;

-- ============= PLANS RLS =============
DROP POLICY IF EXISTS "plans readable own or admin" ON public.plans;
DROP POLICY IF EXISTS "plans insert own" ON public.plans;
DROP POLICY IF EXISTS "plans update own or admin" ON public.plans;
DROP POLICY IF EXISTS "plans delete own or admin" ON public.plans;

CREATE POLICY "plans select team"
  ON public.plans FOR SELECT
  TO authenticated
  USING (public.same_team(auth.uid(), created_by));

CREATE POLICY "plans insert own"
  ON public.plans FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "plans update owner tl or admin"
  ON public.plans FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = created_by
    OR public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = created_by AND p.team_leader_id = auth.uid())
  )
  WITH CHECK (
    auth.uid() = created_by
    OR public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = created_by AND p.team_leader_id = auth.uid())
  );

CREATE POLICY "plans delete owner tl or admin"
  ON public.plans FOR DELETE
  TO authenticated
  USING (
    auth.uid() = created_by
    OR public.has_role(auth.uid(), 'admin')
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = created_by AND p.team_leader_id = auth.uid())
  );

-- ============= PRODUCTION UPDATES RLS =============
DROP POLICY IF EXISTS "prod updates select own or admin" ON public.production_updates;
DROP POLICY IF EXISTS "prod updates insert own or admin" ON public.production_updates;
DROP POLICY IF EXISTS "prod updates update own or admin" ON public.production_updates;
DROP POLICY IF EXISTS "prod updates delete own or admin" ON public.production_updates;

CREATE POLICY "prod updates select team"
  ON public.production_updates FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1 FROM public.plans p
      WHERE p.id = production_updates.plan_id
        AND public.same_team(auth.uid(), p.created_by)
    )
  );

CREATE POLICY "prod updates insert team"
  ON public.production_updates FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND (
      public.has_role(auth.uid(), 'admin')
      OR EXISTS (
        SELECT 1 FROM public.plans p
        WHERE p.id = production_updates.plan_id
          AND (
            p.created_by = auth.uid()
            OR EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
          )
      )
    )
  );

CREATE POLICY "prod updates update team"
  ON public.production_updates FOR UPDATE
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1 FROM public.plans p
      WHERE p.id = production_updates.plan_id
        AND (
          p.created_by = auth.uid()
          OR EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
        )
    )
  )
  WITH CHECK (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1 FROM public.plans p
      WHERE p.id = production_updates.plan_id
        AND (
          p.created_by = auth.uid()
          OR EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
        )
    )
  );

CREATE POLICY "prod updates delete team"
  ON public.production_updates FOR DELETE
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1 FROM public.plans p
      WHERE p.id = production_updates.plan_id
        AND (
          p.created_by = auth.uid()
          OR EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.id = p.created_by AND pr.team_leader_id = auth.uid())
        )
    )
  );

-- ============= PROFILES RLS =============
DROP POLICY IF EXISTS "profiles readable own or admin" ON public.profiles;
CREATE POLICY "profiles readable team"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (public.same_team(auth.uid(), id));