CREATE TABLE IF NOT EXISTS public.budget_floor_clusters (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id uuid NOT NULL REFERENCES public.factories(id),
    cluster_name text NOT NULL,
    line_names text[] NOT NULL DEFAULT '{}',
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(factory_id, cluster_name)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.budget_floor_clusters TO authenticated;
GRANT ALL ON public.budget_floor_clusters TO service_role;

ALTER TABLE public.budget_floor_clusters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Manage factory floor clusters" ON public.budget_floor_clusters
    FOR ALL TO authenticated
    USING ((SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id)
    WITH CHECK ((SELECT factory_id FROM public.profiles WHERE id = auth.uid()) = factory_id);