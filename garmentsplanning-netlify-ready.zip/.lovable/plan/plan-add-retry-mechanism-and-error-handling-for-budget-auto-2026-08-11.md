# Plan: Add Retry Mechanism and Error Handling for Budget Auto-save

I will implement a robust error handling and retry system for the Line Wise Budget auto-save feature to ensure data integrity and provide clear feedback to the user.

## Proposed Changes

### 1. State Management

- Add a new state variable `saveError` (string | null) to `MonthlyBudgetView.tsx` to track and display specific error messages.

### 2. Mutation Enhancements

- Update `bulkUpsertLineMutation` in `src/components/planning/MonthlyBudgetView.tsx`:
  - Add `retry: 3` to the mutation configuration for automatic background retries on transient failures.
  - Update `onError` to set a descriptive error message in `saveError` and stop the `isSaving` spinner.
  - Update `onSuccess` to clear `saveError`.

### 3. UI Feedback Improvements

- Modify the status indicator area in the "Line Wise Budget" tab:
  - If a save fails after all retries, display the error message in red text.
  - Add a "Retry Now" button that appears only when an error occurs, allowing the user to manually trigger `saveLineBudget()`.
  - Maintain the existing "Saving..." and "All changes saved" indicators, but prioritize the error state when active.

### 4. Logic Refinement

- Update `saveLineBudget` to clear the `saveError` state at the beginning of each manual or automatic attempt.

## Technical Details

- **File**: `src/components/planning/MonthlyBudgetView.tsx`
- **Hook**: `useMutation` for `bulkUpsertLineMutation`.
- **Components**: `AlertCircle` icon (from `lucide-react`) for error visibility.
- **Retry Strategy**: 3 automatic retries with exponential backoff (default TanStack behavior).

## User Impact

- **Transparency**: Users will know exactly why a save failed (e.g., "Network error", "Permission denied").
- **Reliability**: Brief network hiccups will be handled automatically without user intervention.
- **Control**: Users can manually re-trigger a save if the automatic system stops.
